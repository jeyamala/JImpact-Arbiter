package org.jwalk;

import java.util.EventObject;
import org.jwalk.out.Question;

public class QuestionEvent extends EventObject {

    private static final long serialVersionUID = 1L;
    protected Question question;

    public QuestionEvent(JWalker source, Question question) {
        super(source);
        this.question = question;
    }

    public JWalker getSource() {
        return (JWalker) super.getSource();
    }

    public Question getQuestion() {
        return this.question;
    }

    public String toString() {
        return this.question.toString();
    }
}
