package org.jwalk;

import java.lang.reflect.Member;

public class ExecutionException extends JWalkException {

    private Member operation = null;
    private boolean random = false;

    public ExecutionException(Member operation) {
        super("Could not invoke the operation: " + operation,
                Error.EXECUTION_ERROR);
        this.operation = operation;
    }

    public ExecutionException(Member operation, String message) {
        super(message + operation, Error.EXECUTION_ERROR);
        this.operation = operation;
    }

    public ExecutionException(Member operation, boolean random) {
        super("Unpredictable behaviour by the operation: " + operation,
                Error.EXECUTION_ERROR);
        this.operation = operation;
        this.random = true;
    }

    public Member getOperation() {
        return this.operation;
    }

    public boolean invocationFailed() {
        return !this.random;
    }

    public boolean executionFailed() {
        return this.random;
    }
}
