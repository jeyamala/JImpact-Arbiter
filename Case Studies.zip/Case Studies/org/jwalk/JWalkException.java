package org.jwalk;

public class JWalkException extends Exception {

    private Error error;

    public JWalkException(String message, Error error) {
        super(message);
        this.error = error;
    }

    public Error getError() {
        return this.error;
    }
}
