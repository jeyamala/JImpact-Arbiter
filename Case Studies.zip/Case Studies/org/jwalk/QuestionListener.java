package org.jwalk;

import java.util.EventListener;
import org.jwalk.out.Answer;

public abstract interface QuestionListener extends EventListener {

    public abstract Answer respond(QuestionEvent paramQuestionEvent);
}
