package org.jwalk;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.jwalk.gen.CustomGenerator;

public class Settings {

    private int testDepth = 3;
    private int probeDepth = 12;
    private int treeDepth = 0;
    private Strategy strategy = Strategy.ALGEBRA;
    private Modality modality = Modality.EXPLORE;
    private Convention convention = Convention.STANDARD;
    private File testClassDirectory = null;
    private File generatorDirectory = null;
    private File oracleDirectory = null;
    private List<Class<CustomGenerator>> customGenerators = null;
    private ClassLoader loader = null;
    private Class<?> testClass = null;

    private ClassLoader getClassLoader()
            throws MalformedURLException {
        if (this.loader == null) {
            ClassLoader parent = getClass().getClassLoader();
            URL[] urls = {
                getTestClassDirectory().toURI().toURL(),
                getGeneratorDirectory().toURI().toURL()};

            this.loader = new URLClassLoader(urls, parent);
        }
        return this.loader;
    }

    public Settings() {
//       LicenseManager manager = new LicenseManager();
//       manager.validateLicense();
        try {
            addCustomGenerator("org.jwalk.gen.StringGenerator");
            addCustomGenerator("org.jwalk.gen.InterfaceGenerator");
            addCustomGenerator("org.jwalk.gen.EnumGenerator");
            addCustomGenerator("org.jwalk.gen.PlatformGenerator");
        } catch (LoaderException ex) {
            System.out.println(ex);
        }
    }

    public int getTestDepth() {
        return this.testDepth;
    }

    public int getProbeDepth() {
        return this.probeDepth;
    }

    public int getTreeDepth() {
        return this.treeDepth;
    }

    public Strategy getStrategy() {
        return this.strategy;
    }

    public Modality getModality() {
        return this.modality;
    }

    public Convention getConvention() {
        return this.convention;
    }

    public File getTestClassDirectory() {
        if (this.testClassDirectory == null) {
            String current = System.getProperty("user.dir");
            return new File(current);
        }

        return this.testClassDirectory;
    }

    public File getGeneratorDirectory() {
        if (this.generatorDirectory == null) {
            return getTestClassDirectory();
        }
        return this.generatorDirectory;
    }

    public File getOracleDirectory() {
        if (this.oracleDirectory == null) {
            return getTestClassDirectory();
        }
        return this.oracleDirectory;
    }

    public Class<?> getTestClass() {
        return this.testClass;
    }

    public List<Class<CustomGenerator>> getCustomGenerators() {
        if (this.customGenerators == null) {
            return Collections.emptyList();
        }
        return this.customGenerators;
    }

    public void setTestDepth(int depth) {
        if (depth < 0) {
            this.testDepth = 0;
        } else {
            this.testDepth = depth;
        }
    }

    public void setProbeDepth(int depth) {
        if (depth < 0) {
            this.probeDepth = 0;
        } else {
            this.probeDepth = depth;
        }
    }

    public void setTreeDepth(int depth) {
        if (depth < 0) {
            this.treeDepth = 0;
        } else {
            this.treeDepth = depth;
        }
    }

    public void setStrategy(Strategy strategy) {
        this.strategy = strategy;
    }

    public void setModality(Modality mode) {
        this.modality = mode;
    }

    public void setConvention(Convention convention) {
        this.convention = convention;
    }

    public void setTestClassDirectory(File directory) {
        this.testClassDirectory = directory;
        this.loader = null;
    }

    public void setGeneratorDirectory(File directory) {
        this.generatorDirectory = directory;
        this.loader = null;
    }

    public void setOracleDirectory(File directory) {
        this.oracleDirectory = directory;
    }

    public void setTestClass(Class<?> testClass) {
        this.testClass = testClass;
    }

    public void setTestClass(String name)
            throws LoaderException {
        File directory = getTestClassDirectory();
        final String clsname = name;
        try {
            try {
                URL[] urls = {directory.toURI().toURL()};
                ClassLoader parent = getClassLoader();
                ClassLoader loader = new URLClassLoader(urls, parent) {

                    public Class<?> loadClass(String name) throws ClassNotFoundException {
                        if ((!name.equals(clsname))
                                || (name.startsWith("java"))) {
                            return super.loadClass(name);
                        }
                        return findClass(name);
                    }
                };
                this.testClass = loader.loadClass(name);
            } catch (IOException ex) {
                this.testClass = Class.forName(name);
            }
        } catch (ClassNotFoundException ex) {
            throw new LoaderException(name);
        } catch (NoClassDefFoundError ex) {
            throw new LoaderException(name, true);
        }
    }

    public void addCustomGenerator(Class<CustomGenerator> generator) {
        if (this.customGenerators == null) {
            this.customGenerators = new ArrayList();
        }
        this.customGenerators.add(generator);
    }

    public void addCustomGenerator(String name)
            throws LoaderException {
        Class generator = null;
        try {
            try {
                ClassLoader loader = getClassLoader();
                generator =
                        loader.loadClass(name);
            } catch (IOException ex) {
                generator =
                        Class.forName(name);
            }
            addCustomGenerator(generator);
        } catch (ClassNotFoundException ex) {
            throw new LoaderException(name);
        } catch (NoClassDefFoundError ex) {
            throw new LoaderException(name, true);
        } catch (ClassCastException ex) {
            throw new LoaderException(name);
        }
    }

    public void removeCustomGenerator(Class<CustomGenerator> generator) {
        if (this.customGenerators != null) {
            this.customGenerators.remove(generator);
        }
    }

    public void removeCustomGenerator(String name) {
        Class toRemove = null;
        for (Class generator : getCustomGenerators()) {
            if (name.equals(generator.getName())) {
                toRemove = generator;
                break;
            }
        }
        if (toRemove != null) {
            this.customGenerators.remove(toRemove);
        }
    }
}
