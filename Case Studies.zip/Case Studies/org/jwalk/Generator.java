package org.jwalk;

public abstract interface Generator {

    public abstract Object nextValue(Class<?> paramClass)
            throws GeneratorException;

    public abstract boolean canCreate(Class<?> paramClass);
}
