package org.jwalk;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import org.jwalk.out.Answer;
import org.jwalk.out.Confirmation;
import org.jwalk.out.Edition;
import org.jwalk.out.Notification;
import org.jwalk.out.Question;
import org.jwalk.out.Report;
import org.jwalk.out.Urgency;

public class Console
        implements QuestionListener, ReportListener {

    private BufferedReader keyboard;
    private PrintStream monitor;

    public Console() {
        super();
        this.keyboard = new BufferedReader(new InputStreamReader(System.in));
        this.monitor = System.out;
    }

    public void publish(ReportEvent event) {
        Report report = event.getReport();
        this.monitor.print(report);
        this.monitor.flush();
    }

    public Answer respond(QuestionEvent event) {
        Question question = event.getQuestion();
        Edition edition = question.getEdition();
        switch (edition) {
            case STATE_REPORT:
                return handle((Confirmation) question);
            case SUMMARY_REPORT:
                return handle((Notification) question);
        }

        return Answer.QUIT;
    }

    private Answer handle(Confirmation question) {
        this.monitor.print("JWalk Query: \n\n");
        this.monitor.print(question.getContent());
        this.monitor.print("\n\n");
        try {
            char key;
            do {
                this.monitor.print(question.getQuestion());
                String line = this.keyboard.readLine();
                this.monitor.println();
                key = line.length() == 0 ? 'y' : line.charAt(0);
                if ((key == 'y') || (key == 'Y')) {
                    return Answer.YES;
                }
                if ((key == 'n') || (key == 'N')) {
                    return Answer.NO;
                }
            } while ((key != 'q') && (key != 'Q'));
            return Answer.QUIT;
        } catch (IOException ex) {
        }
        return Answer.QUIT;
    }

    private Answer handle(Notification notice) {
        Urgency urgency = notice.getUrgency();
        switch (urgency) {
            case NOTICE:
                this.monitor.print("JWalk Notice: \n\n");
                break;
            case SILENT:
                this.monitor.print("JWalk Warning: \n\n");
                break;
            case WARNING:
                this.monitor.print("JWalk Error: \n\n");
        }

        this.monitor.print(notice.getContent());
        this.monitor.print("\n\n");
        try {
            char key;
            do {
                this.monitor.print(notice.getQuestion());
                String line = this.keyboard.readLine();
                this.monitor.println();
                key = line.length() == 0 ? 'y' : line.charAt(0);
            } while ((key != 'y') && (key != 'Y'));
            return Answer.OK;
        } catch (IOException ex) {
        }
        return Answer.OK;
    }
}
