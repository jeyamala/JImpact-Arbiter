package org.jwalk;

public class PermissionException extends JWalkException {

    private Class<?> type;
    private boolean generator;

    public PermissionException(Class<?> type) {
        super("Permission was refused to execute: "
                + type.getSimpleName(), Error.PERMISSION_ERROR);
        this.type = type;
    }

    public PermissionException(Class<?> type, String message) {
        super(message + type.getSimpleName(), Error.PERMISSION_ERROR);
        this.type = type;
    }

    public PermissionException(Class<?> type, boolean generator) {
        super("Permission was refused to execute: "
                + type.getSimpleName(), Error.PERMISSION_ERROR);
        this.type = type;
        this.generator = true;
    }

    public Class<?> getType() {
        return this.type;
    }

    public boolean testClassRefused() {
        return !this.generator;
    }

    public boolean generatorRefused() {
        return this.generator;
    }
}
