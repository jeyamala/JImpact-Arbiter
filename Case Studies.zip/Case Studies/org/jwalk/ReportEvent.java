package org.jwalk;

import java.util.EventObject;
import org.jwalk.out.Report;

public class ReportEvent extends EventObject {

    private static final long serialVersionUID = 1L;
    protected Report report;

    public ReportEvent(JWalker source, Report report) {
        super(source);
        this.report = report;
    }

    public JWalker getSource() {
        return (JWalker) super.getSource();
    }

    public Report getReport() {
        return this.report;
    }

    public String toString() {
        return this.report.toString();
    }
}
