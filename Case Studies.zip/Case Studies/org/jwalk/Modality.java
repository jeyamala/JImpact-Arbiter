package org.jwalk;

public enum Modality {

    INSPECT,
    EXPLORE,
    VALIDATE;
}
