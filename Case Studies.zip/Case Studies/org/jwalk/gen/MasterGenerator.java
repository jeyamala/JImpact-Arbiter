package org.jwalk.gen;

import org.jwalk.Generator;
import org.jwalk.JWalker;

public abstract interface MasterGenerator extends Generator
{
public abstract JWalker getJWalker();

public abstract void logTarget(Object paramObject);

public abstract Object getTarget();

public abstract Class<?> getTargetType();

public abstract void logObject(Object paramObject);

public abstract String oracleValue(Object paramObject);

public abstract void addDelegate(CustomGenerator paramCustomGenerator);
}

