package org.jwalk.gen;

import org.jwalk.Generator;

public abstract interface CustomGenerator extends Generator
{
public abstract void setOwner(MasterGenerator paramMasterGenerator);
}

