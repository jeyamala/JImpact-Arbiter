package org.jwalk.gen;

import java.nio.charset.Charset;
import java.util.Date;
import java.util.Locale;

public class PlatformGenerator
implements CustomGenerator
{
private static Locale[] standardLocales = Locale.getAvailableLocales();

private static Charset[] standardCharsets = (Charset[])Charset.availableCharsets().values().toArray(new Charset[0]);

private int localeSeed = 0;
private int charsetSeed = 0;
private long dateSeed = 0L;

public boolean canCreate(Class<?> type)
{
return (type == Locale.class) || (type == Charset.class) ||
(type == Date.class);
}

public Object nextValue(Class<?> type)
{
Object result;
if (type == Locale.class) {
result = this.localeSeed == 0 ? Locale.getDefault():
standardLocales[this.localeSeed];
this.localeSeed = ((this.localeSeed + 17) % standardLocales.length);
}
else if (type == Charset.class) {
result = this.charsetSeed == 0 ? Charset.defaultCharset() :
standardCharsets[this.charsetSeed];
this.charsetSeed = ((this.charsetSeed + 17) % standardCharsets.length);
}
else {
result = new Date(this.dateSeed);
this.dateSeed = ((this.dateSeed + 250000000000L) % 9223372036854775807L);
}
return result;
}

public void setOwner(MasterGenerator generator)
{
}
}


