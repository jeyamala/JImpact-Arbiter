package org.jwalk.gen;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jwalk.GeneratorException;

public class InterfaceGenerator
implements CustomGenerator
{
private MasterGenerator owner;

public boolean canCreate(Class<?> type)
{
return type.isInterface();
}

public Object nextValue(Class<?> type)
throws GeneratorException
{
if (type == CharSequence.class)
return this.owner.nextValue(String.class);
if (type == Collection.class)
return this.owner.nextValue(ArrayList.class);
if (type == List.class)
return this.owner.nextValue(ArrayList.class);
if (type == Set.class)
return this.owner.nextValue(HashSet.class);
if (type == Map.class) {
return this.owner.nextValue(HashMap.class);
}
if (type == Comparable.class)
return this.owner.nextValue(this.owner.getTargetType());
if (type == Cloneable.class) {
return this.owner.nextValue(this.owner.getTargetType());
}

throw new GeneratorException(type);
}

public void setOwner(MasterGenerator generator)
{
this.owner = generator;
}
}


