package org.jwalk.gen;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import org.jwalk.Channels;
import org.jwalk.GeneratorException;
import org.jwalk.JWalker;
import org.jwalk.Settings;
import org.jwalk.out.Notification;
import org.jwalk.out.Urgency;

public class RedirectInGenerator
implements CustomGenerator
{
private static String[] verses = {
"1 partridge in a pear tree",
"2 turtle doves",
"3 French hens",
"4 colly birds",
"5 gold rings",
"6 geese a-laying",
"7 swans a-swimming",
"8 maids a-milking",
"9 drummers drumming",
"10 pipers piping",
"11 ladies dancing",
"12 lords a-leaping",
"Oxford Dictionary of Nursery Rhymes" };
private InputStream oldInput;
private MasterGenerator owner;
private File inputFile;

public RedirectInGenerator()
{
this.oldInput = System.in;
}

private void redirectInput()
{
JWalker walker = this.owner.getJWalker();
Settings settings = walker.getSettings();
this.inputFile = new File(settings.getTestClassDirectory(), "input.txt");
try {
if (!this.inputFile.exists()) {
PrintStream output = new PrintStream(
new FileOutputStream(this.inputFile));
for (String line : verses)
output.println(line);
output.close();
Channels channels = walker.getChannels();
String message = "The input file `input.txt' was created in: \n" +
settings.getTestClassDirectory();
channels.dispatch(new Notification(walker, message, Urgency.NOTICE));
}
System.setIn(new FileInputStream(this.inputFile));
}
catch (FileNotFoundException ex) {
System.setIn(this.oldInput);
System.err.println(ex);
}
}

protected void finalize()
{
System.setIn(this.oldInput);
}

public void setOwner(MasterGenerator generator)
{
this.owner = generator;
redirectInput();
}

public boolean canCreate(Class<?> type)
{
return false;
}

public Object nextValue(Class<?> type)
throws GeneratorException
{
throw new GeneratorException(type);
}
}

