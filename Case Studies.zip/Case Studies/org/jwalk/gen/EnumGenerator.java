      package org.jwalk.gen;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.jwalk.GeneratorException;

public class EnumGenerator
implements CustomGenerator
{
private MasterGenerator owner;
protected Map<Class<?>, Integer> indexMap;

public EnumGenerator()
{
this.indexMap = new HashMap();
}

public boolean canCreate(Class<?> type)
{
return (type.isEnum()) || (type == Enum.class);
}

public Object nextValue(Class<?> type)
throws GeneratorException
{
if (type == Enum.class) {
return nextValue(getConcreteSubtype(type));
}
Integer enumSeed = (Integer)this.indexMap.get(type);
if (enumSeed == null)
enumSeed = Integer.valueOf(0);
Object[] values = type.getEnumConstants();
if (values == null)
throw new GeneratorException(type);
Object result = values[enumSeed.intValue()];
enumSeed = Integer.valueOf((enumSeed.intValue() + 1) % values.length);
this.indexMap.put(type, enumSeed);
return result;
}

public void setOwner(MasterGenerator generator)
{
this.owner = generator;
}

private Class<?> getConcreteSubtype(Class<?> type)
throws GeneratorException
{
Class result = this.owner.getTargetType();
if (!result.isEnum()) {
Iterator localIterator = this.indexMap.keySet().iterator(); if (localIterator.hasNext()) { Class first = (Class)localIterator.next();
result = first;
}

if (!result.isEnum())
throw new GeneratorException(type);
}
return result;
}
}


