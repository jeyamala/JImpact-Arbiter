     package org.jwalk.gen;

public class StringGenerator
implements CustomGenerator
{
private static String[] standardStrings = {
"aubergine", "barking", "crescent", "debatable",
"elementary", "forceful", "gumboots", "hawker",
"indignant", "jaundice", "kelp", "lambast",
"mornington", "nonesense", "opulent", "predator",
"queen", "register", "solemn", "tenuous", "undulate",
"version", "withering", "xylophone", "yellow", "zebra" };

private int stringSeed = 0;

public boolean canCreate(Class<?> type)
{
return type == String.class;
}

public Object nextValue(Class<?> type)
{
String result = standardStrings[this.stringSeed];
this.stringSeed = ((this.stringSeed + 1) % standardStrings.length);
return result;
}

public void setOwner(MasterGenerator generator)
{
}
}

