package org.jwalk.tool;

import javax.swing.JOptionPane;
import org.jwalk.QuestionEvent;
import org.jwalk.QuestionListener;
import org.jwalk.out.Answer;
import org.jwalk.out.Confirmation;
import org.jwalk.out.Edition;
import org.jwalk.out.Notification;
import org.jwalk.out.Question;
import org.jwalk.out.Urgency;

public class QuestionMaster
        implements QuestionListener {

    private JWalkTester application;

    public QuestionMaster(JWalkTester tester) {
        this.application = tester;
    }

    public Answer respond(QuestionEvent event) {
        Question question = event.getQuestion();
        Edition edition = question.getEdition();
        switch (edition) {
            case STATE_REPORT:
                return handle((Confirmation) question);
            case SUMMARY_REPORT:
                return handle((Notification) question);
        }

        return Answer.QUIT;
    }

    protected Answer handle(Confirmation question) {
        String title = "JWalk Query";
        int result = JOptionPane.showConfirmDialog(
                this.application, question.getContent(), title, 0);
        switch (result) {
            case 0:
                return Answer.YES;
            case 1:
                return Answer.NO;
            case 2:
                return Answer.QUIT;
        }
        return Answer.QUIT;
    }

    protected Answer handle(Notification notice) {
        Urgency urgency = notice.getUrgency();
        switch (urgency) {
            case ERROR:
                this.application.finishedTests();
                return Answer.OK;
            case NOTICE:
                JOptionPane.showMessageDialog(this.application,
                        notice.getContent(), "JWalk Notice",
                        1);
                return Answer.OK;
            case SILENT:
                JOptionPane.showMessageDialog(this.application,
                        notice.getContent(), "JWalk Warning",
                        2);
                return Answer.OK;
            case WARNING:
                this.application.handleException(notice.getException());
                return Answer.OK;
        }
        return Answer.OK;
    }
}
