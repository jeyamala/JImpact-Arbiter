package org.jwalk.tool;

import javax.swing.JPanel;

public abstract class AbstractPanel extends JPanel {

    protected JWalkTester application;

    public AbstractPanel(JWalkTester tester) {
        this.application = tester;
    }
}
