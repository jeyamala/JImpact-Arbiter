package org.jwalk.tool;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import org.jwalk.LoaderException;
import org.jwalk.Settings;

public class ClassFinderPanel extends AbstractPanel {

    private JTextField rootField;
    private JTextField nameField;
    private File directory = null;

    public ClassFinderPanel(JWalkTester tester) {
        super(tester);
        Settings settings = this.application.getSettings();
        this.directory = settings.getTestClassDirectory();
        setLayout(new GridLayout(4, 1));
        setBorder(BorderFactory.createTitledBorder("Test Class"));

        this.rootField = new JTextField();
        this.rootField.setText(this.directory.getAbsolutePath());
        this.rootField.setEditable(false);
        this.rootField.setToolTipText("The working directory for the test class");
        JButton rootButton = new JButton("Browse");
        rootButton.setToolTipText("Browse to select the working directory");
        rootButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(ActionEvent event) {
                        ClassFinderPanel.this.browseForClass(true);
                    }
                });
        JPanel rootPanel = new JPanel();
        rootPanel.setLayout(new BoxLayout(rootPanel, 0));
        rootPanel.add(this.rootField);
        rootPanel.add(rootButton);
        add(new JLabel(" Location: "));
        add(rootPanel);

        this.nameField = new JTextField();
        this.nameField.setEditable(true);
        this.nameField.setToolTipText("Enter the (qualified) name of the test class");
        JButton nameButton = new JButton("Browse");
        nameButton.setToolTipText("Browse within a package for the test class");
        nameButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(ActionEvent event) {
                        ClassFinderPanel.this.browseForClass(false);
                    }
                });
        JPanel namePanel = new JPanel();
        namePanel.setLayout(new BoxLayout(namePanel, 0));
        namePanel.add(this.nameField);
        namePanel.add(nameButton);
        add(new JLabel(" Name: "));
        add(namePanel);
    }

    private void browseForClass(boolean isRoot) {
        JFileChooser chooser = new JFileChooser(this.directory);
        chooser.setFileSelectionMode(2);
        chooser.setFileFilter(new FileFilter() {

            public boolean accept(File f) {
                return (f.isDirectory()) || (f.getName().endsWith(".class"));
            }

            public String getDescription() {
                return "Folders and Java class files";
            }
        });
        int result = chooser.showOpenDialog(this.application);
        if (result == 0) {
            File selected = chooser.getSelectedFile();
            if ((this.directory == null) || (isRoot)) {
                if (selected.isDirectory()) {
                    this.directory = selected;
                } else {
                    this.directory = chooser.getCurrentDirectory();
                }
            }
            String dirName = this.directory.getAbsolutePath();
            String clsName = selected.getAbsolutePath();

            if ((selected.isFile()) && (clsName.contains(dirName))) {
                clsName = clsName.substring(dirName.length() + 1);
                clsName = clsName.substring(0, clsName.indexOf(".class"));
            } else {
                clsName = "";
            }
            this.rootField.setText(dirName);
            this.nameField.setText(clsName.replace(File.separatorChar, '.'));
            this.application.clearOutput();
        }
    }

    public void saveSettings()
            throws LoaderException {
        Settings settings = this.application.getSettings();
        settings.setTestClassDirectory(this.directory);
        settings.setTestClass(this.nameField.getText());
    }
}
