package org.jwalk.tool;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import org.jwalk.JWalkException;

public abstract class AbstractDialog extends JDialog {

    protected JWalkTester application;

    public AbstractDialog(JWalkTester tester, String title) {
        super(tester, title, true);
        this.application = tester;
    }

    protected JPanel createExitDialogPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(1));
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event) {
                AbstractDialog.this.saveSettings(true);
            }
        });
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event) {
                AbstractDialog.this.saveSettings(false);
            }
        });
        panel.add(okButton);
        panel.add(cancelButton);
        return panel;
    }

    protected abstract void saveSettings(boolean paramBoolean);

    protected void logException(JWalkException ex) {
        System.err.println(ex);
        Throwable cause = ex.getCause();
        while (cause != null) {
            System.err.println("Cause: " + cause);
            cause = cause.getCause();
        }
    }
}
