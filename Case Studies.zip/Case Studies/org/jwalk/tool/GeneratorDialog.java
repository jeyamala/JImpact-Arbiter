package org.jwalk.tool;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileFilter;
import org.jwalk.LoaderException;
import org.jwalk.Settings;

public class GeneratorDialog extends AbstractDialog {

    private static final int DIALOG_WIDTH = 320;
    private static final int DIALOG_HEIGHT = 280;
    private static final String emptyString = "<empty>";
    private File directory = null;
    private JTextField rootField;
    private JTextField nameField;
    private JList generatorList;

    public GeneratorDialog(JWalkTester tester) {
        super(tester, "JWalk Custom Generators");

        setDefaultCloseOperation(2);
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setMinimumSize(new Dimension(320, 280));
        setLayout(new BoxLayout(getContentPane(), 1));
        setLocationRelativeTo(tester);
        add(createGeneratorFinderPanel());
        add(createGeneratorChooserPanel());
        add(createExitDialogPanel());
        pack();
    }

    private JPanel createGeneratorFinderPanel() {
        Settings settings = this.application.getSettings();
        this.directory = settings.getOracleDirectory();
        JPanel panel = new JPanel(new GridLayout(4, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Generator"));

        this.rootField = new JTextField();
        this.rootField.setText(this.directory.getAbsolutePath());
        this.rootField.setEditable(false);
        this.rootField.setToolTipText("The directory for loading custom generators");

        JButton rootButton = new JButton("Browse");
        rootButton.setToolTipText("Browse to select the custom generator directory");
        rootButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event) {
                GeneratorDialog.this.browseForGenerator(true);
            }
        });
        JPanel rootPanel = new JPanel();
        rootPanel.setLayout(new BoxLayout(rootPanel, 0));
        rootPanel.add(this.rootField);
        rootPanel.add(rootButton);
        panel.add(new JLabel(" Location: "));
        panel.add(rootPanel);

        this.nameField = new JTextField();
        this.nameField.setEditable(true);
        this.nameField.setToolTipText("Enter the (qualified) name of the generator");
        JButton nameButton = new JButton("Browse");
        nameButton.setToolTipText("Browse within a package for the generator");
        nameButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event) {
                GeneratorDialog.this.browseForGenerator(false);
            }
        });
        JPanel namePanel = new JPanel();
        namePanel.setLayout(new BoxLayout(namePanel, 0));
        namePanel.add(this.nameField);
        namePanel.add(nameButton);
        panel.add(new JLabel(" Name: "));
        panel.add(namePanel);
        return panel;
    }

    private JPanel createGeneratorChooserPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Custom Generators"));

        JPanel addRemovePanel = new JPanel(new FlowLayout(1));
        JButton addButton = new JButton("Add");
        addButton.setToolTipText(
                "Add the selected generator to the custom generators");
        addButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event) {
                GeneratorDialog.this.addGenerator(GeneratorDialog.this.nameField.getText());
            }
        });
        JButton removeButton = new JButton("Remove");
        removeButton.setToolTipText(
                "Remove the selected generator from the custom generators");
        removeButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event) {
                GeneratorDialog.this.removeGenerator(GeneratorDialog.this.nameField.getText());
            }
        });
        addRemovePanel.add(addButton);
        addRemovePanel.add(removeButton);
        panel.add(addRemovePanel);

        JPanel listPanel = new JPanel(new GridLayout(1, 1));
        listPanel.setBorder(BorderFactory.createEtchedBorder());
        DefaultListModel model = new DefaultListModel();
        model.addElement("<empty>");
        this.generatorList = new JList(model);
        this.generatorList.setBackground(Color.WHITE);
        this.generatorList.setSelectionMode(0);
        Settings settings = this.application.getSettings();
        for (Class generator : settings.getCustomGenerators()) {
            addGenerator(generator.getName());
        }
        this.generatorList.setModel(model);
        this.generatorList.addListSelectionListener(new ListSelectionListener() {

            public void valueChanged(ListSelectionEvent event) {
                if (!event.getValueIsAdjusting()) {
                    GeneratorDialog.this.selectGenerator();
                }
            }
        });
        listPanel.add(this.generatorList);
        panel.add(listPanel);
        return panel;
    }

    private void browseForGenerator(boolean isRoot) {
        JFileChooser chooser = new JFileChooser(this.directory);
        chooser.setFileSelectionMode(2);
        chooser.setFileFilter(new FileFilter() {

            public boolean accept(File f) {
                return (f.isDirectory())
                        || (f.getName().endsWith("Generator.class"));
            }

            public String getDescription() {
                return "Folders and JWalk generators";
            }
        });
        int result = chooser.showOpenDialog(this);
        if (result == 0) {
            File selected = chooser.getSelectedFile();
            if ((this.directory == null) || (isRoot)) {
                if (selected.isDirectory()) {
                    this.directory = selected;
                } else {
                    this.directory = chooser.getCurrentDirectory();
                }
            }
            String dirName = this.directory.getAbsolutePath();
            String clsName = selected.getAbsolutePath();

            if ((selected.isFile()) && (clsName.contains(dirName))) {
                clsName = clsName.substring(dirName.length() + 1);
                clsName = clsName.substring(0, clsName.indexOf(".class"));
            } else {
                clsName = "";
            }
            this.rootField.setText(dirName);
            this.nameField.setText(clsName.replace(File.separatorChar, '.'));
        }
    }

    private void addGenerator(String name) {
        if (name.endsWith("Generator")) {
            DefaultListModel model = (DefaultListModel) this.generatorList.getModel();
            if (model.contains("<empty>")) {
                model.removeElement("<empty>");
            }
            if (!model.contains(name)) {
                model.addElement(name);
            }
            this.generatorList.setModel(model);
            pack();
        }
    }

    private void removeGenerator(String name) {
        if (name.endsWith("Generator")) {
            DefaultListModel model = (DefaultListModel) this.generatorList.getModel();
            model.removeElement(name);
            if (model.size() == 0) {
                model.addElement("<empty>");
            }
            this.generatorList.setModel(model);
            pack();
        }
    }

    private void selectGenerator() {
        int index = this.generatorList.getSelectedIndex();

        if (index != -1) {
            DefaultListModel model = (DefaultListModel) this.generatorList.getModel();
            String selection = (String) model.get(index);
            if (selection != "<empty>") {
                this.nameField.setText(selection);
            }
        }
    }

    protected void saveSettings(boolean okClicked) {
        boolean closeOnExit = true;
        if (okClicked) {
            Settings settings = this.application.getSettings();
            settings.setGeneratorDirectory(this.directory);

            DefaultListModel model = (DefaultListModel) this.generatorList.getModel();
            List newNames = new ArrayList();
            for (Object object : model.toArray()) {
                if (object != "<empty>") {
                    newNames.add((String) object);
                }
            }
            List<String> oldNames = new ArrayList();
            for (Class generator : settings.getCustomGenerators()) {
                oldNames.add(generator.getName());
            }
            for (String oldName : oldNames) {
                if (!newNames.contains(oldName)) {
                    settings.removeCustomGenerator(oldName);
                }
            }
            try {
                Iterator iter;
                for (iter = newNames.iterator(); iter.hasNext();) {
                    String newName = (String) iter.next();
                    if (!oldNames.contains(newName)) {
                        settings.addCustomGenerator(newName);
                    }
                }
            } catch (LoaderException ex) {
                closeOnExit = false;
                handleLoaderException(ex);
            }
        }
        if (closeOnExit) {
            setVisible(false);
            dispose();
        }
    }

    private void handleLoaderException(LoaderException ex) {
        if (ex.classNotFound()) {
            JOptionPane.showMessageDialog(this.application,
                    "A custom generator could not be found. \nPlease check each generator's location and \nthe spelling of each generator's name. ",
                    "JWalk Error",
                    0);
        }
        if (ex.classNotQualified()) {
            JOptionPane.showMessageDialog(this.application,
                    "A custom generator could not be loaded. \nPlease change the location and load each \ngenerator using its package-qualified name. ",
                    "JWalk Error",
                    0);
        }

        logException(ex);
    }
}
