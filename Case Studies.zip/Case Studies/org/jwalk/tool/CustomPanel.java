package org.jwalk.tool;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

public class CustomPanel extends AbstractPanel {

    public CustomPanel(JWalkTester tester) {
        super(tester);
        setLayout(new GridLayout(1, 2));
        setBorder(BorderFactory.createTitledBorder("Custom Settings"));

        JButton genButton = new JButton("Generators");
        genButton.setToolTipText("Add or remove custom test input generators");
        genButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(ActionEvent event) {
                        CustomPanel.this.openGeneratorDialog();
                    }
                });
        JButton confButton = new JButton("Configuration");
        confButton.setToolTipText("Change the basic configuration of JWalk");
        confButton.addActionListener(
                new ActionListener() {

                    public void actionPerformed(ActionEvent event) {
                        CustomPanel.this.openConfigureDialog();
                    }
                });
        JPanel genPanel = new JPanel();
        genPanel.setLayout(new FlowLayout(1, 0, 0));
        genPanel.add(genButton);
        JPanel confPanel = new JPanel();
        confPanel.setLayout(new FlowLayout(1, 0, 0));
        confPanel.add(confButton);
        add(genPanel);
        add(confPanel);
    }

    private void openConfigureDialog() {
        ConfigureDialog dialog = new ConfigureDialog(this.application);
        dialog.setVisible(true);
    }

    private void openGeneratorDialog() {
        GeneratorDialog dialog = new GeneratorDialog(this.application);
        dialog.setVisible(true);
    }
}
