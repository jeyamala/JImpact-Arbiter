package org.jwalk.tool;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.io.PrintStream;
import java.lang.reflect.Member;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JViewport;
import javax.swing.UIManager;
import org.jwalk.Channels;
import org.jwalk.Error;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;
import org.jwalk.JWalkException;
import org.jwalk.JWalker;
import org.jwalk.LoaderException;
import org.jwalk.PermissionException;
import org.jwalk.Settings;
import org.jwalk.SettingsException;

public class JWalkTester extends JFrame
        implements Thread.UncaughtExceptionHandler {

    private static final int MAIN_VIEWER_WIDTH = 800;
    private static final int MAIN_VIEWER_HEIGHT = 550;
    private static final int INPUT_PANEL_WIDTH = 320;
    private static final int INPUT_PANEL_HEIGHT = 490;
    private static final int OUTPUT_PANEL_ROWS = 30;
    private static final int OUTPUT_PANEL_COLS = 50;
    private static final String iconPath = "/org/jwalk/tool/minimizeJimbo.gif";
    private static final String splashText = "<html><h3>JWalk Tester</h3><hr>Version 1.1 (c) 2011, Anthony J H Simons<br><br>Department of Computer Science<br>University of Sheffield<br><br>Harness the power of lazy systematic unit testing and grow<br> test oracles for your Java classes, by walking through each<br> class as it evolves.  Save time writing difficult test cases and<br> rely on the systematic testing engine to discover all those<br> interleaved cases developers usually forget.</html>";
    private static final String helpText = "<html><h3>Quick Start</h3><hr>Navigate to the working directory, from which you launch<br>Java to execute your chosen test class;<br><br>Select the test class here, or navigate further into the<br>package owning the test class to find it;<br><br>Select a strategy to explore the method protocols, algebraic<br>constructions, or high-level state space;<br><br>Select a modality to inspect the class, explore its behaviour<br>or validate its behaviour against an oracle;<br><br>Select the maximum depth for generated test sequences;<br><br>Click on 'JWalking Jimbo' to start the test engine.</html>";
    private JWalker walker;
    private int[] memory;
    private ClassFinderPanel finderPanel;
    private TestSettingsPanel settingsPanel;
    private TestExecutePanel executePanel;
    private JTabbedPane outputPanel;

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,
                    "Cannot install platform look-and-feel;\nreverting to standard look-and-feel.",
                    "JWalk Warning", 0);
        }
        JWalkTester viewer = new JWalkTester();
        Thread.setDefaultUncaughtExceptionHandler(viewer);
        viewer.setVisible(true);
    }

    public JWalkTester() {
        this.walker = new JWalker();
        Channels channels = this.walker.getChannels();
        channels.addQuestionListener(new QuestionMaster(this));
        channels.addReportListener(new ReportPublisher(this));

        setLayout(new BorderLayout());
        add(createInputPanel(), "West");
        add(createOutputPanel(), "Center");
        setDefaultCloseOperation(3);
        setTitle("JWalk Tester");
        setSize(800, 550);

        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/org/jwalk/tool/minimizeJimbo.gif")));
        setLocationRelativeTo(null);
        setResizable(true);
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, 1));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setPreferredSize(
                new Dimension(320, 490));

        panel.add(this.finderPanel = new ClassFinderPanel(this));
        panel.add(this.settingsPanel = new TestSettingsPanel(this));
        panel.add(this.executePanel = new TestExecutePanel(this));
        panel.add(new CustomPanel(this));
        JPanel inputPanel = new JPanel(new FlowLayout(3));
        inputPanel.add(panel);
        return inputPanel;
    }

    private JTabbedPane createOutputPanel() {
        this.outputPanel = new JTabbedPane(0, 0);
        addAboutInfo();
        addHelpInfo();
        return this.outputPanel;
    }

    private void addAboutInfo() {
        JLabel about = new JLabel("<html><h3>JWalk Tester</h3><hr>Version 1.1 (c) 2011, Anthony J H Simons<br><br>Department of Computer Science<br>University of Sheffield<br><br>Harness the power of lazy systematic unit testing and grow<br> test oracles for your Java classes, by walking through each<br> class as it evolves.  Save time writing difficult test cases and<br> rely on the systematic testing engine to discover all those<br> interleaved cases developers usually forget.</html>");
        JPanel infoPanel = new JPanel(new FlowLayout(3, 20, 0));
        infoPanel.setBackground(Color.WHITE);
        infoPanel.add(about);
        this.outputPanel.addTab("About JWalk", null, infoPanel,
                "JWalk splash screen with version information");
    }

    private void addHelpInfo() {
        JLabel help = new JLabel("<html><h3>Quick Start</h3><hr>Navigate to the working directory, from which you launch<br>Java to execute your chosen test class;<br><br>Select the test class here, or navigate further into the<br>package owning the test class to find it;<br><br>Select a strategy to explore the method protocols, algebraic<br>constructions, or high-level state space;<br><br>Select a modality to inspect the class, explore its behaviour<br>or validate its behaviour against an oracle;<br><br>Select the maximum depth for generated test sequences;<br><br>Click on 'JWalking Jimbo' to start the test engine.</html>");
        JPanel helpPanel = new JPanel(new FlowLayout(3, 20, 0));
        helpPanel.setBackground(Color.WHITE);
        helpPanel.add(help);
        this.outputPanel.addTab("JWalk Help", null, helpPanel,
                "Would you like some help to get started?");
    }

    public Settings getSettings() {
        return this.walker.getSettings();
    }

    public void clearOutput() {
        this.outputPanel.removeAll();
        addHelpInfo();
        addAboutInfo();
    }

    public void addOutput(String title, String content) {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setVerticalScrollBarPolicy(
                20);
        scrollPane.setHorizontalScrollBarPolicy(
                30);
        JLabel padding = new JLabel("   ");
        JTextArea textArea = new JTextArea(20, 20);
        textArea.setFont(new Font("SansSerif", 0, 12));
        textArea.setEditable(false);
        textArea.setLineWrap(false);
        textArea.append(content);
        scrollPane.setRowHeaderView(padding);
        scrollPane.setViewportView(textArea);
        scrollPane.getRowHeader().setBackground(Color.WHITE);
        scrollPane.getViewport().setBackground(Color.WHITE);
        this.outputPanel.addTab(title, null, scrollPane,
                "Select and view test results");
    }

    public void executeTests() {
        try {
            this.executePanel.setEnabled(false);
            this.outputPanel.removeAll();
            this.finderPanel.saveSettings();
            this.settingsPanel.saveSettings();

            this.memory = new int[1048576];

            Thread worker = new Thread(this.walker);
            worker.setPriority(2);
            worker.start();
        } catch (JWalkException ex) {
            handleException(ex);
        }
    }

    public void finishedTests() {
        this.executePanel.setEnabled(true);
    }

    public void interruptTests() {
        this.walker.getChannels().setUserAborted();
    }

    public void handleException(JWalkException ex) {
        Error error = ex.getError();
        switch (error) {
            case EXECUTION_ERROR:
                loaderException((LoaderException) ex);
                break;
            case GENERATOR_ERROR:
                settingsException((SettingsException) ex);
                break;
            case LOADER_ERROR:
                permissionsException((PermissionException) ex);
                break;
            case PERMISSION_ERROR:
                generatorException((GeneratorException) ex);
                break;
            case SETTINGS_ERROR:
                executionException((ExecutionException) ex);
                break;
            default:
                logException(Thread.currentThread(), ex);
        }
        finishedTests();
    }

    public void uncaughtException(Thread thread, Throwable thrown) {
        this.memory = null;
        if ((thrown instanceof OutOfMemoryError)) {
            this.walker.getChannels().setOutOfMemory();
            Thread.yield();
            if (thread.getName().startsWith("Image")) {
                this.executePanel.restart();
            }
        } else {
            this.walker.getChannels().setUserAborted();
            Thread.yield();
            String message = thrown.getMessage();
            JOptionPane.showMessageDialog(this,
                    "JWalk encountered an unexpected exception:\n" + (message == null ? thrown.toString() : message),
                    "Fatal Error",
                    0);
        }

        logException(thread, thrown);
    }

    private void loaderException(LoaderException ex) {
        addHelpInfo();
        if (ex.classNotFound()) {
            JOptionPane.showMessageDialog(this,
                    "The test class could not be found. \nPlease check the location and the \nspelling of the test class's name. ",
                    "JWalk Error",
                    0);
        }
        if (ex.classNotQualified()) {
            JOptionPane.showMessageDialog(this,
                    "The test class could not be loaded. \nPlease change the location and load \nusing a package-qualified class name. ",
                    "JWalk Error",
                    0);
        }

        logException(Thread.currentThread(), ex);
    }

    private void settingsException(SettingsException ex) {
        if (ex.enumConversionFailed()) {
            JOptionPane.showMessageDialog(this,
                    "The user-supplied test setting: " + ex.getValue()
                    + " \ncould not be converted into an enum constant. \n"
                    + "Please supply a canonical string in uppercase.",
                    "JWalk Error",
                    0);
        }
        if (ex.intConversionFailed()) {
            JOptionPane.showMessageDialog(this,
                    "The user-supplied test setting: " + ex.getValue()
                    + " \ncould not be converted into an int value. \n"
                    + "Please supply a string consisting only of digits. ",
                    "JWalk Error",
                    0);
        }

        logException(Thread.currentThread(), ex);
    }

    private void permissionsException(PermissionException ex) {
        if (ex.testClassRefused()) {
            JOptionPane.showMessageDialog(this,
                    "Permission was refused to create and \nexecute the test class: "
                    + ex.getType().getSimpleName()
                    + ". \nIs it non-public, abstract or an interface? ",
                    "JWalk Error",
                    0);
        }
        if (ex.generatorRefused()) {
            JOptionPane.showMessageDialog(this,
                    "Permission was refused to instantiate \nthe custom generator: "
                    + ex.getType().getSimpleName()
                    + ". \nDoes it have a public default constructor? ",
                    "JWalk Error",
                    0);
        }

        logException(Thread.currentThread(), ex);
    }

    private void generatorException(GeneratorException ex) {
        if (ex.creationFailed()) {
            JOptionPane.showMessageDialog(this,
                    "No test input could be synthesised for \nthe parameter type: "
                    + ex.getType().getSimpleName()
                    + ". \nPlease supply a custom generator. ",
                    "JWalk Error",
                    0);
        }
        if (ex.generatorFailed()) {
            JOptionPane.showMessageDialog(this,
                    ex.getGenerator().getClass().getSimpleName()
                    + " failed while synthesising \n"
                    + "a value for the parameter type: "
                    + ex.getType().getSimpleName()
                    + ". \nPlease check and repair the generator. ",
                    "JWalk Error",
                    0);
        }

        logException(Thread.currentThread(), ex);
    }

    private void executionException(ExecutionException ex) {
        if (ex.invocationFailed()) {
            JOptionPane.showMessageDialog(this,
                    "An illegal attempt was made to invoke \nthe operation: "
                    + ex.getOperation().getName() + ".  \n"
                    + "Check visibility, security and arguments. ",
                    "JWalk Error",
                    0);
        }
        if (ex.executionFailed()) {
            JOptionPane.showMessageDialog(this,
                    "The operation: " + ex.getOperation().getName()
                    + " \nfailed randomly. Please ensure that \n"
                    + " it behaves in a deterministic way. ",
                    "JWalk Error",
                    0);
        }

        logException(Thread.currentThread(), ex);
    }

    private void logException(Thread thread, Throwable thrown) {
        System.err.println(thread + ": " + thrown);
        Throwable cause = thrown.getCause();
        while (cause != null) {
            System.err.println("Cause: " + cause);
            cause = cause.getCause();
        }
    }
}
