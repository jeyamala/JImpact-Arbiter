package org.jwalk.tool;

import org.jwalk.ReportEvent;
import org.jwalk.ReportListener;
import org.jwalk.out.AlgebraReport;
import org.jwalk.out.CycleReport;
import org.jwalk.out.Edition;
import org.jwalk.out.ProtocolReport;
import org.jwalk.out.Report;
import org.jwalk.out.StateReport;
import org.jwalk.out.SummaryReport;

public class ReportPublisher
        implements ReportListener {

    private JWalkTester application;

    public ReportPublisher(JWalkTester tester) {
        this.application = tester;
    }

    public void publish(ReportEvent event) {
        Report report = event.getReport();
        Edition edition = report.getEdition();
        switch (edition) {
            case ALGEBRA_REPORT:
                handle((ProtocolReport) report);
                break;
            case CONFIRM_DIALOG:
                handle((AlgebraReport) report);
                break;
            case CYCLE_REPORT:
                handle((StateReport) report);
                break;
            case NOTIFY_DIALOG:
                handle((CycleReport) report);
                break;
            case PROTOCOL_REPORT:
                handle((SummaryReport) report);
                break;
        }
    }

    protected void handle(ProtocolReport report) {
        String title = report.toString(report.getTestClass())
                + " Protocol Analysis";
        this.application.addOutput(title, report.getContent());
    }

    protected void handle(AlgebraReport report) {
        String title = report.toString(report.getTestClass())
                + " Algebraic Analysis";
        this.application.addOutput(title, report.getContent());
    }

    protected void handle(StateReport report) {
        String title = report.toString(report.getTestClass())
                + " State Space Analysis";
        this.application.addOutput(title, report.getContent());
    }

    protected void handle(CycleReport report) {
        String state = report.getStartingState();
        String title = "Test Cycle #" + report.getTestCycle();
        if (state != null) {
            title = state + ": " + title;
        }
        this.application.addOutput(title, report.getContent());
    }

    protected void handle(SummaryReport report) {
        String title = report.toString(report.getTestClass())
                + " Test Summary";
        this.application.addOutput(title, report.getContent());
    }
}
