package org.jwalk.tool;

import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import org.jwalk.Modality;
import org.jwalk.Settings;
import org.jwalk.SettingsException;
import org.jwalk.Strategy;

public class TestSettingsPanel extends AbstractPanel {

    private JComboBox strategyBox;
    private JComboBox modalityBox;
    private JSpinner depthSpinner;

    public TestSettingsPanel(JWalkTester tester) {
        super(tester);
        setLayout(new GridLayout(3, 2));
        setBorder(BorderFactory.createTitledBorder("Test Settings"));
        Settings settings = this.application.getSettings();

        add(new JLabel(" Strategy: "));
        this.strategyBox = new JComboBox(Strategy.values());
        this.strategyBox.setSelectedItem(settings.getStrategy());
        this.strategyBox.setToolTipText("Select the desired test strategy");
        add(this.strategyBox);

        add(new JLabel(" Modality: "));
        this.modalityBox = new JComboBox(Modality.values());
        this.modalityBox.setSelectedItem(settings.getModality());
        this.modalityBox.setToolTipText("Select the desired test modality");
        add(this.modalityBox);

        add(new JLabel(" Test Depth: "));
        this.depthSpinner = new JSpinner(new SpinnerNumberModel(
                settings.getTestDepth(), 0, 20, 1));
        this.depthSpinner.setToolTipText("Select the maximum length of test sequences");
        add(this.depthSpinner);
    }

    public void saveSettings()
            throws SettingsException {
        Settings settings = this.application.getSettings();
        Object value = null;
        try {
            value = this.strategyBox.getSelectedItem();
            settings.setStrategy((Strategy) value);
            value = this.modalityBox.getSelectedItem();
            settings.setModality((Modality) value);
        } catch (ClassCastException badConversion) {
            SettingsException ex = new SettingsException(value);
            ex.initCause(badConversion);
            throw ex;
        }
        try {
            value = this.depthSpinner.getValue();
            settings.setTestDepth(((Integer) value).intValue());
        } catch (ClassCastException badConversion) {
            SettingsException ex = new SettingsException(value, true);
            ex.initCause(badConversion);
            throw ex;
        }
    }
}
