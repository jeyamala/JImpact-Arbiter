package org.jwalk.tool;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.filechooser.FileFilter;
import org.jwalk.Convention;
import org.jwalk.Settings;
import org.jwalk.SettingsException;

public class ConfigureDialog extends AbstractDialog {

    private static final int DIALOG_WIDTH = 320;
    private static final int DIALOG_HEIGHT = 280;
    private File directory = null;
    private JTextField rootField;
    private JComboBox conventionBox;
    private JSpinner probeSpinner;
    private JSpinner stateSpinner;

    public ConfigureDialog(JWalkTester tester) {
        super(tester, "JWalk Custom Settings");
        setDefaultCloseOperation(2);
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setMinimumSize(new Dimension(320, 280));
        setLayout(new BoxLayout(getContentPane(), 1));
        setLocationRelativeTo(tester);
        add(createOracleFinderPanel());
        add(createCustomSettingsPanel());
        add(createExitDialogPanel());
        pack();
    }

    private JPanel createOracleFinderPanel() {
        Settings settings = this.application.getSettings();
        this.directory = settings.getOracleDirectory();
        JPanel panel = new JPanel(new GridLayout(2, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Test Oracles"));

        this.rootField = new JTextField();
        this.rootField.setText(this.directory.getAbsolutePath());
        this.rootField.setEditable(false);
        this.rootField.setToolTipText("The directory for loading and saving test oracles");

        JButton rootButton = new JButton("Browse");
        rootButton.setToolTipText("Browse to select the test oracle directory");
        rootButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event) {
                ConfigureDialog.this.browseForOracle();
            }
        });
        JPanel rootPanel = new JPanel();
        rootPanel.setLayout(new BoxLayout(rootPanel, 0));
        rootPanel.add(this.rootField);
        rootPanel.add(rootButton);
        panel.add(new JLabel(" Location: "));
        panel.add(rootPanel);
        return panel;
    }

    private JPanel createCustomSettingsPanel() {
        Settings settings = this.application.getSettings();
        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.setBorder(BorderFactory.createTitledBorder("Configuration"));

        panel.add(new JLabel(" Convention: "));
        this.conventionBox = new JComboBox(Convention.values());
        this.conventionBox.setSelectedItem(settings.getConvention());
        this.conventionBox.setToolTipText(
                "Select the convention on including Object's methods");
        panel.add(this.conventionBox);

        panel.add(new JLabel(" Probe Depth: "));
        this.probeSpinner = new JSpinner(new SpinnerNumberModel(
                settings.getProbeDepth(), 0, 20, 1));
        this.probeSpinner.setToolTipText(
                "Select the maximum length of probe sequences");
        panel.add(this.probeSpinner);

        panel.add(new JLabel(" State Depth: "));
        this.stateSpinner = new JSpinner(new SpinnerNumberModel(
                settings.getTreeDepth(), 0, 5, 1));
        this.stateSpinner.setToolTipText(
                "Select the object tree-depth for state comparison");
        panel.add(this.stateSpinner);
        return panel;
    }

    private void browseForOracle() {
        JFileChooser chooser = new JFileChooser(this.directory);
        chooser.setFileSelectionMode(2);
        chooser.setFileFilter(new FileFilter() {

            public boolean accept(File f) {
                return (f.isDirectory()) || (f.getName().endsWith(".jwk"));
            }

            public String getDescription() {
                return "Folders and JWalk test oracles";
            }
        });
        int result = chooser.showOpenDialog(this);
        if (result == 0) {
            File selected = chooser.getSelectedFile();
            if (selected.isDirectory()) {
                this.directory = selected;
            } else {
                this.directory = selected.getParentFile();
            }
            String dirName = this.directory.getAbsolutePath();
            this.rootField.setText(dirName);
        }
    }

    protected void saveSettings(boolean okClicked) {
        boolean closeOnExit = true;
        if (okClicked) {
            Settings settings = this.application.getSettings();
            settings.setOracleDirectory(this.directory);
            Object value = null;
            try {
                value = this.conventionBox.getSelectedItem();
                settings.setConvention((Convention) value);
            } catch (ClassCastException badConversion) {
                closeOnExit = false;
                SettingsException ex = new SettingsException(value);
                ex.initCause(badConversion);
                handleSettingsException(ex);
            }
            try {
                value = this.probeSpinner.getValue();
                settings.setProbeDepth(((Integer) value).intValue());
                value = this.stateSpinner.getValue();
                settings.setTreeDepth(((Integer) value).intValue());
            } catch (ClassCastException badConversion) {
                closeOnExit = false;
                SettingsException ex = new SettingsException(value, true);
                ex.initCause(badConversion);
                handleSettingsException(ex);
            }
        }
        if (closeOnExit) {
            setVisible(false);
            dispose();
        }
    }

    private void handleSettingsException(SettingsException ex) {
        if (ex.enumConversionFailed()) {
            JOptionPane.showMessageDialog(this,
                    "The user-supplied test setting: " + ex.getValue()
                    + " \ncould not be converted into an enum constant. \n"
                    + "Please supply a canonical string in uppercase.",
                    "JWalk Error",
                    0);
        }
        if (ex.intConversionFailed()) {
            JOptionPane.showMessageDialog(this,
                    "The user-supplied test setting: " + ex.getValue()
                    + " \ncould not be converted into an int value. \n"
                    + "Please supply a string consisting only of digits. ",
                    "JWalk Error",
                    0);
        }

        logException(ex);
    }
}
