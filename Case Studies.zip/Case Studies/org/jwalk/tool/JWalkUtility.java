package org.jwalk.tool;

import java.io.PrintStream;
import org.jwalk.Convention;
import org.jwalk.JWalker;
import org.jwalk.Modality;
import org.jwalk.Settings;
import org.jwalk.SettingsException;
import org.jwalk.Strategy;

public class JWalkUtility {

    public static void main(String[] args) {
        StringBuilder splash = new StringBuilder();
        splash.append("\t**************************************************\n");
        splash.append("\t*                                                *\n");
        splash.append("\t*  JWalk - a lazy, systematic class unit tester  *\n");
        splash.append("\t*      v1.1 (c) 2011, Anthony J H Simons         *\n");
        splash.append("\t*                                                *\n");
        splash.append("\t*         Department of Computer Science         *\n");
        splash.append("\t*          University of Sheffield, UK.          *\n");
        splash.append("\t*                                                *\n");
        splash.append("\t**************************************************\n");

        StringBuilder usage = new StringBuilder();
        usage.append("JWalkUtility: command line usage is :-\n\n");
        usage.append("    java org.jwalk.tool.JWalkUtility <testClass>\n\t[<strategy> | <modality> | <testDepth> | <generator>\n\t    | <convention> | <probeDepth> | <stateDepth>]*\n\n");

        usage.append("<testClass> ::= the name of the test class (mandatory)\n");
        usage.append("<strategy> ::= [protocol | algebra | states] (default = algebra)\n");
        usage.append("<modality> ::= [inspect | explore | validate] (default = explore)\n");
        usage.append("<convention> ::= [standard | custom | complete] (default = standard)\n");
        usage.append("<testDepth> ::= [t]0..n, length limit for test sequences (default = 3)\n");
        usage.append("<probeDepth> ::= p0..n, length limit for probe sequences (default = 12)\n");
        usage.append("<stateDepth> ::= s0..n, tree depth for state comparison (default = 0)\n");
        usage.append("<generator> ::= the name of a custom input generator (optional)\n");

        System.out.println(splash);
        if (args.length == 0) {
            System.out.println(usage);
        } else {
            try {
                JWalker walker = new JWalker();
                Settings settings = walker.getSettings();
                for (int i = 0; i < args.length; i++) {
                    String parameter = args[i];
                    if (i == 0) {
                        settings.setTestClass(parameter);
                    } else if (parameter.endsWith("Generator")) {
                        settings.addCustomGenerator(parameter);
                    } else if (Character.isDigit(parameter.charAt(0))) {
                        try {
                            int depth = Integer.parseInt(parameter);
                            settings.setTestDepth(depth);
                        } catch (NumberFormatException ex) {
                            throw new SettingsException(parameter, true);
                        }
                    } else if (Character.isDigit(parameter.charAt(1))) {
                        try {
                            int depth = Integer.parseInt(parameter.substring(1));
                            switch (parameter.charAt(0)) {
                                case 'p':
                                    settings.setProbeDepth(depth);
                                    break;
                                case 's':
                                    settings.setTreeDepth(depth);
                                    break;
                                case 't':
                                    settings.setTestDepth(depth);
                                    break;
                                case 'q':
                                case 'r':
                                default:
                                    throw new SettingsException(parameter, true);
                            }
                        } catch (NumberFormatException ex) {
                            throw new SettingsException(parameter, true);
                        }
                    } else if (parameter.equals("protocol")) {
                        settings.setStrategy(Strategy.PROTOCOL);
                    } else if (parameter.equals("algebra")) {
                        settings.setStrategy(Strategy.ALGEBRA);
                    } else if (parameter.equals("states")) {
                        settings.setStrategy(Strategy.STATES);
                    } else if (parameter.equals("inspect")) {
                        settings.setModality(Modality.INSPECT);
                    } else if (parameter.equals("explore")) {
                        settings.setModality(Modality.EXPLORE);
                    } else if (parameter.equals("validate")) {
                        settings.setModality(Modality.VALIDATE);
                    } else if (parameter.equals("standard")) {
                        settings.setConvention(Convention.STANDARD);
                    } else if (parameter.equals("custom")) {
                        settings.setConvention(Convention.CUSTOM);
                    } else if (parameter.equals("complete")) {
                        settings.setConvention(Convention.COMPLETE);
                    } else {
                        throw new SettingsException(parameter);
                    }
                }
                walker.execute();
            } catch (Exception ex) {
                System.err.println("JWalk terminated for the following reason:\n");
                System.err.println(ex);
                Throwable cause = ex.getCause();
                while (cause != null) {
                    System.err.println("Cause: " + cause);
                    cause = cause.getCause();
                }
            }
        }
    }
}
