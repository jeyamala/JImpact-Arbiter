package org.jwalk.tool;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TestExecutePanel extends AbstractPanel {

    private static final String standingPath = "/org/jwalk/tool/standingJimbo.gif";
    private static final String steppingPath = "/org/jwalk/tool/steppingJimbo.gif";
    private static final String walkingPath = "/org/jwalk/tool/walkingJimbo.gif";
    private JButton walkerButton;
    private JButton cancelButton;

    public TestExecutePanel(JWalkTester tester) {
        super(tester);
        setLayout(new GridLayout(1, 2));
        setBorder(BorderFactory.createTitledBorder("Test Execution"));

        ImageIcon standingIcon = new ImageIcon(
                getClass().getResource("/org/jwalk/tool/standingJimbo.gif"));
        ImageIcon steppingIcon = new ImageIcon(
                getClass().getResource("/org/jwalk/tool/steppingJimbo.gif"));
        ImageIcon walkingIcon = new ImageIcon(
                getClass().getResource("/org/jwalk/tool/walkingJimbo.gif"));

        this.walkerButton = new JButton(standingIcon);
        this.walkerButton.setBackground(Color.WHITE);
        this.walkerButton.setPressedIcon(walkingIcon);
        this.walkerButton.setRolloverIcon(steppingIcon);
        this.walkerButton.setDisabledIcon(walkingIcon);
        this.walkerButton.setToolTipText("Run the current test series");
        this.walkerButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event) {
                TestExecutePanel.this.application.executeTests();
            }
        });
        this.cancelButton = new JButton("Cancel");
        this.cancelButton.setToolTipText("Abort the current test series");
        this.cancelButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent event) {
                TestExecutePanel.this.application.interruptTests();
            }
        });
        this.cancelButton.setEnabled(false);

        JPanel labelPanel = new JPanel();
        labelPanel.setLayout(new FlowLayout(1, 0, 30));
        labelPanel.add(new JLabel(" Start JWalking! "));
        labelPanel.add(this.cancelButton);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(1, 0, 0));
        buttonPanel.add(this.walkerButton);

        add(labelPanel);
        add(buttonPanel);
    }

    public void setEnabled(boolean enabled) {
        synchronized (this) {
            super.setEnabled(enabled);
            this.walkerButton.setEnabled(enabled);
            this.cancelButton.setEnabled(!enabled);
        }
    }

    public void restart() {
        this.walkerButton.setPressedIcon(null);
        this.walkerButton.setDisabledIcon(null);
        ImageIcon walkingIcon = new ImageIcon(
                Toolkit.getDefaultToolkit().createImage(
                getClass().getResource("/org/jwalk/tool/walkingJimbo.gif")));
        this.walkerButton.setPressedIcon(walkingIcon);
        this.walkerButton.setDisabledIcon(walkingIcon);
    }
}
