package org.jwalk;

public enum Strategy {

    PROTOCOL,
    ALGEBRA,
    STATES;
}
