package org.jwalk;

public enum Error {

    LOADER_ERROR,
    SETTINGS_ERROR,
    PERMISSION_ERROR,
    GENERATOR_ERROR,
    EXECUTION_ERROR;
}
