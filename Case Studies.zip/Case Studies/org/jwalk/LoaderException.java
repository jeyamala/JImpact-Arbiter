package org.jwalk;

public class LoaderException extends JWalkException {

    private String name;
    private boolean qualify;

    public LoaderException(String name) {
        super("Could not find any class named: " + name,
                Error.LOADER_ERROR);
        this.name = name;
        this.qualify = false;
    }

    public LoaderException(String name, boolean qualify) {
        super("Incorrect package qualification for: " + name,
                Error.LOADER_ERROR);
        this.name = name;
        this.qualify = true;
    }

    public String getClassName() {
        return this.name;
    }

    public boolean classNotFound() {
        return !this.qualify;
    }

    public boolean classNotQualified() {
        return this.qualify;
    }
}
