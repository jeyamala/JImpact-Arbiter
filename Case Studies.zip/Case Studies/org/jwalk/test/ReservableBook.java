package org.jwalk.test;

public class ReservableBook extends LibraryBook {

    private String requester;

    public ReservableBook() {
        this.requester = null;
    }

    public void issue(String person)
            throws Exception {
        if ((this.requester != null) && (!person.equals(this.requester))) {
            throw new Exception("this book is reserved for another");
        }
        super.issue(person);
    }

    public void reserve(String person)
            throws Exception {
        if (this.requester != null) {
            throw new Exception("Book is already reserved");
        }
        this.requester = person;
    }

    public void cancel() {
        this.requester = null;
    }

    public String getRequester() {
        return this.requester;
    }

    public boolean isReserved() {
        return this.requester != null;
    }
}
