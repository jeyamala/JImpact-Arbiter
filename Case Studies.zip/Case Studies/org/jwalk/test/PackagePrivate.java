package org.jwalk.test;

class PackagePrivate {

    int value = 0;

    public PackagePrivate() {
        this.value = 5;
    }

    public int getValue() {
        return this.value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String toString() {
        return String.valueOf(this.value);
    }

    public int hashCode() {
        return this.value;
    }
}
