package org.jwalk.test;

public class LibraryBook {

    private String borrower;

    public LibraryBook() {
        this.borrower = null;
    }

    public void issue(String person)
            throws Exception {
        if (this.borrower != null) {
            throw new Exception("this book is already on loan");
        }
        this.borrower = person;
    }

    public void discharge() {
        this.borrower = null;
    }

    public String getBorrower() {
        return this.borrower;
    }

    public boolean isOnLoan() {
        return this.borrower != null;
    }
}
