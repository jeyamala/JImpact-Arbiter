package org.jwalk.test;

public abstract interface Interface {

    public abstract int getValue();

    public abstract void setValue(int paramInt);

    public abstract String toString();

    public abstract int hashCode();
}
