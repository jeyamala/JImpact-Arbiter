package org.jwalk.test;

public class StackProxy {

    private Stack stack;

    public StackProxy() {
        this.stack = new Stack();
    }

    public void push(Object item) {
        this.stack.push(item);
    }

    public void pop() {
        this.stack.pop();
    }

    public Object top() {
        return this.stack.top();
    }

    public int size() {
        return this.stack.size();
    }

    public boolean isEmpty() {
        return this.stack.isEmpty();
    }

    public boolean isFull() {
        return this.stack.isFull();
    }
}
