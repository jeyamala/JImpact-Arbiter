package org.jwalk.test;

public class Wallet {

    private int balance;

    public Wallet() {
        this.balance = 0;
    }

    public void payIn(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException(
                    "amount must be positive: " + amount);
        }
        this.balance += amount;
    }

    public boolean payOut(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException(
                    "amount must be positive: " + amount);
        }
        if (amount <= this.balance) {
            this.balance -= amount;
            return true;
        }

        return false;
    }

    public int money() {
        return this.balance;
    }

    public boolean isEmpty() {
        return this.balance == 0;
    }

    public boolean inCredit() {
        return this.balance > 0;
    }
}
