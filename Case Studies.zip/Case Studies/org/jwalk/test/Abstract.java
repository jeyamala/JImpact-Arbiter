package org.jwalk.test;

public abstract class Abstract {

    int value = 0;

    public Abstract() {
        this.value = 5;
    }

    public int getValue() {
        return this.value;
    }

    public abstract void setValue(int paramInt);

    public String toString() {
        return String.valueOf(this.value);
    }

    public int hashCode() {
        return this.value;
    }
}
