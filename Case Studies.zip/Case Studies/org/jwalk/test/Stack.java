package org.jwalk.test;

import java.util.EmptyStackException;

public class Stack {

    private static int CAPACITY = 5;
    private Object[] items;
    private int count;

    public Stack() {
        this.items = new Object[CAPACITY];
        this.count = 0;
    }

    public void push(Object item) {
        this.items[(this.count++)] = item;
    }

    public void pop() {
        if (this.count == 0) {
            throw new EmptyStackException();
        }
        this.items[(--this.count)] = null;
    }

    public Object top() {
        if (this.count == 0) {
            throw new EmptyStackException();
        }
        return this.items[(this.count - 1)];
    }

    public int size() {
        return this.count;
    }

    public boolean isEmpty() {
        return this.count == 0;
    }

    public boolean isFull() {
        return this.count == CAPACITY;
    }
}
