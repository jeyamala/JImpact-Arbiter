package org.jwalk.test;

import org.jwalk.out.Answer;

public class AnswerCycle {

    private Answer answer = Answer.QUIT;

    public AnswerCycle() {
        this.answer = Answer.QUIT;
    }

    public void setAnswer(Answer value) {
        this.answer = value;
    }

    public Answer getAnswer() {
        return this.answer;
    }
}
