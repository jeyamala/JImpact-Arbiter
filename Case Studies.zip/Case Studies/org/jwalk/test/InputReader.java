package org.jwalk.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class InputReader {

    private BufferedReader input;
    private String data;

    public InputReader() {
        this.input = new BufferedReader(
                new InputStreamReader(System.in));
    }

    public String getString()
            throws IOException {
        System.out.println("Enter a string: ");
        this.data = "hai";
        return this.data;
    }
}
