package org.jwalk;

import org.jwalk.core.AlgebraWalker;
import org.jwalk.core.ProtocolWalker;
import org.jwalk.core.StateInspector;
import org.jwalk.core.StateSpaceWalker;
import org.jwalk.core.TestCase;
import org.jwalk.out.Notification;

public class JWalker
        implements Runnable {

    protected Settings settings;
    protected Channels channels;

    public JWalker() {
        this.settings = new Settings();
        this.channels = new Channels();
    }

    protected JWalker(Settings settings, Channels channels) {
        this.settings = settings;
        this.channels = channels;
    }

    public Settings getSettings() {
        return this.settings;
    }

    public Channels getChannels() {
        return this.channels;
    }

    public Class<?> getTestClass() {
        return this.settings.getTestClass();
    }

    public void execute()
            throws PermissionException, GeneratorException, ExecutionException {
        JWalker walker = null;
        int x = this.settings.getStrategy().ordinal();
        switch (x) {
            case 1:
                walker = new ProtocolWalker(this.settings, this.channels);
                break;
            case 2:
                walker = new AlgebraWalker(this.settings, this.channels);
                break;
            case 3:
                walker = new StateSpaceWalker(this.settings, this.channels);
                break;
        }

        TestCase.setInspector(
                new StateInspector(this.settings.getTreeDepth()));
        walker.execute();
    }

    public void run() {
        try {
            execute();
            this.channels.dispatch(new Notification(this));
        } catch (JWalkException ex) {
            this.channels.dispatch(new Notification(this, ex));
        }
    }

    public boolean outOfMemory() {
        return this.channels.outOfMemory();
    }

    public boolean userAborted() {
        return this.channels.userAborted();
    }
}
