package org.jwalk;

public class GeneratorException extends JWalkException {

    private Class<?> type = null;
    private Generator generator = null;
    private boolean internal = false;

    public GeneratorException(Class<?> type) {
        super("Could not synthesise a value for: " + (type == null ? null : type.getSimpleName()),
                Error.GENERATOR_ERROR);
        this.type = type;
        this.internal = false;
    }

    public GeneratorException(Class<?> type, Generator generator) {
        super((generator == null ? "A generator"
                : generator.getClass().getSimpleName())
                + " failed while synthesising: " + (type == null ? null : type.getSimpleName()),
                Error.GENERATOR_ERROR);
        this.type = type;
        this.generator = generator;
        this.internal = true;
    }

    public boolean creationFailed() {
        return !this.internal;
    }

    public boolean generatorFailed() {
        return this.internal;
    }

    public Class<?> getType() {
        return this.type;
    }

    public Generator getGenerator() {
        return this.generator;
    }
}
