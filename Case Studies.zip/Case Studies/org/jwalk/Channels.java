package org.jwalk;

import org.jwalk.out.Answer;
import org.jwalk.out.Question;
import org.jwalk.out.Report;

public class Channels {

    private static final int NOMINAL = 0;
    private static final int MEMORY = 1;
    private static final int ABORT = 2;
    private int operatingStatus;
    private QuestionListener questionListener;
    private ReportListener reportListener;
    private static Console console = new Console();

    public Channels() {
        this.operatingStatus = 0;
        this.questionListener = console;
        this.reportListener = console;
    }

    public void addQuestionListener(QuestionListener listener) {
        this.questionListener = (listener == null ? console : listener);
    }

    public void addReportListener(ReportListener listener) {
        this.reportListener = (listener == null ? console : listener);
    }

    public void removeQuestionListener(QuestionListener listener) {
        if (this.questionListener == listener) {
            this.questionListener = console;
        }
    }

    public void removeReportListener(ReportListener listener) {
        if (this.reportListener == listener) {
            this.reportListener = null;
        }
    }

    public void dispatch(Report report) {
        this.reportListener.publish(new ReportEvent(report.getJWalker(), report));
    }

    public Answer dispatch(Question question) {
        return this.questionListener.respond(new QuestionEvent(question.getJWalker(), question));
    }

    public boolean nominal() {
        return this.operatingStatus == 0;
    }

    public boolean interrupted() {
        return this.operatingStatus != 0;
    }

    public boolean outOfMemory() {
        return this.operatingStatus == 1;
    }

    public boolean userAborted() {
        return this.operatingStatus == 2;
    }

    public void setNominal() {
        this.operatingStatus = 0;
    }

    public void setOutOfMemory() {
        this.operatingStatus = 1;
    }

    public void setUserAborted() {
        this.operatingStatus = 2;
    }
}
