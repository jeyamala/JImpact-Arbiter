package org.jwalk;

public class SettingsException extends JWalkException {

    private Object badValue;
    private boolean badInteger = false;

    public SettingsException(Object badValue) {
        super("Could not convert: " + badValue
                + " into an enumerated constant",
                Error.SETTINGS_ERROR);
        this.badValue = badValue;
    }

    public SettingsException(Object badValue, boolean integral) {
        super("Could not convert: " + badValue + " into an integer value",
                Error.SETTINGS_ERROR);
        this.badValue = badValue;
        this.badInteger = true;
    }

    public Object getValue() {
        return this.badValue;
    }

    public boolean enumConversionFailed() {
        return !this.badInteger;
    }

    public boolean intConversionFailed() {
        return this.badInteger;
    }
}
