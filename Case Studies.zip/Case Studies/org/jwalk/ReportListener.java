package org.jwalk;

import java.util.EventListener;

public abstract interface ReportListener extends EventListener {

    public abstract void publish(ReportEvent paramReportEvent);
}
