package org.jwalk.core;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;

public abstract class TestCase
        implements Cloneable {

    protected static StateInspector inspector = null;
    protected int state = 0;

    public static void setInspector(StateInspector inspector) {
        inspector = inspector;
    }

    public TestCase clone() {
        TestCase result = null;
        try {
            result = (TestCase) super.clone();
            result.state = 0;
        } catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
        }
        return result;
    }

    public int getState() {
        return this.state;
    }

    public abstract Member getOperation();

    public abstract Class<?> getReturnType();

    public abstract Object execute(ObjectGenerator paramObjectGenerator, Object paramObject)
            throws InvocationTargetException, GeneratorException, ExecutionException;

    public abstract String toString(ObjectGenerator paramObjectGenerator);

    public abstract String getKey(ObjectGenerator paramObjectGenerator);
}
