package org.jwalk.core;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
import org.jwalk.Generator;
import org.jwalk.GeneratorException;
import org.jwalk.JWalker;

public class ObjectGenerator extends ArrayGenerator {

    protected JWalker walker;
    protected Class<?> targetType;
    protected Object target;
    boolean selfReturned = false;
    protected Map<Object, String> oracleMap;
    protected Map<Class<?>, Integer> indexMap;

    public ObjectGenerator(JWalker walker) {
        this.walker = walker;
        this.targetType = walker.getTestClass();
        this.oracleMap = new HashMap();
        this.indexMap = new HashMap();
    }

    public boolean canCreate(Class<?> type) {
        return true;
    }

    protected boolean isMetaClass(Class<?> type) {
        return type == Class.class;
    }

    protected Object createClass(Class<?> type) {
        return this.targetType;
    }

    protected Object createFromNextConstructor(Class<?> type)
            throws GeneratorException {
        try {
            for (Constructor constructor : type.getConstructors()) {
                Class[] paramTypes = constructor.getParameterTypes();
                Object[] paramValues = new Object[paramTypes.length];
                try {
                    for (int j = 0; j < paramTypes.length; j++) {
                        paramValues[j] = nextValue(paramTypes[j]);
                    }
                    Object exemplar = constructor.newInstance(paramValues);
                    logObject(exemplar);
                    return exemplar;
                } catch (Exception localException) {
                }
            }
            throw new GeneratorException(type);
        } catch (SecurityException securityBreach) {
            GeneratorException ex = new GeneratorException(type);
            ex.initCause(securityBreach);
            throw ex;
        }
    }

    protected Object createObject(Class<?> type)
            throws GeneratorException {
        try {
            Object exemplar = type.newInstance();
            logObject(exemplar);
            return exemplar;
        } catch (InstantiationException ex) {
            return createFromNextConstructor(type);
        } catch (IllegalAccessException ex) {
            return createFromNextConstructor(type);
        } catch (Exception ex) {
            GeneratorException genEx = new GeneratorException(type);
            genEx.initCause(ex);
            throw genEx;
        }
    }

    public Object nextValue(Class<?> type)
            throws GeneratorException {
        if ((type == this.targetType) && (this.target != null) && (!this.selfReturned)) {
            this.selfReturned = true;
            return this.target;
        }

        for (Generator generator : this.delegates) {
            if (generator.canCreate(type)) {
                try {
                    Object exemplar = generator.nextValue(type);
                    logObject(exemplar);
                    return exemplar;
                } catch (GeneratorException ex) {
                    throw ex;
                } catch (Exception badGenerator) {
                    GeneratorException ex =
                            new GeneratorException(type, generator);
                    ex.initCause(badGenerator);
                    throw ex;
                }
            }
        }
        if (isPrimitive(type)) {
            return createPrimitive(type);
        }
        if (isWrapped(type)) {
            return createWrapped(type);
        }
        if (isArray(type)) {
            return createArray(type);
        }
        if (isMetaClass(type)) {
            return createClass(type);
        }
        return createObject(type);
    }

    public void logTarget(Object object) {
        this.target = object;
        logObject(object.getClass());
    }

    public Object getTarget() {
        return this.target;
    }

    public Class<?> getTargetType() {
        return this.targetType;
    }

    public JWalker getJWalker() {
        return this.walker;
    }

    public void logObject(Object object) {
        if ((object != null) && (this.oracleMap.get(object) == null)) {
            Class type = object.getClass();
            if (!isPrintable(type)) {
                Integer count = (Integer) this.indexMap.get(type);
                if (count == null) {
                    count = Integer.valueOf(0);
                }
                this.indexMap.put(type, count = Integer.valueOf(count.intValue() + 1));

                String oracleValue = type.getSimpleName();
                if (isMetaClass(type)) {
                    String param = "<" + ((Class) object).getSimpleName() + ">";
                    oracleValue = oracleValue + param;
                } else {
                    oracleValue = oracleValue + "#" + count;
                }
                this.oracleMap.put(object, oracleValue);
            }
        }
    }

    public String oracleValue(Object object) {
        String result = (String) this.oracleMap.get(object);
        if (result != null) {
            return result;
        }
        return super.oracleValue(object);
    }
}
