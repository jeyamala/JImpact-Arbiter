package org.jwalk.core;

import java.lang.reflect.Array;
import org.jwalk.GeneratorException;

public abstract class ArrayGenerator extends ValueGenerator {

    private int length = 0;

    protected boolean isArray(Class<?> type) {
        return type.isArray();
    }

    protected boolean isPrintable(Class<?> type) {
        return (isArray(type)) || (super.isPrintable(type));
    }

    protected Object createArray(Class<?> type)
            throws GeneratorException {
        this.length += 1;
        Class elemType = type.getComponentType();
        try {
            Object array = Array.newInstance(elemType, this.length);
            for (int i = 0; i < this.length; i++) {
                if (elemType.isArray()) {
                    this.length -= 1;
                }
                Object elem = nextValue(elemType);
                Array.set(array, i, elem);
            }
            return array;
        } catch (RuntimeException runEx) {
            GeneratorException genEx = new GeneratorException(type);
            genEx.initCause(runEx);
            throw genEx;
        }
    }

    public String oracleValue(Object object) {
        if ((object != null) && (isArray(object.getClass()))) {
            StringBuilder buffer = new StringBuilder();
            buffer.append('{');
            for (int i = 0; i < Array.getLength(object); i++) {
                Object elem = Array.get(object, i);
                if (i > 0) {
                    buffer.append(", ");
                }
                buffer.append(oracleValue(elem));
            }
            buffer.append('}');
            return buffer.toString();
        }

        return super.oracleValue(object);
    }
}
