package org.jwalk.core;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.util.ArrayList;
import java.util.List;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;

public class TestSequence {

    private boolean executed = false;
    private ObjectGenerator generator = null;
    private ArrayList<TestCase> sequence;
    private Object target;
    private Object result;
    private Outcome outcome = Outcome.UNKNOWN;

    private void ensureDeterminstic(Throwable cause, int counter)
            throws ExecutionException {
        if (counter > 0) {
            int index = this.sequence.size() - (counter + 1);
            TestCase testCase = (TestCase) this.sequence.get(index);
            ExecutionException ex =
                    new ExecutionException(testCase.getOperation(), true);
            ex.initCause(cause);
            throw ex;
        }
    }

    public TestSequence() {
        this.sequence = new ArrayList(1);
    }

    public TestSequence(TestSequence prefix) {
        this.sequence = new ArrayList(prefix.size() + 1);
        for (TestCase testCase : prefix.sequence) {
            add(testCase.clone());
        }
    }

    public void add(TestCase testCase) {
        this.sequence.add(testCase);
    }

    public int size() {
        return this.sequence.size();
    }

    public List<TestCase> getSequence() {
        return this.sequence;
    }

    public Member getOperation() {
        int last = size() - 1;
        if (last >= 0) {
            return ((TestCase) this.sequence.get(last)).getOperation();
        }
        return null;
    }

    public Class<?> getReturnType() {
        int last = size() - 1;
        if (last >= 0) {
            return ((TestCase) this.sequence.get(last)).getReturnType();
        }
        return null;
    }

    public Object getTarget() {
        return this.target;
    }

    public Object getResult() {
        return this.result;
    }

    public String oracleResult() {
        return this.generator.oracleValue(this.result);
    }

    public Object execute(ObjectGenerator generator)
            throws GeneratorException, ExecutionException {
        this.generator = generator;
        int counter = this.sequence.size();
        try {
            this.executed = true;
            for (TestCase testCase : this.sequence) {
                counter--;
                this.result = testCase.execute(generator, this.target);
                if (this.target == null) {
                    this.target = this.result;
                    generator.logTarget(this.target);
                }
            }

        } catch (InvocationTargetException callFailed) {
            this.result = callFailed.getCause();
            generator.logObject(this.result);
            ensureDeterminstic(callFailed.getCause(), counter);
        }
        return this.result;
    }

    public Outcome getOutcome() {
        return this.outcome;
    }

    public void setOutcome(Outcome outcome) {
        this.outcome = outcome;
    }

    public boolean hasExecuted() {
        return this.executed;
    }

    public boolean hasSucceeded() {
        return (this.executed) && (!(this.result instanceof Exception));
    }

    public boolean hasTerminated() {
        return (this.executed) && ((this.result instanceof Exception));
    }

    public boolean isUnchanged() {
        int last = size() - 1;

        return (last > 0)
                && (((TestCase) this.sequence.get(last)).getState()
                == ((TestCase) this.sequence.get(last - 1)).getState());
    }

    public boolean isReentrant() {
        int last = size() - 1;
        if (last > 0) {
            int state = ((TestCase) this.sequence.get(last)).getState();
            for (int index = 0; index < last; index++) {
                if (((TestCase) this.sequence.get(index)).getState() == state) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean hasPassed() {
        return (this.outcome == Outcome.CORRECT)
                || (this.outcome == Outcome.CONFIRMED);
    }

    public boolean hasFailed() {
        return (this.outcome == Outcome.INCORRECT)
                || (this.outcome == Outcome.REJECTED);
    }

    public boolean isConfirmed() {
        return this.outcome == Outcome.CONFIRMED;
    }

    public boolean isRejected() {
        return this.outcome == Outcome.REJECTED;
    }

    public boolean isCorrect() {
        return this.outcome == Outcome.CORRECT;
    }

    public boolean isIncorrect() {
        return this.outcome == Outcome.INCORRECT;
    }

    public boolean isValidated() {
        return this.outcome != Outcome.UNKNOWN;
    }

    public String getLongKey() {
        StringBuffer buffer = new StringBuffer();
        for (TestCase testCase : this.sequence) {
            buffer.append(testCase.getKey(this.generator));
        }
        return buffer.toString();
    }

    public String getShortKey() {
        int lastIndex = size() - 1;

        TestCase lastCase = (TestCase) this.sequence.get(lastIndex);
        List<TestCase> prefix = new ArrayList();
        int lastState = 0;
        int nextState;
        for (TestCase testCase : this.sequence.subList(0, lastIndex)) {
            nextState = testCase.getState();
            if (nextState != lastState) {
                prefix.add(testCase);
            }
            lastState = nextState;
        }

        StringBuilder buffer = new StringBuilder();
        if (!prefix.isEmpty()) {
            lastIndex = prefix.size() - 1;
            lastState = ((TestCase) prefix.get(lastIndex)).getState();
            for (TestCase testCase : prefix) {
                buffer.append(testCase.getKey(this.generator));
                if (testCase.getState() == lastState) {
                    break;
                }
            }
        }
        buffer.append(lastCase.getKey(this.generator));
        return buffer.toString();
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        for (TestCase testCase : this.sequence) {
            buffer.append(testCase.toString(this.generator)).append('\n');
        }
        buffer.append("\t==> ").append(oracleResult());
        return buffer.toString();
    }
}
