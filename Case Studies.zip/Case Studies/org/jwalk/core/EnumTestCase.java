package org.jwalk.core;

import java.lang.reflect.Field;
import java.lang.reflect.Member;

public class EnumTestCase extends TestCase {

    private Class<?> enumType;
    private Enum<?> enumValue;

    public EnumTestCase(Enum<?> value) {
        this.enumValue = value;
        this.enumType = value.getClass();
    }

    public Object execute(ObjectGenerator generator, Object target) {
        this.state = inspector.inspect(this.enumValue);
        return this.enumValue;
    }

    public String getKey(ObjectGenerator generator) {
        if (this.enumValue == null) {
            return "null";
        }
        return this.enumValue.name();
    }

    public Member getOperation() {
        Field field = null;
        try {
            field = this.enumType.getField(this.enumValue.name());
        } catch (NoSuchFieldException badName) {
            badName.printStackTrace();
        } catch (NullPointerException nullName) {
            nullName.printStackTrace();
        } catch (SecurityException securityBreach) {
            securityBreach.printStackTrace();
        }
        return field;
    }

    public Class<?> getReturnType() {
        return this.enumType;
    }

    public String toString(ObjectGenerator generator) {
        String typeName = this.enumType.getSimpleName();
        StringBuilder buffer = new StringBuilder(typeName);
        buffer.append(" target = ");
        if (this.enumValue == null) {
            buffer.append("null");
        } else {
            buffer.append(typeName).append('.').append(this.enumValue.name());
        }
        buffer.append(';');
        return buffer.toString();
    }
}
