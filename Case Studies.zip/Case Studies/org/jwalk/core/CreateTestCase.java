package org.jwalk.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;

public class CreateTestCase extends ParamTestCase {

    private Constructor<?> operation;

    public CreateTestCase(Constructor<?> constructor) {
        super(constructor);
        this.operation = constructor;
    }

    public Constructor<?> getOperation() {
        return this.operation;
    }

    public Class<?> getReturnType() {
        return this.operation.getDeclaringClass();
    }

    public Object execute(ObjectGenerator generator, Object target)
            throws InvocationTargetException, GeneratorException, ExecutionException {
        Object result = super.execute(generator, target);
        try {
            result = this.operation.newInstance(this.paramValues);
            generator.logObject(result);
            this.state = inspector.inspect(result);
        } catch (InstantiationException isAbstract) {
            ExecutionException ex = new ExecutionException(this.operation,
                    "Cannot construct an abstract class: ");
            ex.initCause(isAbstract);
            throw ex;
        } catch (IllegalAccessException isNotPublic) {
            ExecutionException ex = new ExecutionException(this.operation,
                    "Cannot invoke non-public constructor: ");
            ex.initCause(isNotPublic);
            throw ex;
        } catch (IllegalArgumentException badArguments) {
            ExecutionException ex = new ExecutionException(this.operation,
                    "Cannot match arguments to expected types: ");
            ex.initCause(badArguments);
            throw ex;
        } catch (ExceptionInInitializerError badInit) {
            ExecutionException ex = new ExecutionException(this.operation,
                    "Failed to initialise static variables: ");
            ex.initCause(badInit);
            throw ex;
        }

        return result;
    }

    public String getKey(ObjectGenerator generator) {
        StringBuilder buffer = new StringBuilder("new");
        buffer.append(super.getKey(generator));
        return buffer.toString();
    }

    public String toString(ObjectGenerator generator) {
        String typeName = getReturnType().getSimpleName();
        StringBuilder buffer = new StringBuilder(typeName);
        buffer.append(" target = new ").append(typeName);
        buffer.append(super.toString(generator));
        return buffer.toString();
    }
}
