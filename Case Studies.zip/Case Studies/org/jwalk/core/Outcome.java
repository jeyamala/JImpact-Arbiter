package org.jwalk.core;

public enum Outcome {

    UNKNOWN,
    CONFIRMED,
    REJECTED,
    CORRECT,
    INCORRECT;
}
