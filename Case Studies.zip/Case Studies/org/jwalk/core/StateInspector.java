package org.jwalk.core;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

public class StateInspector {

    private int depth = 0;

    public StateInspector() {
    }

    public StateInspector(int depth) {
        this.depth = (depth < 0 ? 0 : depth);
    }

    public int inspect(Object testObject) {
        if (testObject == null) {
            return 0;
        }
        return inspectObject(testObject.getClass(), testObject, this.depth);
    }

    protected int inspectObject(Class<?> testClass, Object testObject, int depth) {
        List<Field> fields = getFields(testClass);
        List stateVector = new ArrayList();
        for (Field field : fields) {
            Class fieldType = field.getType();
            Object fieldValue = null;
            try {
                fieldValue = field.get(testObject);
            } catch (IllegalAccessException localIllegalAccessException) {
            } catch (IllegalArgumentException localIllegalArgumentException) {
            } catch (NullPointerException localNullPointerException) {
            }
            if (fieldValue == null) {
                stateVector.add(Integer.valueOf(0));
            } else if (fieldType.isPrimitive()) {
                stateVector.add(Integer.valueOf(fieldValue.hashCode()));
            } else if (fieldType.isArray()) {
                stateVector.add(Integer.valueOf(inspectArray(fieldType, fieldValue, depth)));
            } else if (depth > 0) {
                if ((fieldType.isInterface())
                        || (Modifier.isAbstract(fieldType.getModifiers()))) {
                    fieldType = fieldValue.getClass();
                }
                stateVector.add(Integer.valueOf(inspectObject(fieldType, fieldValue, depth - 1)));
            } else {
                stateVector.add(Integer.valueOf(System.identityHashCode(fieldValue)));
            }
        }
        return stateVector.hashCode();
    }

    protected int inspectArray(Class<?> type, Object array, int depth) {
        List stateVector = new ArrayList();
        for (int index = 0; index < Array.getLength(array); index++) {
            Class elemType = type.getComponentType();
            Object elemValue = null;
            try {
                elemValue = Array.get(array, index);
            } catch (IllegalArgumentException localIllegalArgumentException) {
            } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException) {
            } catch (NullPointerException localNullPointerException) {
            }
            if (elemValue == null) {
                stateVector.add(Integer.valueOf(0));
            } else if (elemType.isPrimitive()) {
                stateVector.add(Integer.valueOf(elemValue.hashCode()));
            } else if (elemType.isArray()) {
                stateVector.add(Integer.valueOf(inspectArray(elemType, elemValue, depth)));
            } else if (depth > 0) {
                if ((elemType.isInterface())
                        || (Modifier.isAbstract(elemType.getModifiers()))) {
                    elemType = elemValue.getClass();
                }
                stateVector.add(Integer.valueOf(inspectObject(elemType, elemValue, depth - 1)));
            } else {
                stateVector.add(Integer.valueOf(System.identityHashCode(elemValue)));
            }
        }
        return stateVector.hashCode();
    }

    protected List<Field> getFields(Class<?> testClass) {
        List fields = new ArrayList();
        while (testClass != null) {
            Field[] array = testClass.getDeclaredFields();
            for (Field field : array) {
                field.setAccessible(true);
                fields.add(field);
            }
            testClass = testClass.getSuperclass();
        }
        return fields;
    }
}
