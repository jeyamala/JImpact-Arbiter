package org.jwalk.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.jwalk.Channels;
import org.jwalk.Convention;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;
import org.jwalk.JWalker;
import org.jwalk.PermissionException;
import org.jwalk.Settings;
import org.jwalk.out.ProtocolReport;

public class ClassInspector extends JWalker {

    protected Class<?> testClass = null;
    protected List<Enum<?>> constants = null;
    protected List<Constructor<?>> constructors = null;
    protected List<Method> methods = null;

    public ClassInspector(Settings settings, Channels channels) {
        super(settings, channels);
        this.testClass = settings.getTestClass();
    }

    public Class<?> getTestClass() {
        return this.testClass;
    }

    public boolean classIsInterface() {
        return Modifier.isInterface(this.testClass.getModifiers());
    }

    public boolean classIsAbstract() {
        return Modifier.isAbstract(this.testClass.getModifiers());
    }

    public boolean classIsEnum() {
        return this.testClass.isEnum();
    }

    public boolean classNotPublic() {
        return !Modifier.isPublic(this.testClass.getModifiers());
    }

    public List<Enum<?>> getConstants() {
        return (List<Enum<?>>) (this.constants == null ? Collections.emptyList() : this.constants);
    }

    public List<Constructor<?>> getConstructors() {
        return (List<Constructor<?>>) (this.constructors == null ? Collections.emptyList() : this.constructors);
    }

    public List<Method> getMethods() {
        return (List<Method>) (this.methods == null ? Collections.emptyList() : this.methods);
    }

    public int countConstants() {
        return this.constants == null ? 0 : this.constants.size();
    }

    public int countConstructors() {
        return this.constructors == null ? 0 : this.constructors.size();
    }

    public int countMethods() {
        return this.methods == null ? 0 : this.methods.size();
    }

    public long countPermutations() {
        long permutations = 0L;
        long activeEdges = classIsEnum()
                ? countConstants() : countConstructors();
        for (int i = 0; i < this.settings.getTestDepth(); i++) {
            permutations += activeEdges;
            activeEdges *= countMethods();
        }
        permutations += activeEdges;
        return permutations;
    }

    public int countActiveEdges(int cycle) {
        if (cycle < 0) {
            return 0;
        }
        int activeEdges = classIsEnum()
                ? countConstants() : countConstructors();
        for (int i = 0; i < cycle; i++) {
            activeEdges *= countMethods();
        }
        return activeEdges;
    }

    private void inspectConstants() {
        if (classIsEnum()) {
            Object[] array = this.testClass.getEnumConstants();
            this.constants = new ArrayList(array.length);
            for (Object constant : array) {
                this.constants.add((Enum) constant);
            }
        }
    }

    private void inspectConstructors()
            throws PermissionException {
        try {
            Constructor[] array = this.testClass.getConstructors();
            this.constructors = new ArrayList(array.length);
            for (Constructor constructor : array) {
                this.constructors.add(constructor);
            }
        } catch (SecurityException securityBreach) {
            PermissionException ex = new PermissionException(this.testClass,
                    "Permission denied to use the constructors of: ");
            ex.initCause(securityBreach);
            throw ex;
        }
    }

    private void inspectMethods()
            throws PermissionException {
        Convention convention = this.testClass == Object.class
                ? Convention.COMPLETE : this.settings.getConvention();
        int adjust = 0;
        if (!classIsInterface()) {
            switch (convention) {
                case COMPLETE:
                    adjust += 4;
                case CUSTOM:
                    adjust += 5;
            }
        }
        try {
            String selectedMethods = "equalshashCodegetClasstoString";
            Method[] array = this.testClass.getMethods();
            this.methods = new ArrayList(array.length - adjust);
            for (Method method : array) {
                boolean accept = (convention == Convention.COMPLETE)
                        || (method.getDeclaringClass() != Object.class) || ((convention == Convention.CUSTOM)
                        && (selectedMethods.contains(method.getName())));
                if (accept) {
                    this.methods.add(method);
                }
            }
        } catch (SecurityException securityBreach) {
            PermissionException ex = new PermissionException(this.testClass,
                    "Permission denied to use the methods of: ");
            ex.initCause(securityBreach);
            throw ex;
        }
    }

    public void inspectProtocols()
            throws PermissionException {
        inspectConstants();
        inspectConstructors();
        inspectMethods();
        this.channels.dispatch(new ProtocolReport(this));
    }

    public void execute()
            throws PermissionException, GeneratorException, ExecutionException {
        inspectProtocols();
    }
}
