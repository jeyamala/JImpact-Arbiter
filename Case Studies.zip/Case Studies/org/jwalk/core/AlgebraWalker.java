package org.jwalk.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.jwalk.Channels;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;
import org.jwalk.Modality;
import org.jwalk.PermissionException;
import org.jwalk.Settings;
import org.jwalk.out.AlgebraReport;
import org.jwalk.out.Notification;
import org.jwalk.out.Urgency;

public class AlgebraWalker extends ProtocolWalker {

    protected Map<Member, Category> category;

    public AlgebraWalker(Settings settings, Channels channels) {
        super(settings, channels);
    }

    public Category getCategory(Enum<?> constant) {
        return Category.CONSTRUCTOR;
    }

    public Category getCategory(Member member) {
        if ((member instanceof Field)) {
            return Category.CONSTRUCTOR;
        }
        return (Category) this.category.get(member);
    }

    private void updateMethodCategory(TestSequence sequence) {
        Method method = (Method) sequence.getOperation();
        if ((sequence.isReentrant()) && (hasPrimitivePrefix(sequence))) {
            this.category.put(method, Category.TRANSFORMER);
        } else if (this.category.get(method) != Category.TRANSFORMER) {
            this.category.put(method, Category.CONSTRUCTOR);
        }
    }

    private boolean hasPrimitivePrefix(TestSequence sequence) {
        List testCases = sequence.getSequence();
        int last = testCases.size() - 1;
        for (int index = 1; index < last; index++) {
            Member operation = ((TestCase) testCases.get(index)).getOperation();
            if (getCategory(operation) != Category.CONSTRUCTOR) {
                return false;
            }
        }
        return true;
    }

    private void findDerivedConstructors() {
        Iterator localIterator2;
        for (Iterator localIterator1 = getConstructors().iterator(); localIterator1.hasNext();
                localIterator2.hasNext()) {
            Constructor big = (Constructor) localIterator1.next();
            localIterator2 = getConstructors().iterator(); //continue;
            Constructor small = (Constructor) localIterator2.next();
            if (signatureSubsumes(big, small)) {
                this.category.put(small, Category.TRANSFORMER);
            }
        }
    }

    private boolean signatureSubsumes(Constructor<?> one, Constructor<?> two) {
        Class[] bigSig = one.getParameterTypes();
        Class[] smallSig = two.getParameterTypes();
        if (bigSig.length <= smallSig.length) {
            return false;
        }
        for (int i = 0; i < smallSig.length; i++) {
            if (bigSig[i] != smallSig[i]) {
                return false;
            }
        }
        return true;
    }

    protected boolean isPrunable(TestSequence sequence) {
        return (sequence.hasTerminated()) || (sequence.isReentrant());
    }

    protected void executeProbeCycle(List<TestSequence> testSet, int cycle)
            throws PermissionException, GeneratorException, ExecutionException {
        for (TestSequence sequence : testSet) {
            sequence.execute(makeGenerator());
            if (cycle != 0) {
                if (!sequence.isUnchanged()) {
                    updateMethodCategory(sequence);
                }
            }
        }
    }

    protected void discoverAlgebra()
            throws PermissionException, GeneratorException, ExecutionException {
        ensureExecutable();
        this.category = new LinkedHashMap();
        for (Constructor constructor : getConstructors()) {
            this.category.put(constructor, Category.CONSTRUCTOR);
        }
        for (Method method : getMethods()) {
            this.category.put(method, Category.OBSERVER);
        }
        this.channels.setNominal();
        int depth = this.settings.getProbeDepth();
        int cycle = 0;
        try {
            findDerivedConstructors();
            List testSet = firstCycle();
            int i = 0;
            do {
                cycle = i;
                if (cycle > 0) {
                    testSet = nextCycle(testSet);
                }
                executeProbeCycle(testSet, cycle);

                i++;
                if (!this.channels.nominal()) {
                    break;
                }
            } while (i <= depth);
        } catch (OutOfMemoryError ex) {
            System.gc();
            this.channels.setOutOfMemory();
        }
        this.channels.dispatch(new AlgebraReport(this));
        if (this.channels.outOfMemory()) {
            this.channels.dispatch(new Notification(this,
                    "Ran out of memory in probe cycle: " + cycle
                    + ". \nSuggest that you decrease the probe depth"
                    + "\nwhen analysing the algebra of this class.",
                    Urgency.WARNING));
        } else if (this.channels.userAborted()) {
            this.channels.dispatch(new Notification(this,
                    "Probing interrupted in cycle: " + cycle
                    + "; \nthe test series was aborted and"
                    + "\ntest statistics are incomplete.",
                    Urgency.WARNING));
        }
    }

    public void execute()
            throws PermissionException, GeneratorException, ExecutionException {
        inspectProtocols();
        discoverAlgebra();
        if ((!this.channels.userAborted())
                && (this.settings.getModality() != Modality.INSPECT)) {
            executeTestSeries();
        }
    }
}
