package org.jwalk.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.jwalk.GeneratorException;
import org.jwalk.gen.CustomGenerator;
import org.jwalk.gen.MasterGenerator;

public abstract class ValueGenerator
        implements MasterGenerator {

    private static Set<Class<?>> wrapped = getWrappedTypes();
    protected List<CustomGenerator> delegates;
    private boolean boolSeed = false;
    private byte byteSeed = 1;
    private char charSeed = 'a';
    private short shortSeed = 1;
    private int intSeed = 1;
    private long longSeed = 1L;
    private float floatSeed = 1.0F;
    private double doubleSeed = 1.0D;

    private static Set<Class<?>> getWrappedTypes() {
        Class[] wrapped = {Byte.class, Boolean.class,
            Character.class, Integer.class, Short.class,
            Long.class, Float.class, Double.class};
        return new HashSet((Collection) Arrays.asList(wrapped));
    }

    protected ValueGenerator() {
        this.delegates = new ArrayList();
    }

    protected boolean isPrimitive(Class<?> type) {
        return type.isPrimitive();
    }

    protected boolean isWrapped(Class<?> type) {
        return wrapped.contains(type);
    }

    protected boolean isEnumerated(Class<?> type) {
        return type.isEnum();
    }

    protected boolean isPrintable(Class<?> type) {
        return (isPrimitive(type)) || (isWrapped(type)) || (isEnumerated(type))
                || (type == String.class);
    }

    protected Object createPrimitive(Class<?> type)
            throws GeneratorException {
        if (type == Boolean.TYPE) {
            return Boolean.valueOf((this.boolSeed == this.boolSeed ? 0 : 1) == 0);
        }
        if (type == Byte.TYPE) {
            return new Byte(this.byteSeed++);
        }
        if (type == Character.TYPE) {
            return new Character(this.charSeed++);
        }
        if (type == Short.TYPE) {
            return new Short(this.shortSeed++);
        }
        if (type == Integer.TYPE) {
            return new Integer(this.intSeed++);
        }
        if (type == Long.TYPE) {
            return new Long(this.longSeed++);
        }
        if (type == Float.TYPE) {
            return new Float(this.floatSeed++);
        }
        if (type == Double.TYPE) {
            return new Double(this.doubleSeed++);
        }
        throw new GeneratorException(type);
    }

    protected Object createWrapped(Class<?> type)
            throws GeneratorException {
        if (type == Boolean.class) {
            return Boolean.valueOf((this.boolSeed == this.boolSeed ? 0 : 1) == 0);
        }
        if (type == Byte.class) {
            return new Byte(this.byteSeed++);
        }
        if (type == Character.class) {
            return new Character(this.charSeed++);
        }
        if (type == Short.class) {
            return new Short(this.shortSeed++);
        }
        if (type == Integer.class) {
            return new Integer(this.intSeed++);
        }
        if (type == Long.class) {
            return new Long(this.longSeed++);
        }
        if (type == Float.class) {
            return new Float(this.floatSeed++);
        }
        if (type == Double.class) {
            return new Double(this.doubleSeed++);
        }
        throw new GeneratorException(type);
    }

    public String oracleValue(Object object) {
        if ((object instanceof Character)) {
            return "'" + object.toString() + "'";
        }
        if ((object instanceof String)) {
            return "\"" + object.toString() + "\"";
        }
        return String.valueOf(object);
    }

    public void addDelegate(CustomGenerator generator) {
        this.delegates.add(0, generator);
        generator.setOwner(this);
    }
}
