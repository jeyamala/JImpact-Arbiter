package org.jwalk.core;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jwalk.Channels;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;
import org.jwalk.Modality;
import org.jwalk.PermissionException;
import org.jwalk.Settings;
import org.jwalk.out.CycleReport;
import org.jwalk.out.Notification;
import org.jwalk.out.StateReport;
import org.jwalk.out.SummaryReport;
import org.jwalk.out.Urgency;

public class StateSpaceWalker extends ProtocolWalker {

    private boolean searchFlag = false;
    protected boolean stateFlag = false;
    protected List<Method> predicates = null;
    protected Map<String, TestSequence> stateCover = null;

    public StateSpaceWalker(Settings settings, Channels channels) {
        super(settings, channels);
    }

    public boolean hasMissingStates() {
        return this.stateFlag;
    }

    public int countMaxStates() {
        int max = 1;
        for (int i = 0; i < this.predicates.size(); i++) {
            max *= 2;
        }
        return max;
    }

    public Map<String, TestSequence> getStateCover() {
        return this.stateCover;
    }

    public List<Method> getStatePredicates() {
        return this.predicates;
    }

    public long countPermutations() {
        long permutations = 0L;
        long activeEdges = this.stateCover.size();
        for (int i = 0; i < this.settings.getTestDepth(); i++) {
            permutations += activeEdges;
            activeEdges *= countMethods();
        }
        permutations += activeEdges;
        return permutations;
    }

    public int countActiveEdges(int cycle) {
        if (cycle < 0) {
            return 0;
        }
        int activeEdges = 1;
        for (int i = 0; i < cycle; i++) {
            activeEdges *= countMethods();
        }
        return activeEdges;
    }

    protected boolean isPrunable(TestSequence sequence) {
        return (sequence.hasTerminated()) || ((this.searchFlag) && (sequence.isReentrant()));
    }

    protected List<TestSequence> firstCycle(String stateKey) {
        return Collections.singletonList(
                new TestSequence((TestSequence) this.stateCover.get(stateKey)));
    }

    private void findStatePredicates() {
        this.predicates = new ArrayList(5);
        for (Method method : getMethods()) {
            if ((method.getReturnType() == Boolean.TYPE)
                    && (method.getParameterTypes().length == 0)) {
                this.predicates.add(method);
            }
        }
    }

    private String getStateName(String name) {
        if (name.startsWith("is")) {
            name = name.substring(2);
        }
        char first = name.charAt(0);
        if (Character.isLowerCase(first)) {
            name = String.valueOf(Character.toUpperCase(first))
                    + name.substring(1);
        }
        return name;
    }

    private String detectState(TestSequence prefix)
            throws PermissionException, GeneratorException, ExecutionException {
        List<Method> truePredicates = new ArrayList(3);
        TestSequence probe;
        for (Method predicate : this.predicates) {
            probe = new TestSequence(prefix);
            probe.add(new InvokeTestCase(predicate));
            Boolean result = (Boolean) probe.execute(makeGenerator());
            if (result.booleanValue()) {
                truePredicates.add(predicate);
            }
        }
        if (truePredicates.size() > 0) {
            StringBuilder buffer = new StringBuilder();
            for (Method predicate : truePredicates) {
                String name = getStateName(predicate.getName());
                if (buffer.length() > 0) {
                    buffer.append('&');
                }
                buffer.append(name);
            }
            return buffer.toString();
        }

        return "Default";
    }

    private void checkDetectedStates() {
        for (Method predicate : this.predicates) {
            String name = getStateName(predicate.getName());
            boolean present = false;
            boolean absent = false;
            for (String stateKey : this.stateCover.keySet()) {
                if (stateKey.contains(name)) {
                    present = true;
                } else {
                    absent = true;
                }
            }
            if ((!present) || (!absent)) {
                this.stateFlag = true;
                break;
            }
        }
    }

    protected void executeProbeCycle(List<TestSequence> testSet, int cycle)
            throws PermissionException, GeneratorException, ExecutionException {
        for (TestSequence prefix : testSet) {
            prefix.execute(makeGenerator());
            if (!isPrunable(prefix)) {
                String stateKey = detectState(prefix);
                if (!this.stateCover.containsKey(stateKey)) {
                    this.stateCover.put(stateKey, prefix);
                }
            }
        }
    }

    protected void discoverStates()
            throws PermissionException, GeneratorException, ExecutionException {
        ensureExecutable();
        findStatePredicates();
        this.stateFlag = false;
        this.searchFlag = true;
        this.stateCover = new LinkedHashMap();
        this.channels.setNominal();
        int maxStates = countMaxStates();
        int depth = this.settings.getProbeDepth();
        int cycle = 0;
        try {
            List testSet = firstCycle();
            int i = 0;
            do {
                cycle = i;
                if (cycle > 0) {
                    testSet = nextCycle(testSet);
                }
                executeProbeCycle(testSet, cycle);

                i++;

                if ((!this.channels.nominal()) || (i > depth)) {
                    break;
                }
            } while (this.stateCover.size() < maxStates);
        } catch (OutOfMemoryError ex) {
            System.gc();
            this.channels.setOutOfMemory();
        }
        checkDetectedStates();
        this.channels.dispatch(new StateReport(this));
        this.searchFlag = false;
        if (this.channels.outOfMemory()) {
            this.channels.dispatch(new Notification(this,
                    "Ran out of memory in probe cycle: " + cycle
                    + ". \nSuggest that you decrease the probe depth"
                    + "\nwhen analysing the state space of this class.",
                    Urgency.WARNING));
        } else if (this.channels.userAborted()) {
            this.channels.dispatch(new Notification(this,
                    "Probing interrupted in cycle: " + cycle
                    + "; \nthe test series was aborted and"
                    + "\ntest statistics are incomplete.",
                    Urgency.WARNING));
        }
        if (this.stateFlag) {
            this.channels.dispatch(new Notification(this,
                    "Expected states not found after probe cycle: " + cycle
                    + ". \nSuggest that you increase the probe depth"
                    + "\nwhen analysing the state space of this class.",
                    Urgency.WARNING));
        }
    }

    protected void executeTestSeries()
            throws PermissionException, GeneratorException, ExecutionException {
        this.summary = new SummaryReport(this);
        if (this.settings.getModality() == Modality.VALIDATE) {
            this.oracle = new Oracle(this);
            this.oracle.open();
        }
        this.channels.setNominal();
        int depth = this.settings.getTestDepth();
        int cycle = 0;
        try {
            int i = 0;
            Iterator localIterator;
            for (localIterator = this.stateCover.keySet().iterator(); (this.channels.nominal() && i <= depth); localIterator.hasNext()) {
                String stateKey = (String) localIterator.next();
                List testSet = firstCycle(stateKey);
                i = 0;
//  continue;
                cycle = i;
                if (cycle > 0) {
                    testSet = nextCycle(testSet);
                }
                executeTestCycle(testSet, cycle);
                CycleReport report =
                        new CycleReport(this, testSet, stateKey, cycle);
                this.summary.tallyResults(report);
                this.channels.dispatch(report);

                i++;
            }

        } catch (OutOfMemoryError ex) {
            System.gc();
            this.channels.setOutOfMemory();
        }
        this.channels.dispatch(this.summary);
        if (this.oracle != null) {
            this.oracle.close();
        }
        if (this.channels.outOfMemory()) {
            this.channels.dispatch(new Notification(this,
                    "Ran out of memory in cycle: " + cycle
                    + "; \nthe test series was aborted and"
                    + "\ntest statistics are incomplete.",
                    Urgency.WARNING));
        } else if (this.channels.userAborted()) {
            this.channels.dispatch(new Notification(this,
                    "Testing interrupted in cycle: " + cycle
                    + "; \nthe test series was aborted and"
                    + "\ntest statistics are incomplete.",
                    Urgency.WARNING));
        }
    }

    public void execute()
            throws PermissionException, GeneratorException, ExecutionException {
        inspectProtocols();
        discoverStates();
        if ((!this.channels.userAborted())
                && (this.settings.getModality() != Modality.INSPECT)) {
            executeTestSeries();
        }
    }
}
