package org.jwalk.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.Map;
import org.jwalk.Channels;
import org.jwalk.JWalker;
import org.jwalk.Settings;
import org.jwalk.out.Notification;
import org.jwalk.out.Urgency;

public class Oracle {

    protected JWalker walker;
    protected Map<String, String> correct;
    protected Map<String, String> incorrect;

    public Oracle(JWalker walker) {
        this.walker = walker;
        this.correct = new LinkedHashMap();
        this.incorrect = new LinkedHashMap();
    }

    public boolean open() {
        Settings settings = this.walker.getSettings();
        Class testClass = settings.getTestClass();
        File file = new File(settings.getOracleDirectory(),
                testClass.getSimpleName() + ".jwk");
        if ((!file.exists()) && (testClass != Object.class)) {
            testClass = testClass.getSuperclass();
            file = new File(settings.getOracleDirectory(),
                    testClass.getSimpleName() + ".jwk");
        }
        if (!file.exists()) {
            return false;
        }
        try {
            BufferedReader reader = new BufferedReader(
                    new FileReader(file));
            boolean mark = false;
            while (reader.ready()) {
                String data = reader.readLine();
                if (data.length() == 0) {
                    mark = true;
                } else {
                    String[] pair = data.split("=");
                    if (mark) {
                        this.incorrect.put(pair[0], pair[1]);
                    } else {
                        this.correct.put(pair[0], pair[1]);
                    }
                }
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return (!this.correct.isEmpty()) || (!this.incorrect.isEmpty());
    }

    public boolean close() {
        Channels channels = this.walker.getChannels();
        Settings settings = this.walker.getSettings();
        String oracleName = settings.getTestClass().getSimpleName() + ".jwk";
        File file = new File(settings.getOracleDirectory(), oracleName);
        boolean writtenOK = false;
        try {
            PrintWriter writer = new PrintWriter(
                    new FileWriter(file));
            for (String key : this.correct.keySet()) {
                writer.print(key);
                writer.print("=");
                writer.println((String) this.correct.get(key));
            }
            writer.println();
            for (String key : this.incorrect.keySet()) {
                writer.print(key);
                writer.print("=");
                writer.println((String) this.incorrect.get(key));
            }
            writtenOK = true;
            writer.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        if (writtenOK) {
            String message = "The oracle file `" + oracleName
                    + "' was written to:\n" + settings.getOracleDirectory();
            channels.dispatch(new Notification(this.walker, message, Urgency.NOTICE));
        } else {
            String message = "The oracle file `" + oracleName
                    + "' cannot be written to:\n" + settings.getOracleDirectory();
            channels.dispatch(new Notification(this.walker, message, Urgency.WARNING));
        }
        return writtenOK;
    }

    public Outcome validate(TestSequence sequence) {
        Outcome outcome = null;
        if (!sequence.hasExecuted()) {
            outcome = Outcome.UNKNOWN;
        } else if ((sequence.getReturnType() == Void.TYPE)
                && (sequence.getResult() == Void.TYPE)) {
            outcome = Outcome.CORRECT;
        } else {
            String result = sequence.oracleResult();
            String longKey = sequence.getLongKey();
            String pass = (String) this.correct.get(longKey);
            String fail = (String) this.incorrect.get(longKey);
            if ((pass == null) && (fail == null)) {
                String shortKey = sequence.getShortKey();
                pass = (String) this.correct.get(shortKey);
                fail = (String) this.incorrect.get(shortKey);
            }

            if ((pass != null) && (result.equals(pass))) {
                outcome = Outcome.CORRECT;
            } else if ((fail != null) && (result.equals(fail))) {
                outcome = Outcome.INCORRECT;
            } else {
                Channels channels = this.walker.getChannels();
                switch (channels.dispatch(new org.jwalk.out.Confirmation(this.walker, sequence)).ordinal()) {
                    case 1:
                        outcome = Outcome.CONFIRMED;
                        this.correct.put(longKey, result);
                        break;
                    case 2:
                        outcome = Outcome.REJECTED;
                        this.incorrect.put(longKey, result);
                        break;
                    case 4:
                        outcome = Outcome.UNKNOWN;
                        break;
                    case 3:
                    default:
                        outcome = Outcome.UNKNOWN;
                }
            }
        }
        sequence.setOutcome(outcome);
        return outcome;
    }
}
