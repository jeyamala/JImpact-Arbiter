package org.jwalk.core;

public enum Category {

    CONSTRUCTOR,
    TRANSFORMER,
    OBSERVER;
}
