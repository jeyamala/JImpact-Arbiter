package org.jwalk.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;

public abstract class ParamTestCase extends TestCase {

    protected boolean isBinary = false;
    protected Class<?>[] paramTypes = null;
    protected Object[] paramValues = null;

    protected ParamTestCase(Constructor<?> constructor) {
        this.paramTypes = constructor.getParameterTypes();
    }

    protected ParamTestCase(Method method) {
        this.paramTypes = method.getParameterTypes();
        String name = method.getName();
        if ((name.equals("equals")) || (name.equals("compareTo"))) {
            this.isBinary = true;
        }
    }

    public ParamTestCase clone() {
        ParamTestCase result = (ParamTestCase) super.clone();
        result.paramValues = null;
        return result;
    }

    public Object execute(ObjectGenerator generator, Object target)
            throws InvocationTargetException, GeneratorException, ExecutionException {
        this.paramValues = new Object[this.paramTypes.length];
        for (int i = 0; i < this.paramValues.length; i++) {
            try {
                if (this.isBinary) {
                    this.paramValues[i] = generator.nextValue(generator.getTargetType());
                } else {
                    this.paramValues[i] = generator.nextValue(this.paramTypes[i]);
                }
            } catch (GeneratorException ex) {
                throw ex;
            } catch (Exception badGenerator) {
                GeneratorException ex =
                        new GeneratorException(this.paramTypes[i], generator);
                ex.initCause(badGenerator);
                throw ex;
            }
        }
        return null;
    }

    public String getKey(ObjectGenerator generator) {
        StringBuilder buffer = new StringBuilder("(");
        for (int i = 0; i < this.paramTypes.length; i++) {
            if (i > 0) {
                buffer.append(',');
            }
            if (this.paramValues == null) {
                buffer.append("null");
            } else {
                buffer.append(generator.oracleValue(this.paramValues[i]));
            }
        }
        buffer.append(')');
        return buffer.toString();
    }

    public String toString(ObjectGenerator generator) {
        StringBuilder buffer = new StringBuilder("(");
        for (int i = 0; i < this.paramTypes.length; i++) {
            if (i > 0) {
                buffer.append(", ");
            }
            buffer.append(this.paramTypes[i].getSimpleName()).append(' ');
            if (this.paramValues == null) {
                buffer.append("null");
            } else {
                buffer.append(generator.oracleValue(this.paramValues[i]));
            }
        }
        buffer.append(");");
        return buffer.toString();
    }
}
