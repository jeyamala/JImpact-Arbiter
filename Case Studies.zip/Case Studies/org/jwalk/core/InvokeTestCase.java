package org.jwalk.core;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;

public class InvokeTestCase extends ParamTestCase {

    private Method operation;

    public InvokeTestCase(Method method) {
        super(method);
        this.operation = method;
    }

    public Method getOperation() {
        return this.operation;
    }

    public Class<?> getReturnType() {
        return this.operation.getReturnType();
    }

    public Object execute(ObjectGenerator generator, Object target)
            throws InvocationTargetException, GeneratorException, ExecutionException {
        Object result = super.execute(generator, target);
        try {
            result = this.operation.invoke(target, this.paramValues);
            generator.logObject(result);
            this.state = inspector.inspect(target);
        } catch (IllegalAccessException isNotPublic) {
            ExecutionException ex = new ExecutionException(this.operation,
                    "Cannot invoke non-public operation: ");
            ex.initCause(isNotPublic);
            throw ex;
        } catch (IllegalArgumentException badArguments) {
            ExecutionException ex = new ExecutionException(this.operation,
                    "Cannot match arguments to expected types: ");
            ex.initCause(badArguments);
            throw ex;
        } catch (NullPointerException nullTarget) {
            ExecutionException ex = new ExecutionException(this.operation,
                    "Cannot invoke a method on a null target: ");
            ex.initCause(nullTarget);
            throw ex;
        } catch (ExceptionInInitializerError badInit) {
            ExecutionException ex = new ExecutionException(this.operation,
                    "Failed to initialise static variables: ");
            ex.initCause(badInit);
            throw ex;
        } catch (InvocationTargetException callFailed) {
            this.state = inspector.inspect(target);
            throw callFailed;
        }

        if (getReturnType() == Void.TYPE) {
            return Void.TYPE;
        }
        return result;
    }

    public String getKey(ObjectGenerator generator) {
        StringBuilder buffer = new StringBuilder(".");
        buffer.append(this.operation.getName()).append(super.getKey(generator));
        return buffer.toString();
    }

    public String toString(ObjectGenerator generator) {
        StringBuilder buffer = new StringBuilder("\ttarget.");
        buffer.append(this.operation.getName()).append(super.toString(generator));
        return buffer.toString();
    }
}
