package org.jwalk.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;
import org.jwalk.Channels;
import org.jwalk.ExecutionException;
import org.jwalk.GeneratorException;
import org.jwalk.Modality;
import org.jwalk.PermissionException;
import org.jwalk.Settings;
import org.jwalk.gen.CustomGenerator;
import org.jwalk.out.CycleReport;
import org.jwalk.out.Notification;
import org.jwalk.out.SummaryReport;
import org.jwalk.out.Urgency;

public class ProtocolWalker extends ClassInspector {

    protected Oracle oracle = null;
    protected SummaryReport summary = null;

    public ProtocolWalker(Settings settings, Channels channels) {
        super(settings, channels);
    }

    protected boolean isPrunable(TestSequence sequence) {
        return sequence.hasTerminated();
    }

    protected ObjectGenerator makeGenerator()
            throws PermissionException {
        ObjectGenerator generator = new ObjectGenerator(this);
        for (Class type : this.settings.getCustomGenerators()) {
            try {
                generator.addDelegate((CustomGenerator) type.newInstance());
            } catch (InstantiationException ex) {
                PermissionException gen = new PermissionException(type, true);
                gen.initCause(ex);
                throw gen;
            } catch (IllegalAccessException ex) {
                PermissionException gen = new PermissionException(type, true);
                gen.initCause(ex);
                throw gen;
            }
        }
        return generator;
    }

    protected void ensureExecutable()
            throws PermissionException {
        if (classIsInterface()) {
            throw new PermissionException(this.testClass,
                    "Permission denied to execute the interface: ");
        }
        if (classIsAbstract()) {
            throw new PermissionException(this.testClass,
                    "Permission denied to execute the abstract class: ");
        }
        if (classNotPublic()) {
            throw new PermissionException(this.testClass,
                    "Permission denied to execute the non-public class: ");
        }
    }

    protected List<TestSequence> firstCycle() {
        List newCycle = new LinkedList();
        if (this.testClass.isEnum()) {
            for (Enum value : getConstants()) {
                TestSequence sequence = new TestSequence();
                sequence.add(new EnumTestCase(value));
                newCycle.add(sequence);
            }
        } else {
            for (Constructor constructor : getConstructors()) {
                TestSequence sequence = new TestSequence();
                sequence.add(new CreateTestCase(constructor));
                newCycle.add(sequence);
            }
        }
        return newCycle;
    }

    protected List<TestSequence> nextCycle(List<TestSequence> oldCycle) {
        List newCycle = new LinkedList();
        for (TestSequence prefix : oldCycle) {
            if (!isPrunable(prefix)) {
                for (Method method : getMethods()) {
                    if (this.channels.interrupted()) {
                        return newCycle;
                    }
                    TestSequence sequence = new TestSequence(prefix);
                    sequence.add(new InvokeTestCase(method));
                    newCycle.add(sequence);
                }
            }
        }
        return newCycle;
    }

    protected void executeTestCycle(List<TestSequence> testSet, int cycle)
            throws PermissionException, GeneratorException, ExecutionException {
        for (TestSequence sequence : testSet) {
            if (this.channels.interrupted()) {
                break;
            }
            sequence.execute(makeGenerator());
            if (this.oracle != null) {
                Outcome outcome = this.oracle.validate(sequence);

                if (outcome == Outcome.UNKNOWN) {
                    this.channels.setUserAborted();
                }
            }
        }
    }

    protected void executeTestSeries()
            throws PermissionException, GeneratorException, ExecutionException {
        ensureExecutable();
        this.summary = new SummaryReport(this);
        if (this.settings.getModality() == Modality.VALIDATE) {
            this.oracle = new Oracle(this);
            this.oracle.open();
        }
        this.channels.setNominal();
        int depth = this.settings.getTestDepth();
        int cycle = 0;
        try {
            List testSet = firstCycle();
            int i = 0;
            do {
                cycle = i;
                if (cycle > 0) {
                    testSet = nextCycle(testSet);
                }
                executeTestCycle(testSet, cycle);
                CycleReport report = new CycleReport(this, testSet, cycle);
                this.summary.tallyResults(report);
                this.channels.dispatch(report);

                i++;
                if (!this.channels.nominal()) {
                    break;
                }
            } while (i <= depth);
        } catch (OutOfMemoryError ex) {
            System.gc();
            this.channels.setOutOfMemory();
        }
        this.channels.dispatch(this.summary);
        if (this.oracle != null) {
            this.oracle.close();
        }
        if (this.channels.outOfMemory()) {
            this.channels.dispatch(new Notification(this,
                    "Ran out of memory in cycle: " + cycle
                    + "; \nthe test series was aborted and"
                    + "\ntest statistics are incomplete.",
                    Urgency.WARNING));
        } else if (this.channels.userAborted()) {
            this.channels.dispatch(new Notification(this,
                    "Testing interrupted in cycle: " + cycle
                    + "; \nthe test series was aborted and"
                    + "\ntest statistics are incomplete.",
                    Urgency.WARNING));
        }
    }

    public void execute()
            throws PermissionException, GeneratorException, ExecutionException {
        inspectProtocols();
        if (this.settings.getModality() != Modality.INSPECT) {
            executeTestSeries();
        }
    }
}
