package org.jwalk;

public enum Convention {

    STANDARD,
    CUSTOM,
    COMPLETE;
}
