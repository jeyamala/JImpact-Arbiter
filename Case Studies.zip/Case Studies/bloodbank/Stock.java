package bloodbank;

import java.sql.*;

public class Stock {

    static int a = 0;
    String red, reby, requdt, bg;
    int rid, qt;
    Issue req = new Issue();
    public void Stockdetails(int ridd, String redd, String bgg, int qtt) {
        if ( req.issueno() > 2000 ) {
            System.out.println("we can't process this order");
            return;
        }
        red = redd;
        bg = bgg;
        rid = ridd;
        qt = qtt;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Stock values(" + rid + ",'" + red + "','" + bg + "'," + qt + ")");
            System.out.println("Stock details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int sno() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select max(stockid) from Stock");
            if (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
