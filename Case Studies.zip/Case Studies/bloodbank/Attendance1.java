package bloodbank;

import java.sql.*;

public class Attendance1 extends Employee {

    String mo, ye;
    int eid, wd, da;

    public void Attendancedetails(int eidd, String moo, String yee, int wdd, int daa) {
        if (moo.length() <= 0 || yee.length() <= 0) {
            System.out.println("Invalid Details");
            return;
        }
        Employee emp = new Employee();
        eid = emp.eno();
        mo = moo;
        ye = yee;
        wd = wdd;
        da = daa;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Attendance values(" + eid + ",'" + mo + "','" + ye + "'," + wd + "," + da + ")");
            System.out.println("Attendance details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
