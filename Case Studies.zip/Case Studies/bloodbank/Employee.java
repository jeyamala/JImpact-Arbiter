/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bloodbank;

import java.sql.*;

public class Employee {

    static int a = 0;
    String ename, gen, doj, exp, des, add, ph;
    int eid, age;

    public void Employeedetails(int eidd, String enamee, int agee, String genn, String dojj, String expp, String dess, String addd, String phh) {
        if (enamee.length() <= 0 || genn.length() <= 0) {
            System.out.println("Invalid Details");
            return;
        }
        eid = eidd;
        age = agee;
        ename = enamee;
        gen = genn;
        doj = dojj;
        exp = expp;
        des = dess;
        add = addd;
        ph = phh;
        try {
            Collect col = new Collect();
            col.Collectdetails(eidd, addd, dess, addd, phh, a);
            Recepeint rep = new Recepeint();
            rep.Recepeintdetails(eidd, genn, dojj, genn, phh, a, add, phh, exp, gen);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into emp values(" + eid + ",'" + ename + "'," + age + ",'" + gen + "','" + doj + "','" + exp + "','" + des + "','" + add + "','" + ph + "')");
            System.out.println("Employee details added successfully");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int eno() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select max(empid) from emp");
            if (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
