package bloodbank;

import java.sql.*;

public class Admin {

    int id, itn;
    String eq, pd;
    int dno, we;
    String check;
    String dname;
    int d;
    String dn;

    public void viewEquipdetails(int idd, String eqq, int itnn, String pdd) {
        if (eqq.length() <= 0 || pdd.length() <= 0) {
            System.out.println("Invalid Details");
            return;
        }
        Stock st = new Stock();
        id = idd;
        eq = eqq;
        itn = itnn;
        pd = pdd;
        st.Stockdetails(idd, pdd, pdd, itn);
        try {
            Attendance1 att = new Attendance1();
            att.Attendancedetails(idd, pdd, eq, idd, dno);
            Salary1 sal = new Salary1();
            sal.Salarydetails(idd, dno, idd, pdd, eq, itn);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("Select * from equip");
            System.out.println("Equipment details Displayed successfully");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public int validate(int dd, String dnn) {
        if (dnn.length() <= 0) {
            System.out.println("Invalid Details");
            return 0;
        }
        d = dd;
        dn = dnn;
        Donar d1 = new Donar();
        int i = d1.dno();
        return i;

    }
}
