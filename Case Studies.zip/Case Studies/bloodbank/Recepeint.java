/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bloodbank;

import java.sql.*;

public class Recepeint {

    static int a = 0;
    String dn, dob, gen, bg, ad, ph, em, re;
    int did, w;

    public void Recepeintdetails(int didd, String dnn, String dobb, String genn, String bgg, int ww, String add, String phh, String emm, String ree) {
        if (dnn.length() <= 0 || genn.length() <= 10) {
            System.out.println("Invalid Details");
            return;
        }
        Admin admin = new Admin();
        int adit = admin.validate(did, dnn);
        did = didd;
        dn = dnn;
        dob = dobb;
        gen = genn;
        bg = bgg;
        w = ww;
        ad = add;
        ph = phh;
        em = emm;
        re = ree;
        try {
            Camp cam = new Camp();
            cam.Campdetails(didd, ree, ree, ree, bgg, ree);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Recepient values(" + did + ",'" + dn + "','" + dob + "','" + gen + "','" + bg + "'," + w + ",'" + ad + "','" + ph + "','" + em + "','" + re + "')");
            System.out.println("Recepient details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int rno() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select max(rerid) from Recepient");
            if (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
