package bloodbank;

import java.sql.*;

public class Salary1 extends Employee {

    String mo, ye;
    int eid, de, ad, tot;

    public void Salarydetails(int eidd, int dee, int add, String moo, String yee, int tott) {
        if (yee.length() <= 0 || moo.length() <= 0) {
            System.out.println("Invalid Details");
            return;
        }
        Employee emp = new Employee();
        eid = emp.eno();
        de = dee;
        ad = add;
        mo = moo;
        ye = yee;
        tot = tott;

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Salary values(" + eid + "," + de + "," + ad + ",'" + mo + "','" + ye + "'," + tot + ")");
            System.out.println("Salary details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
