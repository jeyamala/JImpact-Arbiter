/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bloodbank;

import java.sql.*;

public class Issue {

    static int a = 0;
    String red, reby, requdt, bg;
    int rid, qt;

    public void Issuedetails(int ridd, String redd, String rebyy, String requdtt, String bgg, int qtt) {
        if (redd.length() <= 0 || rebyy.length() <= 0) {
            System.out.println("Invalid Details");
            return;
        }
        Request req = new Request();
        ridd = req.rqno();
        red = redd;
        reby = rebyy;
        requdt = requdtt;
        bg = bgg;
        rid = ridd;
        qt = qtt;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Issue values(" + rid + ",'" + red + "','" + reby + "','" + requdt + "','" + bg + "'," + qt + ")");
            System.out.println("Issue details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int issueno() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select max(issueid) from Issue");
            if (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
