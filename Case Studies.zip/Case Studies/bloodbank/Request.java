package bloodbank;

import java.sql.*;

public class Request {

    static int a = 0;
    String red, reby, requdt, bg;
    int rid, qt;

    public void Requestdetails(int ridd, String redd, String rebyy, String requdtt, String bgg, int qtt) {
        if (redd.length() <= 0 || rebyy.length() <= 0) {
            System.out.println("Invalid Details");
            return;
        }
        Stock st = new Stock();
        st.Stockdetails(ridd, redd, bgg, qtt);
        red = redd;
        reby = rebyy;
        requdt = requdtt;
        bg = bgg;
        rid = ridd;
        qt = qtt;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Request values(" + rid + ",'" + red + "','" + reby + "','" + requdt + "','" + bg + "'," + qt + ")");
            System.out.println("Request details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int rqno() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select max(reid) from Request");
            if (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
