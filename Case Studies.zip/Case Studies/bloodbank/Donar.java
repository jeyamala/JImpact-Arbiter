/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bloodbank;

import java.sql.*;

public class Donar {

    static int a = 0;
    String dn, dob, gen, bg, ad, ph, em;
    int did, w;
    String check;

    public void Donardetails(int didd, String dnn, String dobb, String genn, String bgg, int ww, String add, String phh, String emm) {
        if (dnn.length() <= 0 || genn.length() <= 0) {
            System.out.println("Invalid Details");
            return;
        }
        did = didd;
        dn = dnn;
        dob = dobb;
        gen = genn;
        bg = bgg;
        w = ww;
        ad = add;
        ph = phh;
        em = emm;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Donar values(" + did + ",'" + dn + "','" + dob + "','" + gen + "','" + bg + "'," + w + ",'" + ad + "','" + ph + "','" + em + "')");
            System.out.println("Donar details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int dno() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select max(donarid) from Donar");
            if (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }

    public int Validatedonar(int didd, String dnamee) {
        if (dnamee.length() <= 0) {
            System.out.println("Invalid Details");
            return -1;
        }
        did = didd;
        dn = dnamee;

        System.out.println(did);
        System.out.println(dn);

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c.createStatement();
            ResultSet r = s.executeQuery("select dname from Donar where donarid="+didd+"");
            if (r.next()) {
                check = r.getString(1);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        System.out.println(check);

        if (check == null || check.equals("")) {
            System.out.println("Invaid Donar");
            return 0;
        }
        return 1;
    }
}
