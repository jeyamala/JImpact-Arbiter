package bloodbank;

import java.sql.*;

/**
 *
 * @author HP2
 */
public class Equip {

    String eq, pd;
    int id, itn;
    static int a = 0;

    public void Equipdetails(int idd, String eqq, int itnn, String pdd) {
        if (eqq.length() <= 0 || pdd.length() <= 0) {
            System.out.println("Invalid Details");
            return;
        }
        Stock sto = new Stock();
        int sid = sto.sno();
        id = idd;
        eq = eqq;
        itn = itnn;
        pd = pdd;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into equip values(" + id + ",'" + eq + "'," + itn + ",'" + pd + "')");
            System.out.println("Equipment details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public static int eno() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("jdbc:odbc:Bloodbank", "", "");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select max(eqid) from Equip");
            if (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
