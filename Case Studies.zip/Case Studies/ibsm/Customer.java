package ibsm;

import java.sql.*;

public class Customer extends User {

    String accno, acctype, atypeno;
    int bal, i=1;

    public void GetDetails(String acno, String atype) {
        if (acno.length() <= 0 || atype.length() <= 0) {
            System.out.println("You are not a valid customer");
        }
        accno = acno;
        acctype = atype;      
        if (acctype.equals("cur")) {
            i = 2;
        } else if (acctype.equals("sav")) {
            i = 3;
        } else if (acctype.equals("fd")) {
            i = 4;
        } else if (acctype.equals("rd")) {
            i = 5;
        } else {
            i = 1;
        }
    }
    public String validate1(String acno) {
        if (acno.length() <= 0) {
            return null;
        }
        Month mn = new Month();
        mn.display();
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            // ResultSet rs=s.executeQuery("select * from usr ")
            ResultSet r = s.executeQuery("select * from account");
            if (r.next()) {
                atypeno = r.getString(i);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return atypeno;
    }

    public int ViewBalance(String acctype, String atypeno) {
        if (acctype.length() <= 0 || atypeno.length() <= 0) {
            return 0;
        }
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            String sql;
            if (acctype.equals("cur")) {
                sql = "select bal from current";
            } else if (acctype.equals("sav")) {
                sql = "select bal from saving";
            } else if (acctype.equals("fd")) {
                sql = "select amt from fixed";
            } else {
                sql = "select amt from recurring";
            }
            ResultSet r = s.executeQuery(sql);
            if (r.next()) {
                bal = r.getInt(1);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return bal;
    }
}
