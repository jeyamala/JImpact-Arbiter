package ibsm;

import java.sql.*;
import java.util.*;

public class Deposit extends Transaction {

    private String an, at, sql, sql1, sac;
    String tt;
    GregorianCalendar gc = new GregorianCalendar();
    int month = gc.get(Calendar.MONTH) + 1;
    String dt = gc.get(Calendar.DATE) + "/" + month + "/" + gc.get(Calendar.YEAR);
    int bln, j, am;

    public int Check(String a, String atp, int b) {
        if (a.length() <= 0 || atp.length() <= 0) {
            return 0;
        }
        an = a;
        at = atp;
        bln = b;
        CheckBalance cb = new CheckBalance();
        int k = cb.CheckBal(an, at, bln);
        return 1;
    }

    public int DebitBalance(String a, String atp, int b, String t) {
        if (a.length() <= 0 || atp.length() <= 0) {
            return 0;
        }
        an = a;
        at = atp;
        bln = b;
        tt = t;
        Deposit d = new Deposit();
        int i = Check(a, atp, b);
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            if (at.equals("cur")) {
                sql = "select cur from account";
            } else if (at.equals("sav")) {
                sql = "select sav from account";
            } else if (at.equals("fd")) {
                sql = "select fd from account";
            } else if (at.equals("rd")) {
                sql = "select rd from account";
            }
            ResultSet r = s.executeQuery(sql);
            while (r.next()) {
                sac = r.getString(1);
            }
            if (at.equals("cur")) {
                sql1 = "select bal from current";
            } else if (at.equals("sav")) {
                sql1 = "select bal from saving";
            } else if (at.equals("fd")) {
                sql1 = "select amt from fixed";
            } else if (at.equals("rd")) {
                sql1 = "select amt from recurring";
            }
            ResultSet rs = s.executeQuery(sql1);
            while (rs.next()) {
                am = rs.getInt(1);
            }
            am = am + bln;           
        } catch (Exception e) {
            System.out.println(e);
        }
        return 1;
    }
}
