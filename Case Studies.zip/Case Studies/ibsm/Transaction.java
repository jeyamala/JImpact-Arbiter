package ibsm;

public class Transaction {

    private String an, at;
    int bl;

    public void display(String a) {
        if (a.length() <= 0) {
            System.out.println("Invalid");
        } else {
            System.out.println(a);
        }
    }

    public int validate(String a, String atp) {
        if (a.length() <= 0 || atp.length() <= 0) {
            return 0;
        }
        User us = new User();
        us.Validate(a, atp);
        an = a;
        at = atp;
        CheckBalance cb = new CheckBalance();
        int i = cb.Validate(an, at);
        if (i != 0) {
            FundTransfer fund = new FundTransfer();
            fund.FundTrans(an, atp, an, atp, i);
        }
        return i;
    }
}
