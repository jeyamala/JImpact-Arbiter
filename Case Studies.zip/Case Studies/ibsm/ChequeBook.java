package ibsm;

import java.sql.*;

public class ChequeBook extends OnlineServices {

    String ano, at, sacn, sql, sql1, sql2;
    int cls, cle, clee;

    public int GetDetails(String an, String at) {
        ProfileUpdation p = new ProfileUpdation();
        sacn = Validate(an, at);
        p.UpDetails(an, at, at, at, ano);
        if (sacn == null || sacn.equals("")) {
            System.out.println("Sub account type is not exist");
            return 0;
        } else {
            return 1;
        }
    }

    public String ChkBk(String a, String atp) {
        ano = a;
        at = atp;
        String ret = "Cheque Book Request Accepted";
        int t = GetDetails(ano, at);
        if (t == 1) {
            if (at.equals("cur")) {
                sql = "select * from current";
            } else if (at.equals("sav")) {
                sql = "select * from saving";
            } else if (at.equals("fd") || (at.equals("rd"))) {
                ret = "NO CHEQUE BOOK FACILITY FOR THIS ACC TYPE";
                return ret;
            }

            try {
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
                Statement s = c.createStatement();
                ResultSet rs = s.executeQuery(sql);
                while (rs.next()) {
                    cls = rs.getInt(3);
                    cle = rs.getInt(4);
                }
                if ((cle - cls) > 0) {
                    clee = cle + 10;
                    if (at.equals("cur")) {
                        sql2 = "update current set cbe='" + clee + "' where cur='" + sacn + "'";
                    } else if (at.equals("sav")) {
                        sql2 = "update saving set cbe='" + clee + "' where sav='" + sacn + "'";
                    }
                    s.executeQuery(sql2);
                    ret = "Cheque Book Request Accepted";
                    return ret;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            return ret;
        } else {
            ret = "Account Not Exist";
            return ret;
        }
    }

    public String ChkBkSt(String a, String atp) {
        ano = a;
        at = atp;
        String ret1 = "";
        int t = GetDetails(ano, at);
        if (t == 1) {
            if (at.equals("cur")) {
                sql = "select * from current";
            } else if (at.equals("sav")) {
                sql = "select * from saving";
            } else if (at.equals("fd") || (at.equals("rd"))) {
                ret1 = "NO CHEQUE BOOK FACILITY FOR THIS ACC TYPE";
                return ret1;
            }
            try {
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
                Statement s = c.createStatement();
                ResultSet rs = s.executeQuery(sql);
                while (rs.next()) {
                    cls = rs.getInt(3);
                    cle = rs.getInt(4);
                }
                if ((cle - cls) > 0) {
                    ret1 = "YOUR CHEQUE BOKK LEAVES ARE TOO LOW PLS REQUEST FOR CHEQUE BOOK";
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        } else {
            ret1 = "ACOUNT NOT EXIST";
        }
        return ret1;
    }
}
