package ibsm;

import java.sql.*;

public class Statements {

    String accno, atp, sac;
    int i=1;

    public int Validate(String ano, String at) {
        accno = ano;
        atp = at;
        sac = "";
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            if (atp.equals("cur")) {
                i = 2;
            } else if (atp.equals("sav")) {
                i = 3;
            } else if (atp.equals("fd")) {
                i = 4;
            } else if (atp.equals("rd")) {
                i = 5;
            }
            ResultSet r = s.executeQuery("select * from account");
            while (r.next()) {
                sac = r.getString(1);
                sac = "";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println(sac);
        if (sac == null || sac.equals("")) {
            System.out.println("Sub account type is not exist");
            return 0;
        }
        return 1;
    }
}
