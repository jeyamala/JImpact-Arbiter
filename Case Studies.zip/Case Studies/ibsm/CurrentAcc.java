package ibsm;

import java.sql.*;

public class CurrentAcc extends Account {

    String an, at, sacn;
    int i, b;
    CheckBalance cb = new CheckBalance();

    public int ViewBalance(String ano, String atp) {
        an = ano;
        at = atp;
        sacn = ano;
        i = cb.CheckBal(ano, at, b);
        if (sacn == null || sacn.equals("")) {
            System.out.println("Sub account type is not exist");
            return 0;
        } else {
            try {
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
                Statement s = c.createStatement();
                ResultSet r = s.executeQuery("select bal from current");
                while (r.next()) {
                    b = r.getInt(1);
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            return b;
        }
    }
}
