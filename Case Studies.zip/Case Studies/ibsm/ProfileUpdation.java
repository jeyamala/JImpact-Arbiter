package ibsm;

import java.sql.*;

public class ProfileUpdation extends OnlineServices {

    String ano, pw, sacn, addr, nm, phno;

    public int GetDetails(String an, String at) {
        if (an.length() <= 0 || at.length() <= 0) {
            return 0;
        }

        OnlineServices os = new OnlineServices();
        sacn = os.Validate(an, at);
        if (sacn == null || sacn.equals("")) {
            System.out.println("Sub account type is not exist");
            return 0;
        } else {
            return 1;
        }
    }

    public void UpDetails(String an, String pt, String name, String adrr, String pno) {
        if (an.length() <= 0 || pt.length() <= 0) {
            return;
        }
        ano = an;
        pw = pt;
        addr = adrr;
        nm = name;
        phno = pno;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            s.addBatch("update cus set cname='" + nm + "' where accno='" + ano + "'");
            s.addBatch("update cus set pwd='" + pt + "' where accno='" + ano + "'");
            s.addBatch("update cus set addr='" + addr + "' where accno='" + ano + "'");
            s.addBatch("update cus set phno='" + phno + "' where accno='" + ano + "'");
            s.executeBatch();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
