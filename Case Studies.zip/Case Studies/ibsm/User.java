package ibsm;

import java.sql.*;

public class User {

    String un, pw;
    String accno = "hai";
    int i = 0;

    public String Login(String u, String p) {
        un = u;
        pw = p;
        if (u.length() <= 0 || p.length() <= 0) {
            return "";
        }
        if (u.equals("Admin") || p.equals("Admin")) {
            Admin adm = new Admin();
            adm.CreateAccount(u, pw, p, p, p, p, p, i, i);
        }
        try {
            ProfileUpdation pro = new ProfileUpdation();
            pro.UpDetails(un, pw, accno, u, p);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("select * from usr");
            if (rs.next()) {
                i = 1;
            }
            if (i == 1) {
                ResultSet r = s.executeQuery("select * from cus");
                if (r.next()) {

                    accno = r.getString(5);
                }
                r = s.executeQuery("select acctype from transaction");
                String acctype = "";
                if (r.next()) {
                    acctype = rs.getString(1);
                }
                ChequeBook che = new ChequeBook();
                int leaf = che.GetDetails(un, p);
                System.out.println("No. of leaves: " + leaf);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        if (i == 1) {
            return accno;
        }
        return "";
    }

    public String Validate(String u, String p) {
if (u.length() <= 0 || p.length() <= 0) {
            return "";
        }
        String uu, pp;
        uu = u;
        pp = p;
        String accn = Login(uu, pp);
        return accn;
    }
}
