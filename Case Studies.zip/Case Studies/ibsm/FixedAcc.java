package ibsm;

import java.sql.*;

public class FixedAcc extends Account {

    String an, at, sacn;
    int b;

    public int ViewBalance(String ano, String atp) {
        if (ano.length() <= 0 || atp.length() <= 0) {
            return 0;
        }
        an = ano;
        at = atp;
        sacn = ano;
        if (sacn != null || !sacn.equals("")) {
            try {
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
                Statement s = c.createStatement();
                ResultSet r = s.executeQuery("select amt from fixed");
                if (r.next()) {
                    b = r.getInt(1);
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        return b;
    }
}
