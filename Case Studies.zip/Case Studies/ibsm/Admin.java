package ibsm;

import java.sql.*;
import java.util.*;

public class Admin extends User {

    String uid, pwd, nm, gr, atp, adr, phno, accno;
    int bal, ac, m;
    int in = 1;
    GregorianCalendar gc = new GregorianCalendar();
    int month = gc.get(Calendar.MONTH) + 1;
    String dt = gc.get(Calendar.DATE) + "/" + month + "/" + gc.get(Calendar.YEAR);

    public void CreateAccount(String u, String pwr, String n, String g, String at, String a, String p, int ba, int mn) {
        if (u.length() <= 0 || pwr.length() <= 0) {
            return;
        }
        //  Account ac1 = new Account();
        //  ac1.Validate(u, pwr);
        uid = u;
        pwd = pwr;
        nm = n;
        gr = g;
        atp = at;
        adr = a;
        phno = p;
        bal = ba;
        m = mn;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            ResultSet r = s.executeQuery("select accno from cus");
            while (r.next()) {
                accno = r.getString(1);
            }
            System.out.println(accno);
            ac = Integer.parseInt(accno) + 1;
            accno = Integer.toString(ac);
            System.out.println(accno);
            s.executeUpdate("insert into usr values('" + uid + "','" + pwd + "')");
            System.out.println("account created successfully.......");
           
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        //  User ui = new User();
        //  ui.Validate(uid, pwd);
    }

    public void crac(String at, String acn, int bal, int mn) {
        if (acn.length() <= 0 || at.length() <= 0) {
            return;
        }
        String t, tt, a, sacn;
        int b, mon;
        tt = "cr";
        t = at;
        a = acn;
        b = bal;
        mon = mn;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            if (t.equals("cur")) {
                sacn = a + "c";
                s.executeUpdate("insert into account(accno,cur) values('" + a + "','" + sacn + "')");
                s.executeUpdate("insert into current(cur,bal,cbs,cbe) values('" + sacn + "'," + b + ",10,20)");
                s.executeUpdate("insert into transaction(accno,acctype,trantype,trandt,amt) values ('" + a + "','" + t + "','" + tt + "','" + dt + "'," + b + ")");
            } else if (t.equals("sav")) {
                sacn = a + "s";
                s.executeUpdate("insert into account(accno,sav) values('" + a + "','" + sacn + "')");
                s.executeUpdate("insert into saving(sav,bal,cbs,cbe) values('" + sacn + "'," + b + ",10,20)");
                s.executeUpdate("insert into transaction(accno,acctype,trantype,trandt,amt) values ('" + a + "','" + t + "','" + tt + "','" + dt + "'," + b + ")");
            } else if (t.equals("fd")) {
                sacn = a + "f";
                s.executeUpdate("insert into account(accno,fd) values('" + a + "','" + sacn + "')");                
                in=6;
                s.executeUpdate("insert into fixed(fd,amt,no_yr,intr) values('" + sacn + "'," + b + "," + mon + "," + in + ")");
                s.executeUpdate("insert into transaction(accno,acctype,trantype,trandt,amt) values ('" + a + "','" + t + "','" + tt + "','" + dt + "'," + b + ")");
            } else if (t.equals("rd")) {
                sacn = a + "r";
                s.executeUpdate("insert into account(accno,rd) values('" + a + "','" + sacn + "')");
                in=4;
                s.executeUpdate("insert into rd values('" + sacn + "'," + b + "," + mon + "," + in + ")");
                s.executeUpdate("insert into transaction(accno,acctype,trantype,trandt,amt) values ('" + a + "','" + t + "','" + tt + "','" + dt + "'," + b + ")");
            }            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void DeleteAcc(String acn) {
        String ano = acn;
        String cr = "", sv = "", f = "", rc = "";
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            ResultSet r = s.executeQuery("select * from account");
            if (r.next()) {
                cr = r.getString(2);
                sv = r.getString(3);
                f = r.getString(4);
                rc = r.getString(5);
            }
            s.addBatch("delete from cus where accno='" + ano + "'");
            s.addBatch("delete from account where accno='" + ano + "'");
            if (cr != null) {
                s.addBatch("delete from current where cur='" + cr + "'");
            }
            if (sv != null) {
                s.addBatch("delete from saving where sav='" + sv + "'");
            }
            if (f != null) {
                s.addBatch("delete from fixed where fd='" + f + "'");
            }
            if (rc != null) {
                s.addBatch("delete from recurring where rd='" + rc + "'");
            }
            s.executeBatch();
            System.out.println("ACCOUNT DELETED SUCCESSFULLY..");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void DeleteSubAcc(String acn, String atp) {
        String ano = acn;
        String ap = atp;
        String n = "";
        String cr = "", sv = "", f = "", rc = "";
        int a = 0;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("select * from cus");
            if (rs.next()) {
                a = 1;
            }
            if (a == 1) {
                ResultSet r = s.executeQuery("select * from account");
                if (r.next()) {
                    cr = r.getString(2);
                    sv = r.getString(3);
                    f = r.getString(4);
                    rc = r.getString(5);
                }
                if ((cr != null) || (ap.equals("cur"))) {
                    s.addBatch("delete from current where cur='" + cr + "'");
                    s.addBatch("update account set cur ='" + n + "' where accno='" + ano + "'");
                }
                if ((sv != null) || (ap.equals("sav"))) {
                    s.addBatch("delete from saving where sav='" + sv + "'");
                    s.addBatch("update account set sav ='" + n + "' where accno='" + ano + "'");
                }
                if ((f != null) || (ap.equals("fd"))) {
                    s.addBatch("delete from fixed where fd='" + f + "'");
                    s.addBatch("update account set fd ='" + n + "' where accno='" + ano + "'");
                }
                if ((rc != null) || (ap.equals("rd"))) {
                    s.addBatch("delete from recurring where rd='" + rc + "'");
                    s.addBatch("update account set rd ='" + n + "' where accno='" + ano + "'");
                }
                s.executeBatch();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
