package ibsm;

public class Month extends Statements {

    String acno, actp;

    public int validate(String ac, String at) {
        if (ac.length() <= 0 || at.length() <= 0) {
            return -1;
        }
        acno = ac;
        actp = at;
        Statements y = new Statements();
        int j = y.Validate(acno, actp);
        return j;
    }

    public void display() {
        System.out.println("Month is created.");
    }
}
