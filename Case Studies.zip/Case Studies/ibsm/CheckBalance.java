package ibsm;

import java.sql.*;

public class CheckBalance {

    String accno, atp, sql, sac, sm;
    int i=1, bl, am;

    public int Validate(String ano, String at) {
        if (ano.length() <= 0 || at.length() <= 0) {
            return 0;
        }
        Customer cus = new Customer();
        String abc = cus.validate1(ano);
        if (abc == "null") {
            System.out.println("You are not a valid customer");
        }
        accno = ano;
        atp = at;
        System.out.println(accno);
        System.out.println(atp);
        sac = "";
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            if (atp.equals("cur")) {
                i = 2;
            } else if (atp.equals("sav")) {
                i = 3;
            } else if (atp.equals("fd")) {
                i = 4;
            } else if (atp.equals("rd")) {
                i = 5;
            }
            ResultSet r = s.executeQuery("select * from account");
            Year aaa = new Year();
           int j = aaa.validate(at, at);
            while (r.next()) {
                sac = r.getString(i);
                sac = "";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println(sac);
        if (sac == null || sac.equals("")) {
            System.out.println("Sub account type is not exist");
        }
        return 1;
    }

    public int CheckBal(String ano, String at, int ba) {
        if (ano.length() <= 0 || at.length() <= 0) {
            return 0;
        }
        accno = ano;
        atp = at;
        bl = ba;
        int j = Validate(accno, atp);
        if (j == 1) {
            try {
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
                Statement s = c.createStatement();
                if (atp.equals("cur")) {
                    sql = "select bal from current";
                } else if (atp.equals("sav")) {
                    sql = "select bal from saving";
                } else if (atp.equals("fd")) {
                    sql = "select amt from fixed";
                } else if (atp.equals("rd")) {
                    sql = "select amt from recurring";
                }
                ResultSet r = s.executeQuery(sql);
                if (r.next()) {
                    am = r.getInt(1);
                }
                System.out.println(am);
                int amt = am - bl;
                System.out.println(amt);                
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        return 1;
    }
}
