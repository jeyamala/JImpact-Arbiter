package ibsm;

import java.sql.*;
import java.util.*;

public class Withdraw extends Transaction {

    private String an, at, sql, sql1, sac;
    String tt;
    GregorianCalendar gc = new GregorianCalendar();
    int month = gc.get(Calendar.MONTH) + 1;
    String dt = gc.get(Calendar.DATE) + "/" + month + "/" + gc.get(Calendar.YEAR);
    int bln, j, am;

    public int Check(String a, String atp, int b) {
        if (a.length() <= 0 || atp.length() <= 0 || b <= 0) {
            return 0;
        }
        an = a;
        at = atp;
        bln = b;
        CheckBalance cb = new CheckBalance();
        int k = cb.CheckBal(an, at, bln);
        return k;
    }

    public int WithBalance(String a, String atp, int b, String t) {
        if (a.length() <= 0 || atp.length() <= 0 || b <= 0 || t.length() <= 0) {
            return 0;
        }
        an = a;
        at = atp;
        bln = b;
        tt = t;
        Withdraw d = new Withdraw();
        int i = d.validate(an, at);
        if (i != 0) {
            j = Check(an, at, bln);
            if (j != 0) {
                try {
                    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                    Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
                    Statement s = c.createStatement();
                    if (at.equals("cur")) {
                        sql = "select cur from account";
                    } else if (at.equals("sav")) {
                        sql = "select sav from account";
                    } else if (at.equals("fd")) {
                        sql = "select fd from account";
                    } else if (at.equals("rd")) {
                        sql = "select rd from account";
                    }
                    ResultSet r = s.executeQuery(sql);
                    while (r.next()) {
                        sac = r.getString(1);
                    }
                    if (at.equals("cur")) {
                        sql1 = "select bal from current";
                    } else if (at.equals("sav")) {
                        sql1 = "select bal from saving";
                    } else if (at.equals("fd")) {
                        sql1 = "select amt from fixed";
                    } else if (at.equals("rd")) {
                        sql1 = "select amt from recurring";
                    }
                    ResultSet rs = s.executeQuery(sql1);
                    while (rs.next()) {
                        am = rs.getInt(1);
                    }
                    am = am - bln;
                    if (at.equals("cur")) {
                        sql = "update current set bal = " + am + " where cur = '" + sac + "'";
                    } else if (at.equals("sav")) {
                        sql = "update saving set bal = " + am + "  where sav = '" + sac + "'";
                    } else if (at.equals("fd")) {
                        sql = "update fixed set amt = " + am + " where fd = '" + sac + "'";
                    } else if (at.equals("rd")) {
                        sql = "update recurring set amt = " + am + " where rd = '" + sac + "'";
                    }
                    j = s.executeUpdate(sql);
                    s.executeUpdate("insert into transaction(accno,acctype,trantype,trandt,amt) values ('" + an + "','" + at + "','" + tt + "','" + dt + "'," + bln + ")");
                    c.commit();
                    c.close();
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                return 1;
            }
        }
        return j;
    }
}
