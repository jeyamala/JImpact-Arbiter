package ibsm;

public class FundTransfer {

    private String fano, fat, sano, sat;
    int bal;
    String tt = "with";
    int i, j;
    Deposit d = new Deposit();
    Withdraw w = new Withdraw();

    public int FundTrans(String fan, String fatp, String san, String satp, int amt) {
        if (fan.length() <= 0 || fatp.length() <= 0) {
            return 0;
        }
        sat = fatp;
        fat = fatp;
        bal = amt;
        fano = fan;
        sano = san;
        if (fat.equals(sat)) {
            String t = "ftrans";
            //  i = d.DebitBalance(sano, sat, bal, t);
            //  j = w.WithBalance(fano, fat, bal, t);
            i = 1;
            j = 1;
            if ((i == 1) || (j == 1)) {
                System.out.println("Fund Transfer DONE Successfully....");
                return 1;
            }
        }
        return 0;
    }
}
