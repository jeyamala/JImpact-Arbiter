package ibsm;

public class Year extends Statements {

    String acno, actp;

    public int validate(String ac, String at) {
        if (ac.length() <= 0 || at.length() <= 0) {
            return 0;
        }
        acno = ac;
        actp = at;
        Statements st = new Statements();
        int j = st.Validate(acno, actp);
        return j;
    }
}
