package ibsm;

import java.sql.*;

public class Account {

    String acno, acct, sac;
    int i=1;

    public String Validate(String an, String at) {
        if (an.length() <= 0 || at.length() <= 0) {
            return "";
        }
        Transaction ts = new Transaction();
        ts.display(at);
        acno = an;
        acct = at;
        CheckBalance cb = new CheckBalance();
        if (acct.equals("cur")) {
            i = 2;
            CurrentAcc cura = new CurrentAcc();
            cura.ViewBalance(an, at);
        } else if (acct.equals("sav")) {
            i = 3;
            SavingAcc sava = new SavingAcc();
            sava.ViewBalance(an, at);
        } else if (acct.equals("fd")) {
            i = 4;
            FixedAcc fixa = new FixedAcc();
            fixa.ViewBalance(an, at);
        } else if (acct.equals("rd")) {
            i = 5;
            RecurringAcc reca = new RecurringAcc();
            reca.ViewBalance(an, at);
        }
        try {
            int j = cb.Validate(an, at);
           System.out.println("Value :"+j);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c = DriverManager.getConnection("jdbc:odbc:ibs", "", "");
            Statement s = c.createStatement();
            ResultSet r = s.executeQuery("select * from cus");
            if (r.next()) {
                System.out.println("Account Exist");
            }
            ResultSet rs = s.executeQuery("select * from account");
            if (rs.next()) {
                sac = rs.getString(i);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return sac;
    }
}
