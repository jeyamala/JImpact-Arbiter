/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymgt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Administrator
 */
public class Staff extends Membership {

    public void stockcheck(int memid) {
        if( memid < 0)
            return;
        Transaction bf = new Transaction();
        int no = bf.bookcount("name");
        System.out.println("Book count :" + no);

        Issuebook issue = new Issuebook();
        if ( issue.issuedbook(memid) < 0 )
        System.out.println("invalid");
        else {
        try {
            Student stud = new Student();
            int count = stud.noofstudent("exdt");
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select * from Student where memid=" + no);
            System.out.println("Student details: ");
            while (rs.next()) {
                System.out.println(rs.getString(1) + " -- " + rs.getString(1));
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        }
    }
}
