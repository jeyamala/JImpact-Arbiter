/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymgt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Administrator
 */
public class Search {

    int bookno, copies;
    String isbnno, title, subject, author, publisher, edition, cost;

    public String search(int bookid) {
        if (bookid < 0) {
            return "NO Data";
        }
        String res = "";
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select * from Book where bookno=" + bookid);
            while (rs.next()) {
                res = res + rs.getString(1);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
            return "Exception";
        }
        return res;
    }
}
