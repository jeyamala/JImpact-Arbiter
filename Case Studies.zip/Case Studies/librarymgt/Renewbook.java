package librarymgt;

import java.sql.*;

public class Renewbook {

    int bno, memid, ncopies;
    String issdate, duedate, redt, fine, exdt;

    public void Renewbookinfodetails(int bnoo, int memidd, int ncopiess, String issdatee, String duedatee, String redtt, String finee, String exdtt) {
        if (bnoo <= 0 || memidd <= 0 || ncopiess <= 0 || issdatee == null || duedatee == null || redtt == null || finee == null || exdtt == null) {
            return;
        }
        bno = bnoo;
        memid = memidd;
        ncopies = ncopiess;
        issdate = issdatee;
        duedate = duedatee;
        redt = redtt;
        fine = finee;
        exdt = exdtt;
        Returnbook rebook = new Returnbook();
        rebook.returndate(bnoo);
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Renewbook values(" + bno + "," + memid + "," + ncopies + ",'" + issdate + "','" + duedate + "','" + redt + "','" + fine + "','" + exdt + "')");
            System.out.println("Renewbooks details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public String renewdate(int memid) {
        if (memid <= 0) {
            return "hai";
        }
        String redate = "";
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select renewdate from Renewbook where memid=" + memid);
            if (rs.next()) {
                redate = rs.getString(1);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
            redate = "";
        }
        return redate;
    }
}
