package librarymgt;

import java.sql.*;

public class Issuebook {

    int bno, ncopies;
    String memid, issdate, duedate;

    public void Issuebookdetails(int bnoo, String memidd, int ncopiess, String issdatee, String duedatee) {
        if (bnoo <= 0 || memidd == null || ncopiess <= 0 || issdatee == null || duedatee == null) {
            return;
        }
        Student st = new Student();
        st.Studentdetails(bnoo, bnoo, memid, issdatee, memid);

        Transaction book = new Transaction();
        bno = bnoo;
        memid = memidd;
        ncopies = ncopiess;
        issdate = issdatee;
        duedate = duedatee;
        int count = book.bookcount(memid);
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            if (count <= 0) {
                s.executeUpdate("insert into Issuebook values(" + bno + ",'" + memid + "'," + ncopies + ",'" + issdate + "','" + duedate + "')");
                System.out.println("IssueBook details added successfully");
                c1.commit();
                c1.close();
            } else {
                System.out.println("Not sufficient books");
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public int issuedbook(int memid) {
        if (memid <= 0) {
            return 0;
        }
        int bookcount = 0;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select count(*) from Issuebook where memid=" + memid);
            if (rs.next()) {
                bookcount = rs.getInt(1);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
            bookcount = 0;
        }
        return bookcount;
    }
}
