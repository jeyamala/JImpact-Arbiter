package librarymgt;

import java.sql.*;

public class Membership {

    int memid;
    String exdt, memdt, name, memtype, add, pw, mail;

    public void Memberdetails(int memidd, String exdtt, String memdtt, String namee, String memtypee, String addd, String phh, String maill) {
        if (memidd <= 0 || exdtt == null || memdtt == null || namee == null || memtypee == null || addd == null || phh == null || maill == null) {
            return;
        }
        memid = memidd;
        exdt = exdtt;
        memdt = memdtt;
        name = namee;
        memtype = memtypee;
        add = addd;
        pw = phh;
        mail = maill;
        Staff st = new Staff();
        st.stockcheck(memid);

        try {
            Admin adm = new Admin();
            if ( adm.validate(memidd, pw) > 0) {
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
                Statement s = c1.createStatement();
                s.executeUpdate("insert into Member values(" + memid + ",'" + exdt + "','" + memdt + "','" + name + "','" + memtype + "','" + add + "','" + pw + "', '" + mail + "')");
                System.out.println("Membership details added successfully");
                c1.commit();
                c1.close();

            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public int viewmemberinfo(int memberid) {
        if (memberid <= 0) {
            return 0;
        }
        int no = 0;
        try {
            Student stud = new Student();
            int count = stud.noofstudent(exdt);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select * from Student where memid=" + memberid);

            if (rs.next()) {
                no = rs.getInt(2);
                System.out.println("Student Roll No: " + no);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return no;
    }
}
