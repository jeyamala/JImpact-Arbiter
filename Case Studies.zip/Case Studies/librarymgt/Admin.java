/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymgt;

/**
 *
 * @author Administrator
 */
public class Admin {

    public int validate(int dd, String dnn) {
        if (dnn.length() <= 0) {
            System.out.println("Invalid Details");
            return 0;
        } else {
            Membership m = new Membership();
            if ( m.viewmemberinfo(dd) > 0 ) {
                System.out.println("Login Successful");
                return 1;
            }
        }
        return 0;
    }
}
