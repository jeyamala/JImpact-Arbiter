/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymgt;

import java.sql.*;

/**
 *
 * @author Administrator
 */
public class Digitallibrary {

    int bookno, copies;
    String isbnno, title, subject, author, publisher, edition, cost;

    public void Bookdetails(int booknoo, String isbnnoo, String titlee, String subjectt, String authorr, String publisherr, String editionn, int copiess, String costt) {
        if (booknoo < 0 || isbnnoo == null || titlee == null || subjectt == null || authorr == null || publisherr == null || editionn == null || copiess < 0 || costt == null) {
            return;
        }
        bookno = booknoo;
        copies = copiess;
        isbnno = isbnnoo;
        title = titlee;
        subject = subjectt;
        author = authorr;
        publisher = publisherr;
        edition = editionn;
        cost = costt;


        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Book values(" + bookno + ",'" + isbnno + "','" + title + "','" + subject + "','" + author + "','" + publisher + "','" + edition + "'," + copies + ",'" + cost + "')");
            System.out.println("Book details added successfully");
            Books bk = new Books();
            String temp = bk.getdetails(bookno) + author;
            System.out.println("Book info" + temp);
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public void viewinfo(int bookid) {
        if(bookid <= 0)
            return;
        Search sh = new Search();
        System.out.println(sh.search(bookid));

    }
}
