package librarymgt;

import java.sql.*;

public class Returnbook {

    int bno, memid, ncopies;
    String issdate, duedate, redt;

    public void Returnbookdetails(int bnoo, int memidd, int ncopiess, String issdatee, String duedatee, String redtt, int fine) {
        if (bnoo <= 0 || memidd <= 0 || ncopiess <= 0 || issdatee == null || duedatee == null || redtt == null || fine <0 ) {
            return;
        }
        bno = bnoo;
        memid = memidd;
        ncopies = ncopiess;
        issdate = issdatee;
        duedate = duedatee;
        redt = redtt;
        Collectfine fi = new Collectfine();      
        int finamt = fi.fineamount(bno);
        int temp = finamt - fine;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            if (fine <= 0) {
                s.executeUpdate("insert into Retunbook values(" + bno + "," + memid + "," + ncopies + ",'" + issdate + "','" + duedate + "','" + redt + "','" + temp + "')");
                System.out.println("Returnbooks details added successfully");
                c1.commit();
                c1.close();
            } else {
                System.out.println("Please pay the fees to return the book");
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public String returndate(int memid) {
        if (memid <= 0) {
            return "Error";
        }
        String redate = "";
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select returndate from Retunbook where memid=" + memid);
            if (rs.next()) {
                redate = rs.getString(1);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
            redate = "";
        }
        return redate;
    }
}
