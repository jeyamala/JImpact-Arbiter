package librarymgt;

import java.sql.*;

public class Student {

    int rollno, memid;
    String dept, classname, year;

    public void Studentdetails(int memidd, int rollnoo, String deptt, String classnamee, String yearr) {
        if (rollnoo <= 0 || memidd <=0 || deptt ==null || classnamee == null || yearr == null) {
            return;
        }
        memid = memidd;
        rollno = rollnoo;
        dept = deptt;
        classname = classnamee;
        year = yearr;
        Transaction book = new Transaction();
        Collectfine fine = new Collectfine();
        Membership mem = new Membership();
        int count = book.bookcount(yearr);
        try {
            if ( count >0 )
            {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Student values(" + memid + "," + rollno + ",'" + dept + "','" + classname + "','" + year + "')");
            System.out.println("Student details added successfully");   
            int fineamt = fine.fineamount(memid);
            mem.Memberdetails(memidd, deptt, deptt, yearr, deptt, dept, deptt, yearr);
            c1.commit();
            c1.close();
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public int noofstudent(String dept) {
        if (dept == null) {
            return 0;
        }
        int noof = 0;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select count(*) from Student where dept='" + dept + "'");
            if (rs.next()) {
                noof = rs.getInt(1);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
            noof = 0;
        }
        return noof;
    }

    public void search (int bookid)
    {
        if( bookid < 0 )
            return;
        Digitallibrary dl = new Digitallibrary();
        dl.viewinfo(bookid);
    }
}
