package librarymgt;

import java.sql.*;

public class Transaction {

    int bookno, copies;
    String isbnno, title, subject, author, publisher, edition, cost;

    public void Bookdetails(int booknoo, String isbnnoo, String titlee, String subjectt, String authorr, String publisherr, String editionn, int copiess, String costt) {
        if (booknoo < 0 || isbnnoo == null || titlee == null || subjectt == null || authorr == null || publisherr == null || editionn == null || copiess < 0 || costt == null) {
            return;
        }
        bookno = booknoo;
        copies = copiess;
        isbnno = isbnnoo;
        title = titlee;
        subject = subjectt;
        author = authorr;
        publisher = publisherr;
        edition = editionn;
        cost = costt;

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Book values(" + bookno + ",'" + isbnno + "','" + title + "','" + subject + "','" + author + "','" + publisher + "','" + edition + "'," + copies + ",'" + cost + "')");
            System.out.println("Book details added successfully");

            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public int bookcount(String title) {
        int count = 0;
        if (title == null) {
            return 0;
        }
        Issuebook issue = new Issuebook();
        try {
            int bcount = issue.issuedbook(bookno);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select count(*) from Book where title='" + title + "'");
            if (rs.next()) {
                count = rs.getInt(1);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
            count = 0;
        }
        return count;
    }
}
