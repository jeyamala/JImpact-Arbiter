package librarymgt;

import java.sql.*;

public class Bookpurchase {

    int orderno, bookno, ncopies, bookshopid;
    String isbnno, title, subject, author, edition, cost;

    public void Orderdetails(int ordernoo, int booknoo, int bookshopidd, String isbnnoo, String titlee, String subjectt, String authorr, String editionn, int copiess, String costt) {
        if (ordernoo <= 0 || booknoo < 0 || bookshopidd < 0 || isbnno == null || titlee == null || subjectt == null || authorr == null || editionn == null || copiess <= 0 || costt == null) {
            return;
        }
        Transaction book = new Transaction();
        Bookshop shop = new Bookshop();
        bookno = booknoo;
        ncopies = copiess;
        isbnno = isbnnoo;
        title = titlee;
        subject = subjectt;
        author = authorr;
        orderno = ordernoo;
        bookshopid = bookshopidd;
        edition = editionn;
        cost = costt;
        Admin adm = new Admin();
        adm.validate(orderno, isbnno);

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            if (book.bookcount(title) <= 0) {
                shop.viewBookShop();
                s.executeUpdate("insert into Order values(" + orderno + "," + bookno + "," + bookshopid + ",'" + isbnno + "','" + title + "','" + subject + "','" + author + "','" + edition + "'," + ncopies + ",'" + cost + "')");
                System.out.println("Order details added successfully");
                c1.commit();
                c1.close();
            } else {
                System.out.println("You have enough books");
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public int vieworder(int orderno) {
        if (orderno <= 0) {
            return 0;
        }
        int nocopies = 0;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            String sql = "select count(*) from Book where title='" + title + "'";
            System.out.println("Sql1:" + sql);
            ResultSet rs = s.executeQuery(sql);
            if (rs.next()) {
                nocopies = rs.getInt(1);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
            nocopies = 0;
        }
        return nocopies;
    }
}
