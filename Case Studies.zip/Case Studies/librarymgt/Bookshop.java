package librarymgt;

import java.sql.*;

public class Bookshop {

    int bid;
    String bname, add, ph, mail;

    public void Bookshopdetails(int bidd, String bnamee, String addd, String phh, String maill) {
        if (bidd <= 0 || bnamee == null || addd == null || phh == null || maill == null) {
            return;
        }
        bid = bidd;
        bname = bnamee;
        add = addd;
        ph = phh;
        mail = maill;

        Payment paymen = new Payment();
        try {
            if ( paymen.paymentcost(bid) > 0) {
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
                Statement s = c1.createStatement();
                s.executeUpdate("insert into Bookshop values(" + bid + ",'" + bname + "','" + add + "','" + ph + "','" + mail + "')");
                System.out.println("Bookshop details added successfully");
                c1.commit();
                c1.close();
            } else {
                System.out.println("Invalid");
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public void viewBookShop() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select * from Bookshop");
            if (rs.next()) {
                System.out.println("BookShop Name: " + rs.getString(2));
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}
