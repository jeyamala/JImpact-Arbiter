package librarymgt;

import java.sql.*;

public class Payment {

    int ordid, bshopid, totalcost, paidamt, balamt;
    String sts;

    public void Paymentdetails(int ordidd, int bshopidd, int totalcostt, int paidamtt, int balamtt, String stss) {
        if( ordidd <=0 || bshopidd <=0 || totalcostt <=0 || paidamtt <=0 || balamtt <=0 || stss.length() < 0)
        return ;
        ordid = ordidd;
        bshopid = bshopidd;
        totalcost = totalcostt;
        paidamt = paidamtt;
        balamt = balamtt;
        sts = stss;

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            String sql="insert into Payment values(" + ordid + "," + bshopid + "," + totalcost + "," + paidamt + "," + balamt + ",'" + sts + "')";
            System.out.println("Sql:"+sql);
            s.executeUpdate(sql);
            System.out.println("Payment details added successfully");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public int paymentcost(int bookshopid) {
        if(bookshopid<=0)
            return 0;
        Bookpurchase order = new Bookpurchase();
        int cost = 0;
        try {
            int bookcount = order.vieworder(ordid);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select totalcost,paidamt from Payment where bookshopid=" + bookshopid);
            if (rs.next()) {
                cost = rs.getInt(1) - rs.getInt(2);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
            cost = 0;
        }
        return cost;
    }
}
