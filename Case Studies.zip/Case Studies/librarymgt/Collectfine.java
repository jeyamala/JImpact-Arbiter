package librarymgt;

import java.sql.*;

public class Collectfine {

    int fine, memid;
    String sts;

    public void Finedetails(int memidd, int finee, String stss) {
        if (memidd <= 0 || finee <= 0 || stss == null) {
            return;
        }
        memid = memidd;
        fine = finee;
        sts = stss;
        Renewbook rb = new Renewbook();
        String temp = rb.renewdate(memid) + stss;
        System.out.println(temp);
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Fine values(" + memid + "," + fine + ",'" + sts + "')");
            System.out.println("Fine details added successfully");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public int fineamount(int memberid) {
        if (memberid < 0) {
            return 0;
        }
        int fine1 = 0;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Library", "", "");
            Statement s = c1.createStatement();
            ResultSet rs = s.executeQuery("select fineamt from Fine where memid=" + memberid);
            if (rs.next()) {
                fine1 = rs.getInt(1);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.toString());
            fine1 = 0;
        }
        return fine1;
    }
}
