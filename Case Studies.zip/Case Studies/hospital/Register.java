package hospital;

import java.io.*;
import java.sql.*;

public class Register {

    String sql, sql2, sql1, rd, rt, rch, pt, pn;
    int p, r, w;
    int m;
    int pi, n;
    String add, dd, wno, bno, ch;
    String y = "Yes";
    int i;

    public void Registerdetail(int pp, String pnn, int rr, String rdd, String rtt, String rchh, String ptt) {
        if (rdd.length() <= 0 && ptt.length() <= 0) {
            System.out.println("Invalid details");
        }
        p = pp;
        r = rr;
        rd = rdd;
        rt = rtt;
        rch = rchh;
        pt = ptt;
        pn = pnn;
        Patient re = new Patient();
        p = re.pno();
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into register values(" + p + ",'" + pn + "'," + r + ",'" + rd + "','" + rt + "','" + rch + "','" + pt + "')");
            s.executeUpdate("insert into patreport(pid) values(" + p + ")");
            s.executeUpdate("insert into Billing(pid) values(" + p + ")");
            System.out.println("Patient Registered successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int rno() {
        int a = 1;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("Jdbc:Odbc:pat");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select rid from register");
            while (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }

    public void Registercharge(int pp) {
        p = pp;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            sql1 = "update Billing set regcharge ='" + rch + "' where pid = " + p + "";
            w = s.executeUpdate(sql1);
            System.out.println(w);
            System.out.println("Registration Charge updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Wardallotment(int pii, String addd, String ddd, int nn, String wnoo, String bnoo, String chh) {
        pi = pii;
        add = addd;
        dd = ddd;
        n = nn;
        wno = wnoo;
        bno = bnoo;
        ch = chh;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            Statement s1 = c1.createStatement();
            Statement s2 = c1.createStatement();
            s.executeUpdate("insert into allot values(" + pi + ",'" + add + "','" + dd + "'," + n + ",'" + wno + "','" + bno + "','" + ch + "')");
            s1.executeUpdate("insert into inpatient(pid,wno,bno) values(" + pi + ",'" + wno + "','" + bno + "')");

            sql1 = "update ward set stat ='" + y + "' where wno = '" + wno + "'";
            i = s2.executeUpdate(sql1);

            System.out.println("Ward Alloted successfully.......");
            System.out.println("Inpatient record updated successfully.......");
            System.out.println("Ward updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Wardcharge(int pii) {

        pi = pii;

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            sql = "update Billing set wardch ='" + ch + "' where pid =" + pi + "";
            w = s.executeUpdate(sql);
            System.out.println("Ward Charge Detail updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
