package hospital;

import java.sql.*;

public class Nurse extends Staff {

    String d, de, n;
    int doc, pi, e;
    String sql1;

    public void Nursedetail(int ee, String dd, String nn, int docc, int pii) {
        if (nn.length() <= 0 && dd.length() <= 0) {
            System.out.println("Invalid details");
        }
        Staff si = new Staff();
        d = dd;
        doc = docc;
        pi = pii;
        n = nn;
        e = ee;
        ee = si.eno();
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s1 = c1.createStatement();
//            String sql1="Select empid from Staff1 where des='Nurse'";

            Statement s = c1.createStatement();
//            s1.executeQuery(sql1);
//


            s.executeUpdate("insert into Nurse values(" + e + ",'" + d + "','" + n + "'," + doc + "," + pi + ")");
            System.out.println("Nurse Detail Added successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
