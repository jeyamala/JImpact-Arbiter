package hospital;

import java.sql.*;

public class DietInfo extends Treatments {

    int pid, did, m, tid;
    String pn, da, dn;

    public void Dietdetail(int tidd, int pidd, String pnn, int didd, String dnn, String daa) {
        if (pnn.length() <= 0 && daa.length() <= 0) {
            System.out.println("Invalid details");
        }
        Treatments tin = new Treatments();
        tid = tin.tno();
        pid = pidd;
        pn = pnn;
        da = daa;
        tid = tidd;
        dn = dnn;
        did = didd;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into diet values(" + tid + "," + pid + ",'" + pn + "'," + did + ",'" + dn + "','" + da + "')");

//            
//
            String sql = "update patreport set dietre ='" + da + "' where pid = " + pid + "";
            m = s.executeUpdate(sql);


            System.out.println("Diet Details Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Dietreport(int pidd, String daa) {
        if (daa.equals("null")) {
            System.out.println("Invalid details");
        }
        pid = pidd;
        da = daa;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into diet values(" + tid + "," + pid + ",'" + pn + "'," + did + ",'" + da + "')");
            String sql = "update patreport set dietre ='" + da + "' where pid = " + pid + "";
            m = s.executeUpdate(sql);
            System.out.println("Diet Report Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public int Validate(int pidd, int didd, String dnn) {

        pid = pidd;
        dn = dnn;
        did = didd;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            ResultSet r = s.executeQuery("select pid,did,disn from Diet where pid=" + pid + " and did=" + did + " and disn='" + dn + "'");
            if (r.next()) {
                m = 1;
            } else {
                m = 0;
            }

            System.out.println("Staff details already exist");

            c1.commit();
            c1.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return m;
    }
}
