package hospital;

import java.sql.*;

public class Bills {

    int rc, tc, mc, dc, oc, ic, tot, wc;
    int bi, pi;
    String bd, pn, pt, rn, da, dd, re;
    String ad, at;
    static int a = 0;

    public void Billdetail(int bii, String bdd, int pii, String pnn, String ptt, String rnn, String daa, String ddd, int rcc, int tcc, int mcc, int wcc, int dcc, int occ, int icc, String ree, int totc) {
        if (bdd.length() <= 0 && ptt.length() <= 0) {
            System.out.println("Invalid details");
        }
        Wardallot war = new Wardallot();
        war.Wardcharge(pii);
        Register reg = new Register();
        reg.Registercharge(pii);
        bi = bii;
        bd = bdd;
        pi = pii;
        pn = pnn;
        pt = ptt;
        rn = rnn;
        da = daa;
        dd = ddd;
        rc = rcc;
        tc = tcc;
        wc = wcc;
        mc = mcc;
        dc = dcc;
        oc = occ;
        ic = icc;
        tot = totc;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Bills values(" + bi + ",'" + bd + "'," + pi + ",'" + pn + "','" + pt + "','" + rn + "','" + da + "','" + dd + "'," + rc + "," + tc + "," + mc + "," + wc + "," + dc + "," + oc + "," + ic + ",'" + re + "'," + tot + ")");
            System.out.println("Bills record updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int bno() {

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("Jdbc:Odbc:pat");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select Billno from Bills");
            while (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
