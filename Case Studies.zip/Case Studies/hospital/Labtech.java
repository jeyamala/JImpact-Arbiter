/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.sql.*;

public class Labtech extends Staff {

    String l, d;
    String sql1, j;
    int i, e;

    public void Labtechdetail(int ee, String ll, String dd) {
        if (ll.length() <= 0 && dd.length() <= 0) {
            System.out.println("Invalid details");
        }
        Staff ss = new Staff();
        l = ll;
        d = dd;
        e = ee;
        e = ss.eno();
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            //  Statement s1 = c1.createStatement();
            //System.out.println("lly.......");
            s.executeUpdate("insert into labtech values(" + e + ",'" + l + "','" + d + "')");
            //            sql1 = "update inpatient set admitdate = '"+ad+"' and diseasetype='"+dt+"' and stat ='"+st+"' where pid = "+p+"";
//            i = s1.executeUpdate(sql1);
            System.out.println("Labt Tech Details Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
