package hospital;

import java.sql.*;

public class Wardallot {

    String add, dd, wno, bno, ch; //pi,ad,dd,n,wno,bno,ch
    int pi, n;
    String y = "Y";
    String sql, sql1, sql2, sql3, j, k;
    int i, w;

    public void Wardallotment(int pii, String addd, String ddd, int nn, String wnoo, String bnoo, String chh) {
        if (addd.length() <= 0 && ddd.length() <= 0) {
            System.out.println("Invalid details");
        }
        Ward wa = new Ward();
        pi = pii;
        add = addd;
        dd = ddd;
        n = nn;
        wno = wnoo;
        bno = bnoo;
        ch = chh;
        wa.Warddetail(dd, dd, dd, chh, dd);
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
//            Statement s1 = c1.createStatement();
//            Statement s2 = c1.createStatement();
            s.executeUpdate("insert into allot values(" + pi + ",'" + add + "','" + dd + "'," + n + ",'" + wno + "','" + bno + "','" + ch + "')");
            s.executeUpdate("insert into inpatient(pid,wno,bno) values(" + pi + ",'" + wno + "','" + bno + "')");
            sql1 = "update ward set stat ='" + y + "' where wno = '" + wno + "'";
            s.executeUpdate("insert into inpatient(pid,wno,bno) values(" + pi + ",'" + wno + "','" + bno + "')");
            sql2 = "update ward set stat ='" + y + "' where wno = '" + wno + "'";
            i = s.executeUpdate(sql2);

            sql3 = "update Billing set wcharge ='" + ch + "' where pid = " + pi + "";
            w = s.executeUpdate(sql3);
            //s.executeUpdate("insert into inpatient(pid,wno,bno) values("+pi+",'"+wno+"','"+bno+"')");


            s.executeUpdate("insert into Billing(wcharge)values('" + wno + "')");
            System.out.println(wno);
            System.out.println("Ward Alloted successfully.......");
            System.out.println("Inpatient record updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Wardcharge(int pii) {
        if (pii == 0) {
            pii += 1;
        }
        // pi=pii; opn=opnn; opth=opthh;odt=odtt;opch=opchh;
        //pi=pii;opth=opthh; opn=opnn; od=odd; ot=ott; opch=opchh; rt=rtt;
        pi = pii;

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            //          s.executeUpdate("insert into Operation values("+opi+","+ti+","+pi+",'"+opth+"','"+opn+"',"+di+",'"+od+"','"+ot+"','"+opch+"','"+rt+"')");

            sql = "update Billing set wardch ='" + ch + "' where pid =" + pi + "";
            w = s.executeUpdate(sql);
            System.out.println(w);


            System.out.println("Operation Detail updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
