package hospital;

import java.sql.*;

public class Ward {

    String w, r, b, ch, st;

    public void Warddetail(String ww, String rr, String bb, String chh, String ss) {
        if (ww.length() <= 0 && bb.length() <= 0) {
            System.out.println("Invalid details");
        }
        Wardallot wardallot = new Wardallot();
        Patient pat = new Patient();
        w = ww;
        r = rr;
        b = bb;
        ch = chh;
        st = ss;
        wardallot.Wardcharge(pat.pno());
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");

            Statement s = c1.createStatement();
            s.executeUpdate("insert into ward values('" + w + "','" + r + "','" + b + "','" + ch + "','" + st + "')");
            System.out.println("Ward Detail Added successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
