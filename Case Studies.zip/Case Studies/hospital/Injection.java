package hospital;

import java.sql.*;

public class Injection extends Treatments {

    String pn, in, it, dn;
    int pi, iq, di, ic, ti;
    int p1, m1;
    String sql, sql1, sql2, re, tn;
    int w, m;

    public void Injectiondetail(int tii, int pii, String pnn, int dii, String dnn, String inn, int iqq, String itt, int icc) {
        if (pnn.length() <= 0 && inn.length() <= 0) {
            System.out.println("Invalid details");
        }
        pi = pii;
        pn = pnn;
        di = dii;
        in = inn;
        iq = iqq;
        it = itt;
        ic = icc;
        ti = tii;
        dn = dnn;

        Diagnosis dia = new Diagnosis();
        dia.Diagnosisdetail(dii, dnn, dii, pii, inn, pnn, inn, dnn, dnn, itt, dn);
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Injection values(" + ti + "," + pi + ",'" + pn + "'," + di + ",'" + dn + "','" + in + "'," + iq + ",'" + it + "'," + ic + ")");
            System.out.println("Injection Details Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Injectiontotal(int p11) {

        p1 = p11;
        int amt = 0;
        int x = 0;
        System.out.println("welcome");
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            sql2 = "select Inc from Injection where pid=" + p1 + "";
            Statement s = c1.createStatement();
            System.out.println("hai");
            ResultSet rs = s.executeQuery(sql2);
            while (rs.next()) {
                amt += (rs.getInt(1));
            }
            x = amt;
            System.out.println(x);
            sql2 = "update Billing set injeccharge =" + x + " where pid = " + p1 + "";
            w = s.executeUpdate(sql2);
            System.out.println("Injection Bills Added successfully.......");

//            String sql4 = "update patreport set mere='"+mne+"' where pid = "+pi+"";
//            m =s.executeUpdate(sql);


            System.out.println("Injection Details Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Injectionreport(int pii, String tnn) {
        //String a[]=new String[12] ;

        pi = pii;
        tn = tnn;
//String re;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            //          s.executeUpdate("insert into Operation values("+opi+","+ti+","+pi+",'"+opth+"','"+opn+"',"+di+",'"+od+"','"+ot+"','"+opch+"','"+rt+"')");


            //            sql2="select injectname from Injection where pid="+p1+"";
            //            ResultSet rs=s.executeQuery(sql2);
            //            while(rs.next())
            //            {
            //              re=rs.getString(1);
            //            }

            sql2 = "update patreport set inre ='" + tn + "'  where pid = " + pi + "";
            m = s.executeUpdate(sql2);
            System.out.println(m);


            System.out.println("Injectionreport updated successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public int Validate(int pii, int dii, String dnn, String inn) {
        pi = pii;
        di = dii;
        dn = dnn;
        in = inn;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            ResultSet r = s.executeQuery("select pid,did,disn,injectname from Injection where pid=" + pi + " and did=" + di + " and disn='" + dn + "' and injectname='" + in + "'");
            if (r.next()) {
                m = 1;
            } else {
                m = 0;
            }

            System.out.println("Staff details already exist");

            c1.commit();
            c1.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return m;
    }
}
