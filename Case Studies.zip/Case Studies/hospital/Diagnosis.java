package hospital;

import java.sql.*;

public class Diagnosis {

    static int a = 1;
    int dig, did, pid, w, m;
    String dd, tr, dr, ch, sql, sql2, sql3, sql4, tn, sy, dn, wd;

    public void Diagnosisdetail(int digg, String ddd, int didd, int pidd, String tnn, String trr, String syn, String dnn, String drr, String chh, String wdd) {
        if (ddd.length() <= 0 && tnn.length() <= 0) {
            System.out.println("Invalid details");
        }
        DietInfo din = new DietInfo();
        dig = digg;
        did = didd;
        pid = pidd;
        dd = ddd;
        tr = trr;
        dr = drr;
        ch = chh;
        tn = tnn;
        sy = syn;
        dn = dnn;
        wd = wdd;
        dig = din.tno();
        try {
            Labtech lab = new Labtech();
            lab.Labtechdetail(a, dd, dd);
            Medicine med = new Medicine();
            med.Medicinetotal(pid);
            Preport pre = new Preport();
            pre.reno();
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into diagnosis values(" + dig + ",'" + dd + "'," + did + "," + pid + ",'" + tn + "','" + tr + "','" + sy + "','" + dn + "','" + dr + "','" + ch + "','" + wd + "')");
            System.out.println("Diagnosis Detail Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int digno() {

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("Jdbc:Odbc:pat");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select digid from diagnosis");
            while (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }

    public void Doctorcharge(int pidd) {
        pid = pidd;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            sql = "update Billing set docharge ='" + ch + "' where pid = " + pid + "";
            System.out.println(ch);
            w = s.executeUpdate(sql);
            System.out.println("Doctor Charge updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Digreport(int pidd) {
        pid = pidd;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            sql2 = "update patreport set digre ='" + dr + "' where pid = " + pid + "";
            m = s.executeUpdate(sql2);
            System.out.println("Diagnosis report updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public int Validate(String ddd, int didd, int pidd, String tnn) {
        did = didd;
        pid = pidd;
        dd = ddd;
        tn = tnn;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            ResultSet r = s.executeQuery("select dd,docid,pid,testn from diagnosis where dd='" + dd + "' and docid=" + did + " and pid=" + pid + " and testn='" + tn + "'");
            if (r.next()) {
                m = 1;
            } else {
                m = 0;
            }
            System.out.println("Diagnosis is made already for this patient");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return m;
    }
}
