package hospital;

import java.io.*;
import java.sql.*;

public class Outpatient extends Patient {

    String n, a;
    int p,m=0;

    public void Outpatientdetail(int pp, String nn, String aa) {
        if (nn.length() <= 0 && aa.length() <= 0) {
            System.out.println("Invalid details");
        }
        n = nn;
        a = aa;
        p = pp;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Outpatient values(" + p + ",'" + n + "','" + a + "')");
            System.out.println("Outpatient Detail updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public int Validate(int pp, String nn, String aa) {
        n = nn;
        a = aa;
        p = pp;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            ResultSet r = s.executeQuery("select pid,visitdate,diseasetype from Outpatient where pid=" + p + " and visitdate='" + n + "' and diseasetype='" + a + "'");
            if (r.next()) {
                m = 1;
            } else {
                m = 0;
            }
            System.out.println("Patient Operation Appointment is made already");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return m;
    }
}
