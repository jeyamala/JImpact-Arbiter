package hospital;

import java.sql.*;

public class Inpatient extends Patient {

    String ad, dt, w, b, st;
    String sql1, j;
    int i, p;

    public void Inpatientdetail(int pp, String add, String dtt, String ww, String bb, String ss) {
        if (add.length() <= 0 && dtt.length() <= 0) {
            System.out.println("Invalid details");
        }
        Patient pat = new Patient();
        ad = add;
        dt = dtt;
        w = ww;
        b = bb;
        st = ss;
        p = pp;
        p = pat.pno();
        try {
            Operation ope = new Operation();
            ope.operationreport(pp, dtt);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into inpatient values(" + p + ",'" + ad + "','" + dt + "','" + w + "','" + b + "','" + st + "')");
            System.out.println("Inpatient Detail Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
