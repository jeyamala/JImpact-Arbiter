package hospital;

import java.io.*;
import java.sql.*;

public class Staff {

    String n, a, db, gen, de, qu, ex, dj, sa, des, p;
    int i;
    int m;

    public void Staffdetail(int ii, String nn, String aa, String pp, String dbb, String genn, String dee, String quu, String exx, String djj, String saa, String dess) {
        if (dbb.length() >= 20 && dee.length() >= 20) {
            System.out.println("Invalid details");
        }
        i = ii;
        Test test = new Test();
        n = nn;
        a = aa;
        p = pp;
        db = dbb;
        gen = genn;
        de = dee;
        qu = quu;
        ex = exx;
        dj = djj;
        sa = saa;
        des = dess;
        test.Testreport(ii);
        try {
            Nurse nur = new Nurse();
            nur.Nursedetail(ii, db, nn, ii, ii);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Staff1 values(" + i + ",'" + n + "','" + a + "','" + p + "','" + db + "','" + gen + "','" + de + "','" + qu + "','" + ex + "','" + dj + "','" + sa + "','" + des + "')");
            System.out.println("Staff Detail Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public static int eno() {
        int a = 1;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("Jdbc:Odbc:pat");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select empid from Staff1");
            while (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }

    public int Validate(String nn, String aa, String pp, String dbb) {
        n = nn;
        a = aa;
        p = pp;
        db = dbb;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            ResultSet r = s.executeQuery("select name,address,phono,dob from Staff1 where name='" + n + "' and address='" + a + "' and phono='" + p + "' and dob='" + db + "'");
            if (r.next()) {
                m = 1;

            } else {
                m = 0;


            }
            System.out.println("Staff details already exist");

            c1.commit();
            c1.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return m;
    }
}
