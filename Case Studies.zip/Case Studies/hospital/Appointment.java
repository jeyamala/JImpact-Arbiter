package hospital;

import java.sql.*;

public class Appointment {

    int ai, pi, di, api;
    String ad, at;
    int m;
    static int a = 1;
    String pn, opt, ch;

    public void Appdocdetails(int apii, int dii, int pii, String add, String att) {
        if (add.length() >= 20 && att.length() >= 20) {
            System.out.println("Invalid details");
        }
        pi = pii;
        di = dii;
        ad = add;
        at = att;
        api = apii;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into appoint values(" + api + "," + di + "," + pi + ",'" + ad + "','" + at + "')");
            System.out.println("Doctor Appointment is made...");
            if (at.equals("Inpatient")) {
                Inpatient inp = new Inpatient();
                inp.Inpatientdetail(pi, add, att, ad, ad, ad);
            }
            if (at.equals("Outpatient")) {
                Outpatient outp = new Outpatient();
                outp.Outpatientdetail(pi, pn, ad);
            }
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int ano() {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("Jdbc:Odbc:pat");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select apid from appoint");
            while (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }

    public int Validatepatientop(String pnn, int pii, int dii) {
        pn = pnn;
        pi = pii;
        di = dii;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            ResultSet r = s.executeQuery("select opname,pid,did from Opapp where opname='" + pn + "' and pid=" + pi + " and did=" + di + "");
            if (r.next()) {
                m = 1;
            } else {
                m = 0;
            }
            System.out.println("Patient Operation Appointment is made already");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return m;
    }

    public void Appopdetail(int aii, String pnn, int pii, int dii, String add, String att, String optt, String chh) {
        pn = pnn;
        ai = aii;
        pi = pii;
        di = dii;
        ad = add;
        at = att;
        opt = optt;
        ch = chh;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Opapp values(" + ai + ",'" + pn + "'," + pi + "," + di + ",'" + ad + "','" + at + "','" + opt + "','" + ch + "')");
            System.out.println("Operation appoitment is made successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
