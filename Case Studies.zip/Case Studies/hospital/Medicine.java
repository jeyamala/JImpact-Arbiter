package hospital;

import java.sql.*;

public class Medicine extends Treatments {

    int pi, di, mm, ma, mn, mc, tid;
    String pn, mne, mt, men, dn;
    String sql, sql1, sql2, sql3, sql4;
    int w, m;
    int m1, pc;

    public void Medicinedetail(int tidd, int pii, String pnn, int dii, String dnn, String mnee, int mmm, int maa, int mnn, String mtt, int mcc) {
        if (pnn.length() >= 20 && mnee.length() >= 20) {
            System.out.println("Invalid details");
        }
        Treatments tin = new Treatments();
        pi = pii;
        pn = pnn;
        di = dii;
        mne = mnee;
        mm = mmm;
        ma = maa;
        mn = mnn;
        mt = mtt;
        mc = mcc;
        tid = tidd;
        dn = dnn;
        tid = tin.tno();

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Medicine values(" + tid + "," + pi + ",'" + pn + "'," + di + ",'" + dn + "','" + mne + "'," + mm + "," + ma + "," + mn + ",'" + mt + "'," + mc + ")");

            System.out.println("Medicine Details Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Medicinetotal(int pcc) {

        //int m1,int pi;
        //m1=m11;
        pc = pcc;
        int amt = 0;
        int x = 0;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            sql2 = "select mch from Medicine where pid = " + pc + "";
            Statement s = c1.createStatement();
            System.out.println("welcome");
            //s.executeUpdate("insert into Medicine values("+tid+","+pi+",'"+pn+"',"+di+",'"+mne+"',"+mm+","+ma+","+mn+",'"+mt+"','"+mc+"')");
            ResultSet rs = s.executeQuery(sql2);
            while (rs.next()) {
                amt += (rs.getInt(1));
            }

            x = amt;
            System.out.println(x);

            sql3 = "update Billing set medicharge =" + x + " where pid = " + pc + "";
            w = s.executeUpdate(sql3);

//            String sql4 = "update patreport set mere='"+mne+"' where pid = "+pi+"";
//            m =s.executeUpdate(sql);


            System.out.println("Medicine Bill Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Medicinereport(int pii, String menn) {
        //String a[]=new String[12] ;

        pi = pii;
        men = menn;
//String re;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();

            sql2 = "update patreport set mere ='" + men + "'  where pid = " + pi + "";
            m = s.executeUpdate(sql2);
            System.out.println(m);


            System.out.println("Medicinereport updated successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
