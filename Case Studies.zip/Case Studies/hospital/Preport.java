package hospital;

import java.sql.*;

public class Preport {

    String rc, tc, mc, dc, oc, ic, dn, wc;
    int bi, pi;
    String bd, pn, pt, rn, da, dd, re, di;
    String ad, at;

    public void patientdetail(int bii, String bdd, int pii, String pnn, String ptt, String rnn, String daa, String ddd, String dnn, String tcc, String mcc, String dcc, String occ, String icc, String dii, String ree) {
        if (bdd.length() <= 0 && ptt.length() <= 0) {
            System.out.println("Invalid details");
        }
        Register reg = new Register();
        reg.Registercharge(pi);

        bi = bii;
        bd = bdd;
        pi = pii;
        pn = pnn;
        pt = ptt;
        rn = rnn;
        da = daa;
        dd = ddd;
        tc = tcc;
        dn = dnn;
        mc = mcc;
        dc = dcc;
        oc = occ;
        ic = icc;
        di = dii;
        re = ree;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Patientreport values(" + bi + ",'" + bd + "'," + pi + ",'" + pn + "','" + pt + "','" + rn + "','" + da + "','" + dd + "','" + dn + "','" + tc + "','" + mc + "','" + dc + "','" + oc + "','" + ic + "','" + di + "','" + re + "')");
            System.out.println("Patient report updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public final int reno() {
        int a = 1;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("Jdbc:Odbc:pat");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select repno from Patientreport");
            while (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
