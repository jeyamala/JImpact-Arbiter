/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

/**
 *
 * @author HP2
 */
import java.io.*;
import java.sql.*;

public class Operation extends Treatments {

    String opn, od, ot, opch, opth, rt, re;
    int pi, ti, m;
    String sql, sql1;
    int w;

    public void Operationdetail(int opii, int tii, int pii, String opthh, String opnn, int dii, String odd, String ott, String opchh, String rtt) {
        if (opthh.length() <= 0 && opnn.length() <= 0) {
            System.out.println("Invalid details");
        }
        Treatments pin = new Treatments();
        Operation ss = new Operation();
        Doctor d = new Doctor();
        pi = pii;
        opth = opthh;
        opn = opnn;
        od = odd;
        ot = ott;
        opch = opchh;
        rt = rtt;
        ti = tii;
        ti = pin.tno();
        int opi = ss.tno();
        int di = d.docno();
        opi = opii;
        di = dii;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Operation values(" + opi + "," + ti + "," + pi + ",'" + opth + "','" + opn + "'," + di + ",'" + od + "','" + ot + "','" + opch + "','" + rt + "')");

//            sql = "update Billing set opcharge ='"+opch+"' where pid ="+pi+"";
//             w =s.executeUpdate(sql);
//             System.out.println(w);


            System.out.println("Operation Detail updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Operationtotal(int pii) {
        if (pii == 0) {
            pii = pii + 1;
        }
        // pi=pii; opn=opnn; opth=opthh;odt=odtt;opch=opchh;
        //pi=pii;opth=opthh; opn=opnn; od=odd; ot=ott; opch=opchh; rt=rtt;
        pi = pii;

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            //          s.executeUpdate("insert into Operation values("+opi+","+ti+","+pi+",'"+opth+"','"+opn+"',"+di+",'"+od+"','"+ot+"','"+opch+"','"+rt+"')");

            sql = "update Billing set opcharge ='" + opch + "' where pid =" + pi + "";
            w = s.executeUpdate(sql);
            System.out.println(w);


            System.out.println("Operation Detail updated successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void operationreport(int pii, String rtt) {
        if (rtt.length() >= 20) {
            System.out.println("Invalid details");
        }
        //String a[]=new String[12] ;

        pi = pii;
        rt = rtt;
//String re;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            sql = "update patreport set opre ='" + rt + "'  where pid = " + pi + "";
            m = s.executeUpdate(sql);
            System.out.println(m);


            System.out.println("Medicinereport updated successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
