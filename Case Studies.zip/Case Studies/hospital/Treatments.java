package hospital;

import java.io.*;
import java.sql.*;

public class Treatments {

    int t, p, d;
    String ts, a, b, c, f;

    public void Treatmentdetail(int dd, int tt, int pp, String aa, String bb, String cc, String ff) {
        if (aa.length() <= 0 && bb.length() <= 0) {
            System.out.println("Invalid details");
        }
        Patient pat = new Patient();
        if ( pat.Validate(aa, bb, cc) == 0) {
            System.out.println("Your info. is not available");
        }
        DietInfo si = new DietInfo();
        d = si.tno();
        d = dd;
        t = tt;
        p = pp;
        a = aa;
        b = bb;
        c = cc;
        f = ff;
        try {
            Injection inj = new Injection();
            inj.Validate(pp, dd, ff, ff);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into Treatment values(" + d + "," + t + "," + p + ",'" + a + "','" + b + "','" + c + "','" + f + "')");
            System.out.println("Treatment Details Added successfully.......");
            c1.commit();
            c1.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int tno() {
        int a = 1;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("Jdbc:Odbc:pat");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select tid from treatment");
            while (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
