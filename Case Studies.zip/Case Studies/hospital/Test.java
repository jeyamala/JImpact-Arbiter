/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.io.*;
import java.sql.*;

public class Test {

    String ti, tn, ld, lt, tr, td, ch, sql, sql2;
    int pi, w, m;

    public void Testdetail(String tii, String tnn, String ldd, int pii, String ltt, String trr, String tdd, String chh) {
        if (tnn.length() <= 0 && tii.length() <= 0) {
            System.out.println("Invalid details");
        }
        Patient pat = new Patient();
        ti = tii;
        tn = tnn;
        ld = ldd;
        pi = pii;
        lt = ltt;
        tr = trr;
        td = tdd;
        ch = chh;
        pi = pat.pno();
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into test values('" + ti + "','" + tn + "','" + ld + "'," + pi + ",'" + lt + "','" + tr + "','" + td + "','" + ch + "')");




            System.out.println("Test Detail Added successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Testcharge(int pii) {
        if (pii == 0) {
            pii = pii + 1;
        }

        pi = pii;

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            //          s.executeUpdate("insert into Operation values("+opi+","+ti+","+pi+",'"+opth+"','"+opn+"',"+di+",'"+od+"','"+ot+"','"+opch+"','"+rt+"')");

            sql = "update Billing set testcharge ='" + ch + "' where pid = " + pi + "";
            w = s.executeUpdate(sql);
            System.out.println(w);


            System.out.println("Testcharge updated successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Testreport(int pii) {

        pi = pii;

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            //          s.executeUpdate("insert into Operation values("+opi+","+ti+","+pi+",'"+opth+"','"+opn+"',"+di+",'"+od+"','"+ot+"','"+opch+"','"+rt+"')");

            sql2 = "update patreport set tere ='" + tr + "' where pid = " + pi + "";
            m = s.executeUpdate(sql2);
            System.out.println(m);


            System.out.println("Testreport updated successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
