package hospital;

import java.io.*;
import java.sql.*;

public class Patient {

    String n, a, b, h, d, cu, da, pt, g, gu, c, db;
    int p, m;
    static int aa;

    public void Patientdetail(int pi, String na, String ad, String co, String bg, String hi, String db, String cur, String daa, String pty, String gen, String guu) {
        if (co.length() <= 0 && bg.length() <= 0) {
            System.out.println("Invalid details");
        }
        Appointment app = new Appointment();
        n = na;
        a = ad;
        c = co;
        b = bg;
        h = hi;
        d = db;
        cu = cur;
        da = daa;
        pt = pty;
        g = gen;
        p = pi;
        gu = guu;
        int det = app.Validatepatientop(gen, pi, pi);
        try {
            Bills bil = new Bills();
            bil.Billdetail(pi, db, pi, gen, pty, gen, daa, daa, det, det, m, det, det, det, det, gen, det);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into PAT values(" + p + ",'" + n + "','" + a + "','" + c + "','" + b + "','" + h + "','" + d + "','" + cu + "','" + da + "','" + pt + "','" + g + "','" + gu + "')");
            System.out.println("Patient Detail updated successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static int pno() {

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("Jdbc:Odbc:pat");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select patientno from pat");
            while (rs.next()) {
                aa = rs.getInt(1);
            }
            aa = aa + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return aa;

    }

    public int Validate(String na, String co, String dbb) {
        n = na;
        c = co;
        db = dbb;

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:Pat", "", "");
            Statement s = c1.createStatement();
            ResultSet r = s.executeQuery("select name,contact,dob from PAT where name='" + n + "' and contact='" + c + "' and dob='" + db + "'");

            if (r.next()) {
                m = 1;
            } else {
                m = 0;
            }

            System.out.println("Patient Exist");

            c1.commit();
            c1.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return m;
    }
}
