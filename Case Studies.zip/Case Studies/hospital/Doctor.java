package hospital;

import java.sql.*;

public class Doctor extends Staff {

    int e, d;
    String sp, sh, st, sql, fr, am, to, pm;
	String n;
    static int a = 1;

    public void Doctordetail(int ee, int dd, String nn, String spp) {
        if (nn.length() <= 0 && spp.length() <= 0) {
            System.out.println("Invalid details");
        }
        Appointment app = new Appointment();
        app.Appdocdetails(ee, dd, ee, spp, nn);
        e = ee;
        n = nn;
        sp = spp;
        d = dd;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();
            s.executeUpdate("insert into doc1 values(" + e + "," + d + ",'" + n + "','" + sp + "')");
            System.out.println("Doctor Detail Added successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Doctorshedule(int dd, String shh, String frr, String amm, String too, String pmm) {
        if (shh.length() <= 0 && amm.length() <= 0) {
            System.out.println("Invalid details");
        }
        sh = shh;
        d = dd;
        fr = frr;
        am = amm;
        to = too;
        pm = pmm;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection c1 = DriverManager.getConnection("jdbc:odbc:pat", "", "");
            Statement s = c1.createStatement();

            s.executeUpdate("insert into docsh values(" + d + ",'" + sh + "','" + fr + "','" + am + "','" + to + "','" + pm + "')");
            System.out.println("Doctor Shedule updated successfully.......");
            c1.commit();
            c1.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.out.println(e);
        }
    }

    public static int docno() {

        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn = DriverManager.getConnection("Jdbc:Odbc:pat");
            Statement s = conn.createStatement();
            ResultSet rs = s.executeQuery("Select docid from doc1");
            while (rs.next()) {
                a = rs.getInt(1);
            }
            a = a + 1;
        } catch (Exception e) {
            System.out.println(e);
        }
        return a;
    }
}
