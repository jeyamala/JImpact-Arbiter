/*     */ package info.gridworld.world;
/*     */ 
/*     */ import info.gridworld.grid.BoundedGrid;
/*     */ import info.gridworld.grid.Grid;
/*     */ import info.gridworld.grid.Location;
/*     */ import info.gridworld.gui.WorldFrame;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import javax.swing.JFrame;
/*     */ 
/*     */ public class World<T>
/*     */ {
/*     */   private Grid<T> gr;
/*     */   private Set<String> occupantClassNames;
/*     */   private Set<String> gridClassNames;
/*     */   private String message;
/*     */   private JFrame frame;
/*  45 */   private static Random generator = new Random();
/*     */   private static final int DEFAULT_ROWS = 10;
/*     */   private static final int DEFAULT_COLS = 10;
/*     */ 
/*     */   public World()
/*     */   {
/*  52 */     this(new BoundedGrid(10, 10));
/*  53 */     this.message = null;
/*     */   }
/*     */ 
/*     */   public World(Grid<T> g)
/*     */   {
/*  58 */     this.gr = g;
/*  59 */     this.gridClassNames = new TreeSet();
/*  60 */     this.occupantClassNames = new TreeSet();
/*  61 */     addGridClass("info.gridworld.grid.BoundedGrid");
/*  62 */     addGridClass("info.gridworld.grid.UnboundedGrid");
/*     */   }
/*     */ 
/*     */   public void show()
/*     */   {
/*  70 */     if (this.frame == null)
/*     */     {
/*  72 */       this.frame = new WorldFrame(this);
/*  73 */       this.frame.setVisible(true);
/*     */     }
/*     */     else {
/*  76 */       this.frame.repaint();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Grid<T> getGrid()
/*     */   {
/*  85 */     return this.gr;
/*     */   }
/*     */ 
/*     */   public void setGrid(Grid<T> newGrid)
/*     */   {
/*  94 */     this.gr = newGrid;
/*  95 */     repaint();
/*     */   }
/*     */ 
/*     */   public void setMessage(String newMessage)
/*     */   {
/* 104 */     this.message = newMessage;
/* 105 */     repaint();
/*     */   }
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 114 */     return this.message;
/*     */   }
/*     */ 
/*     */   public void step()
/*     */   {
/* 123 */     repaint();
/*     */   }
/*     */ 
/*     */   public boolean locationClicked(Location loc)
/*     */   {
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean keyPressed(String description, Location loc)
/*     */   {
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */   public Location getRandomEmptyLocation()
/*     */   {
/* 160 */     Grid gr = getGrid();
/* 161 */     int rows = gr.getNumRows();
/* 162 */     int cols = gr.getNumCols();
/*     */ 
/* 164 */     if ((rows > 0) && (cols > 0))
/*     */     {
/* 167 */       ArrayList emptyLocs = new ArrayList();
/* 168 */       for (int i = 0; i < rows; i++)
/* 169 */         for (int j = 0; j < cols; j++)
/*     */         {
/* 171 */           Location loc = new Location(i, j);
/* 172 */           if ((gr.isValid(loc)) && (gr.get(loc) == null))
/* 173 */             emptyLocs.add(loc);
/*     */         }
/* 175 */       if (emptyLocs.size() == 0)
/* 176 */         return null;
/* 177 */       int r = generator.nextInt(emptyLocs.size());
/* 178 */       return (Location)emptyLocs.get(r);
/*     */     }
/*     */     while (true)
/*     */     {
/*     */       int r;
/* 187 */       if (rows < 0)
/* 188 */         r = (int)(10.0D * generator.nextGaussian());
/*     */       else
/* 190 */         r = generator.nextInt(rows);
/*     */       int c;
/* 192 */       if (cols < 0)
/* 193 */         c = (int)(10.0D * generator.nextGaussian());
/*     */       else
/* 195 */         c = generator.nextInt(cols);
/* 196 */       Location loc = new Location(r, c);
/* 197 */       if ((gr.isValid(loc)) && (gr.get(loc) == null))
/* 198 */         return loc;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add(Location loc, T occupant)
/*     */   {
/* 210 */     getGrid().put(loc, occupant);
/* 211 */     repaint();
/*     */   }
/*     */ 
/*     */   public T remove(Location loc)
/*     */   {
/* 221 */     Object r = getGrid().remove(loc);
/* 222 */     repaint();
/* 223 */     return (T) r;
/*     */   }
/*     */ 
/*     */   public void addGridClass(String className)
/*     */   {
/* 232 */     this.gridClassNames.add(className);
/*     */   }
/*     */ 
/*     */   public void addOccupantClass(String className)
/*     */   {
/* 241 */     this.occupantClassNames.add(className);
/*     */   }
/*     */ 
/*     */   public Set<String> getGridClasses()
/*     */   {
/* 251 */     return this.gridClassNames;
/*     */   }
/*     */ 
/*     */   public Set<String> getOccupantClasses()
/*     */   {
/* 261 */     return this.occupantClassNames;
/*     */   }
/*     */ 
/*     */   private void repaint()
/*     */   {
/* 266 */     if (this.frame != null)
/* 267 */       this.frame.repaint();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 275 */     String s = "";
/* 276 */     Grid gr = getGrid();
/*     */ 
/* 278 */     int rmin = 0;
/* 279 */     int rmax = gr.getNumRows() - 1;
/* 280 */     int cmin = 0;
/* 281 */     int cmax = gr.getNumCols() - 1;
/* 282 */     if ((rmax < 0) || (cmax < 0))
/*     */     {
/*       for (Location loc : gr.getOccupiedLocations())
{
int r = loc.getRow();
int c = loc.getCol();
if (r < rmin)
rmin = r;
if (r > rmax)
rmax = r;
if (c < cmin)
cmin = c;
if (c > cmax) {
cmax = c;
}
}*/
          }
/* 299 */     for (int i = rmin; i <= rmax; i++)
/*     */     {
/* 301 */       for (int j = cmin; j < cmax; j++)
/*     */       {
/* 303 */         Object obj = gr.get(new Location(i, j));
/* 304 */         if (obj == null)
/* 305 */           s = s + " ";
/*     */         else
/* 307 */           s = s + obj.toString().substring(0, 1);
/*     */       }
/* 309 */       s = s + "\n";
/*     */     }
/* 311 */     return s;
/*     */   }
/*     */ }

/* Location:           C:\Users\hp1\Downloads\GridWorldCode\GridWorldCode\gridworld.jar
 * Qualified Name:     info.gridworld.world.World
 * JD-Core Version:    0.6.2
 */