/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */

package it.haefelinger.flaka;

import it.haefelinger.flaka.util.Static;

import java.util.ArrayList;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.RuntimeConfigurable;
import org.apache.tools.ant.taskdefs.MacroInstance;
import org.apache.tools.ant.taskdefs.PreSetDef;

/**
 * A task allowing the dynamic execution of a macro or task.
 * 
 * 
 * @author merzedes
 * @since 1.0
 */

public class RunMacro extends Task {
  public String name = "";
  public boolean fail = false;
  public List args = null; /* list of arguments */

  /**
   * The name of the macro to execute.
   * 
   * @param s
   */
  public void setName(String s) {
    this.name = Static.trim2(s, this.name);
  }

  /**
   * Fail if macro does not exist.
   * 
   * @param b
   */
  public void setFail(boolean b) {
    this.fail = b;
  }

  public boolean getFail() {
    return this.fail;
  }

  /** nested element <code>param</code> */
  public Param createParam() {
    return createArg();
  }

  /** nested element <code>attribute</code> */
  public Param createAttribute() {
    return createArg();
  }

  /** nested element <code>arg</code> */
  public Param createArg() {
    Param P;
    P = new Param();
    addarg(P);
    return P;
  }

  public List getargs() {
    if (this.args == null)
      this.args = new ArrayList();
    return this.args;
  }

  public void addarg(Object obj) {
    getargs().add(obj);
  }

  public class Param {
    public String k;
    public String v;

    public Param() {
      this.k = null;
      this.v = null;
    }

    public void setName(String k) {
      this.k = Static.trim2(k, this.k);
    }

    public void setValue(String v) {
      this.v = Static.trim2(v, this.v);
    }
  }

  public void onerror(String s) {
    if (this.fail)
      throwbx(s);
    else
      verbose("warning: " + s);
  }

  public void runmacro(String m, Object[] args) {
    Param P;
    Object obj;

    obj = Static.makecomp(getProject(), m);
    if (obj == null) {
      onerror("`" + m + "' neither marco nor task.");
      return;
    }

    /*
     * Check whether it's a presetdef. If so then Project.createTask() fails
     * with ClassCastException (1.6.5). In such a way we need to create the
     * object like shown below ..
     */
    if (obj instanceof PreSetDef.PreSetDefinition) {
      PreSetDef.PreSetDefinition psd;
      psd = (PreSetDef.PreSetDefinition) obj;
      obj = psd.createObject(getProject());
    } else {
      /* try to create task */
      obj = getProject().createTask(m);
      if (obj == null) {
        /* this should not happen - anyhow, we check again */
        onerror("`" + m + "' neither marco nor task.");
        return;
      }
    }

    if (obj instanceof MacroInstance) {
      MacroInstance M;
      M = (MacroInstance) obj;
      for (int i = 0; i < args.length; ++i) {
        if (args[i] instanceof Param) {
          P = (Param) args[i];
          M.setDynamicAttribute(P.k, P.v);
        }
      }
      M.execute();
      return;
    }

    if (obj instanceof org.apache.tools.ant.Task) {
      RuntimeConfigurable rtc;
      org.apache.tools.ant.Task T;

      T = (org.apache.tools.ant.Task) obj;
      rtc = T.getRuntimeConfigurableWrapper();
      for (int i = 0; i < args.length; ++i) {
        if (args[i] instanceof Param) {
          P = (Param) args[i];
          rtc.setAttribute(P.k, P.v);
        }
      }
      T.execute();
      return;
    }

    onerror("`" + m + "' neither marco nor task.");
    return;
  }

  public void execute() throws BuildException {
    Object[] args = getargs().toArray();
    String[] name = this.name.split("\\s+");

    for (int i = 0; i < name.length; ++i)
      runmacro(name[i], args);
  }
}
