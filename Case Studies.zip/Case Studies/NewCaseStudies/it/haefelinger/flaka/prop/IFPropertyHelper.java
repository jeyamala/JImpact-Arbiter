package it.haefelinger.flaka.prop;

public interface IFPropertyHelper {
  public boolean enable(boolean b);
}
