
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.TaskContainer;


/**
 * A task to rescue variables.
 * 
 * @author merzedes
 * @since 1.0
 */
public class Rescue extends it.haefelinger.flaka.Task implements TaskContainer {
  /* items to protect */
  public it.haefelinger.flaka.List vars;
  public it.haefelinger.flaka.List properties;
  public Map varhtab;
  public Map ptyhtab;
  /** Optional Vector holding the nested tasks */
  public Vector tasks = new Vector();

  public void addVars(it.haefelinger.flaka.List list)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Rescue.addVars.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.vars = list;
    this.vars.setEl(false);
fos.close();

  }

  public void addProperties(it.haefelinger.flaka.List list)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Rescue.addProperties.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.properties = list;
    this.properties.setEl(false);
fos.close();

  }

  public void addTask(Task nestedTask)  {
    this.tasks.add(nestedTask);

  }

  public void rescue()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Rescue.rescue.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Project project;
    Iterator iter;
    String key;
    Object val;

    if (this.vars != null) {

fos.write("2\nB1\n".getBytes());

      project = getProject();
      this.varhtab = new HashMap();
      iter = this.vars.eval().iterator();
      while (iter.hasNext()) {

fos.write("3\nB2\n".getBytes());

        key = (String) iter.next();
        // TODO: references != vars
        val = project.getReference(key);
        this.varhtab.put(key, val);
      }
    }
    if (this.properties != null) {

fos.write("4\nB3\n".getBytes());

      project = getProject();
      this.ptyhtab = new HashMap();
      iter = this.properties.eval().iterator();
      while (iter.hasNext()) {

fos.write("5\nB4\n".getBytes());

        key = (String) iter.next();
        val = project.getProperty(key);
        this.ptyhtab.put(key, val);
      }
    }
fos.close();

  }

  public void restore()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Rescue.restore.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Project project;
    Iterator iter;
    String key;
    Object val;

    if (this.varhtab != null) {

fos.write("2\nB1\n".getBytes());

      project = getProject();
      iter = this.varhtab.keySet().iterator();
      while (iter.hasNext()) {

fos.write("3\nB2\n".getBytes());

        key = (String) iter.next();
        val = this.varhtab.get(key);
        Static.assign(project, key, val, Static.VARREF);
      }
    }
    if (this.ptyhtab != null) {

fos.write("4\nB3\n".getBytes());

      project = getProject();
      iter = this.ptyhtab.keySet().iterator();
      while (iter.hasNext()) {

fos.write("5\nB4\n".getBytes());

        key = (String) iter.next();
        val = this.ptyhtab.get(key);
        Static.assign(project, key, val, Static.WRITEPROPTY);
      }
    }
fos.close();

  }

  public void execute() throws BuildException  {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.Rescue.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            rescue();
            try {
                org.apache.tools.ant.Task task;
                Iterator iter;
                iter = this.tasks.iterator();
                while (iter.hasNext()) {
                    fos.write("2\nB1\n".getBytes());
                    task = (org.apache.tools.ant.Task) iter.next();
                    task.perform();
                }
            } finally {
                restore();
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(Rescue.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(Rescue.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }
}