
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it.haefelinger.flaka.util.Static;

import java.io.File;

import org.apache.tools.ant.BuildException;


/**
 * 
 * @author merzedes
 * @since 1.0
 */
public class CvsStat extends Task {
  public String stem = "cvsstat.";
  public File path = null;
  public boolean fail = false;
  public boolean preserve = false;

  public void setArg(File x)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.setArg.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.path = x;
fos.close();

  }

  public void setPath(File x)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.setPath.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.path = x;
fos.close();

  }

  public void setFile(File x)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.setFile.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.path = x;
fos.close();

  }

  public void setFail(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.setFail.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.fail = b;
fos.close();

  }

  public void setPreserve(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.setPreserve.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.preserve = b;
fos.close();

  }

  /* The stem to be used for properties */
  public void setStem(String x)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.setStem.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.stem = Static.trim2(x, this.stem);
    /* make sure that new stem ends with "." */
    if (!this.stem.endsWith("."))

fos.write("2\nB1\n".getBytes());

      this.stem += ".";
fos.close();

  }

  public void execute() throws BuildException{
      try{
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.execute.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    // Let's first unset all variables we are going to
    // assign later.
    htabrm("error");
    if (this.preserve == false) {

fos.write("2\nB1\n".getBytes());

      htabrm("cvsfile");
      htabrm("cvsrev");
      htabrm("cvsdate");
      htabrm("cvsstag");
      htabrm("cvstag");
      htabrm("cvsdir");
      htabrm("cvsroot");
    }

    if (this.path == null) {

fos.write("3\nB2\n".getBytes());

      String s = this.getProperty("ant.file");
      if (Static.isEmpty(s)) {

fos.write("4\nB3\n".getBytes());

        handleError("use 'path' to specify loc argument.");
        return;
      }
      this.path = new File(s);
    }
    statCvsProperties();
fos.close();
      }catch(Exception e) { }
  }

  public void htabput(String K, String v)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.htabput.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String k = this.stem + K;
    if (this.debug)

fos.write("2\nB1\n".getBytes());

      System.err.println("set property: `" + k + "'='" + v + "'");
    // do not set propery if already set
    getProject().setNewProperty(k, v);
fos.close();

  }

  public void htabrm(String K)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.htabrm.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String k = this.stem + K;
    if (this.debug)

fos.write("2\nB1\n".getBytes());

      System.err.println("removing property: `" + k + "'");
    Static.unset(getProject(), k);
fos.close();

  }

  public void handleError(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.handleError.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    /* If an error occurs, property stem.error is set */
    htabput("error", s);
    if (this.fail)
    {
fos.write("2\nB1\n".getBytes());

      throw new BuildException(s);
      }
    if (this.debug) {

fos.write("3\nB2\n".getBytes());

      System.err.println("**error: " + s);
    } else {

fos.write("4\nB3\n".getBytes());

      debug(s);
      }
fos.close();

  }

  public void statCvsProperties() throws BuildException  {
      try{
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CvsStat.statCvsProperties.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    /* set and override properties */
    int i, j;
    String s;
    File file = this.path;
    File dir, cvs, cvsfile;
    String[] buf;

    // check whether loc exists ..
    if (!file.exists()) {

fos.write("2\nB1\n".getBytes());

      handleError("this loc does not exists: " + file.getPath());
      return;
    }
    dir = file.getParentFile();
    if (dir == null) {

fos.write("3\nB2\n".getBytes());

      handleError("parent dir does not exists: " + file.getPath());
      return;
    }
    cvs = new File(dir, "CVS");
    if (!cvs.exists()) {

fos.write("4\nB3\n".getBytes());

      handleError("CVS directory not available: " + cvs.getPath());
      return;
    }
    if (!cvs.isDirectory()) {

fos.write("5\nB4\n".getBytes());

      handleError("CVS exists but not a directory: " + cvs.getPath());
      return;
    }
    cvsfile = new File(cvs, "Entries");
    if (!cvsfile.canRead()) {

fos.write("6\nB5\n".getBytes());

      handleError("unable to read : " + cvsfile.getPath());
      return;
    }

    /* Read content of CVS/Entries */
    String entries = Static.readlines(cvsfile);
    if (entries == null) {

fos.write("7\nB6\n".getBytes());

      handleError("unknown error while reading: " + cvsfile.getPath());
      return;
    }
    /* control output */
    debug(entries);

    /* get loc's basename */
    String name = file.getName();

    /* find in entries the line that starts with "/<loc>/" */
    String[] line = Static.bufread(entries);

    for (i = 0; i < line.length; ++i) {

fos.write("8\nB7\n".getBytes());

      String[] col = Static.split(line[i], "/");

      if (col == null)
      {
fos.write("9\nB8\n".getBytes());

        continue;
        }
      if (col.length < 2) {

fos.write("10\nB9\n".getBytes());

        continue;
      }
      if (col[1] == null)
      {
fos.write("11\nB10\n".getBytes());

        continue;
        }
      if (col[1].equals(name)) {

fos.write("12\nB11\n".getBytes());

        htabput("cvsfile", name);
        if (col.length > 2 && !Static.isEmpty(col[2]))

fos.write("13\nB12\n".getBytes());

          htabput("cvsrev", col[2]);
        if (col.length > 3 && !Static.isEmpty(col[3]))

fos.write("14\nB13\n".getBytes());

          htabput("cvsdate", col[3]);
        if (col.length > 5 && !Static.isEmpty(col[5])) {

fos.write("15\nB14\n".getBytes());

          String tag = col[5].substring(1);
          htabput("cvstag", tag);
          htabput("cvsstag", tag);
        }
        break;
      }
    }

    if (i >= line.length) {

fos.write("16\nB15\n".getBytes());

      handleError("unable to find `" + name + "' in `" + cvsfile.getPath()
          + "'");
      return;
    }

    /* figure name of the module */
    cvsfile = new File(cvs, "Repository");
    if (!cvsfile.canRead()) {

fos.write("17\nB16\n".getBytes());

      handleError("unable to read : " + cvsfile.getPath());
    } else {

fos.write("18\nB17\n".getBytes());

      buf = Static.bufread(cvsfile);
      for (j = 0; j < buf.length; ++j) {

fos.write("19\nB18\n".getBytes());

        if (!buf[j].equals("")) {

fos.write("20\nB19\n".getBytes());

          htabput("cvsdir", buf[j]);
          break;
        }
      }
    }
    /* figure the name of the CVS repository */
    cvsfile = new File(cvs, "Root");
    if (!cvsfile.canRead()) {

fos.write("21\nB20\n".getBytes());

      handleError("unable to read : " + cvsfile.getPath());
    } else {

fos.write("22\nB21\n".getBytes());

      buf = Static.bufread(cvsfile);
      for (j = 0; j < buf.length; ++j) {

fos.write("23\nB22\n".getBytes());

        if (!buf[j].equals("")) {

fos.write("24\nB23\n".getBytes());

          htabput("cvsroot", buf[j]);
          break;
        }
      }
    }
    /*
     * This loc seems to be only present if a folder is checked out with a tag.
     * If given, we set 'cvstag' - but not cvsstag.
     */
    cvsfile = new File(cvs, "Tag");
    if (!cvsfile.canRead()) {

fos.write("25\nB24\n".getBytes());

      debug("(ignore) unable to read " + cvsfile.getPath());
    } else {

fos.write("26\nB25\n".getBytes());

      buf = Static.bufread(cvsfile);
      if (buf.length <= 0) {

fos.write("27\nB26\n".getBytes());

        debug("CVS/Tag appears to be empty: " + cvsfile.getPath());
      } else {

fos.write("28\nB27\n".getBytes());

        for (j = 0; j < buf.length; ++j) {

fos.write("29\nB28\n".getBytes());

          s = buf[j].trim();
          if (!s.equals("")) {

fos.write("30\nB29\n".getBytes());

            char c = s.charAt(0);
            if (c == 'T') {

fos.write("31\nB30\n".getBytes());

              /* branch tag */
              /* we do not treat a branch tag as regular tag */
              // htabput(P,H,stem + "cvstag",s.substring(1));
              break;
            }
            if (c == 'D') {

fos.write("32\nB31\n".getBytes());

              /* date tag */
              // htabput(P,H,stem + "cvstag",s.substring(1));
              break;
            }
            if (c == 'N') {

fos.write("33\nB32\n".getBytes());

              /* non branch tag */
              htabput("cvstag", s.substring(1));
              break;
            }
            /* should not happen according to CVS manual */
            debug("malformed entry found in: `" + cvsfile.getPath() + "'");
            htabput("cvstag", s.substring(1));
            break;
          }
        }
      }
    }
fos.close();

  }catch(Exception e){}
    }
  }
