
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.dep.Dependency;

import java.io.File;
import java.io.FileInputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * @author merzedes
 * @since 1.0
 */
public class ResolveDeps extends Task {
  public String var = "project.dependencies";
  public File baseline;

  public void setBaseline(File f)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.ResolveDeps.setBaseline.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.baseline = f;
fos.close();

  }

  public void execute()  {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.ResolveDeps.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            if (this.baseline == null) {
                fos.write("2\nB1\n".getBytes());
                /* compile default baseline */
                File d = toFile(this.getProperty("baseline.dir"));
                String b = this.getProperty("baseline");
                this.baseline = new File(d, b + ".txt");
            }
            if (this.baseline != null) {
                fos.write("3\nB2\n".getBytes());
                if (this.baseline.isFile() == false) {
                    fos.write("4\nB3\n".getBytes());
                    warn("Baseline " + this.baseline.getAbsolutePath() + " not a file or not existing.");
                    warn("Giving up.");
                    return;
                }
            }
            Properties Baseline = null;
            FileInputStream fin;
            try {
                fin = new FileInputStream(this.baseline);
                Baseline = new Properties();
                Baseline.load(fin);
                /* evaluate all properties */
                // Eval.eval(Baseline,this.getProject());
            } catch (Exception ex) {
                String s;
                s = this.baseline.getPath();
                throwbx("error while loading Baseline `" + s + "', got `" + ex + "'");
            }
            Collection C = null;
            try {
                C = (Collection) this.getref(this.var);
                if (C == null || C.isEmpty()) {
                    fos.write("5\nB4\n".getBytes());
                    debug("empty collection: " + this.var);
                    return;
                }
            } catch (Exception e) {
                debug("not a collection: " + this.var);
                return;
            }
            Iterator i = C.iterator();
            while (i.hasNext()) {
                fos.write("6\nB5\n".getBytes());
                Dependency d = null;
                try {
                    d = (Dependency) i.next();
                } catch (Exception e) {
                    continue;
                }
                if (d == null) {
                    fos.write("7\nB6\n".getBytes());
                continue;
                }
                String s;
                s = d.getAlias();
                if (s != null) {
                    fos.write("8\nB7\n".getBytes());
                    debug("resolving alias `" + s + "' ..");
                    d.resolve(Baseline);
                }
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(ResolveDeps.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(ResolveDeps.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }
}