
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.TaskContainer;


/**
 * 
 * @author merzedes
 * @since 1.0
 */
public class For extends it.haefelinger.flaka.Task implements TaskContainer {
  public String expr;
  public String var;
  /** Optional Vector holding the nested tasks */
  public Vector tasks = new Vector();
  public Object saved = null;

  public For() {
    super();
  }

  /**
   * The argument list to be iterated over.
   */
  public void setIn(String expr)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.For.setIn.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.expr = Static.trim3(getProject(), expr, this.expr);
fos.close();

  }

  /**
   * Set the var attribute. This is the name of the macrodef attribute that gets
   * set for each iterator of the sequential element.
   */
  public void setVar(String var)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.For.setVar.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.var = Static.trim3(getProject(), var, this.var);
fos.close();

  }

  public void addTask(Task nestedTask)   {
    this.tasks.add(nestedTask);


  }

  public void rescue()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.For.rescue.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    /* save variable (if existing) */
    // TODO: variables are not references
    this.saved = getProject().getReference(this.var);
fos.close();

  }

  public void restore()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.For.restore.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Static.assign(getProject(), this.var, this.saved, Static.VARREF);
fos.close();

  }

  public void exectasks(Object val) throws BuildException   {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.For.exectasks.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            Iterator iter;
            Task task;
            Static.assign(getProject(), this.var, val, Static.VARREF);
            iter = this.tasks.iterator();
            while (iter.hasNext()) {
                fos.write("2\nB1\n".getBytes());
                task = (Task) iter.next();
                task.perform();
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(For.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(For.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }

  public Iterator iterator() {
    Iterator iter = null;
    Project project;
    Object obj;

    project = getProject();
    obj = Static.el2obj(project, this.expr);

    if (obj == null)
      return null;

    if (obj instanceof Iterable) {
      iter = ((Iterable) obj).iterator();
      return iter;
    }
    // If we are a map, then we iterate over the keys.
    if (obj instanceof Map) {
      Set keys = ((Map) obj).keySet();
      // Do not use `keys.iterator()` here otherwise we end up in
      // an concurrent modification exception.
      iter = Arrays.asList(keys.toArray()).iterator();
      return iter;
    }
    // Otherwise, we create an array and iterate over
    // it's one and only argument.
    iter = Arrays.asList(obj).iterator();
    return iter;
  }

  public void execute() throws BuildException   {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.For.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            Iterator iter;
            if (this.expr == null || this.var == null) {
                fos.write("2\nB1\n".getBytes());
                // TODO: debug message
                return;
            }
            try {
                /* rescue variable `var` */
                rescue();
                /* iterate over each list item */
                iter = iterator();
                while (iter != null && iter.hasNext()) {
                    fos.write("3\nB2\n".getBytes());
                    try {
                        /* exec all tasks using on current list item */
                        exectasks(iter.next());
                    } catch (BuildException bx) {
                        String s;
                        s = bx.getMessage();
                        /* we are looking for a special designed message */
                        if (s == null) {
                            fos.write("4\nB3\n".getBytes());

                        throw bx;
                        }
                        /* handle special break statement */
                        if (s.endsWith(Break.TOKEN)) {
                            fos.write("5\nB4\n".getBytes());
                                                break;
                        }
                        /* handle continue statement */
                        if (s.endsWith(Continue.TOKEN)) {
                            fos.write("6\nB5\n".getBytes());

                        continue;
                        }
                        /* regular exception */
                        throw bx;
                    }
                }
            } finally {
                /* restore variable */
                restore();
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(For.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(For.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }
}