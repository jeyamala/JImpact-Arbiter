
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import it.haefelinger.flaka.When;
import java.io.*;

import java.util.ArrayList;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.taskdefs.Sequential;


/**
 * 
 * @author merzedes
 * @since 1.0
 */
public class Choose extends Task {
  public List whenlist;
  public Sequential otherwise;

  public List caselist() {
    if (this.whenlist == null) {
      this.whenlist = new ArrayList();
    }
    return this.whenlist;
  }

  public void addWhen(When task)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Choose.addWhen.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (task != null)

fos.write("2\nB1\n".getBytes());

      caselist().add(task);

fos.write("3\nB2\n".getBytes());

fos.close();

  }

  public void addUnless(Unless task)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Choose.addUnless.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (task != null)

fos.write("2\nB1\n".getBytes());

      caselist().add(task);

fos.write("3\nB2\n".getBytes());

fos.close();

  }

  public void addOtherwise(Sequential task) throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Choose.addOtherwise.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (task == null) {

fos.write("2\nB1\n".getBytes());

      return;
    }
    if (this.otherwise != null) {

fos.write("3\nB2\n".getBytes());

      throwbx("<otherwise/> clause already used.");
      return;
    }
    this.otherwise = task;
fos.close();
    return;



  }

  public void addDefault(Sequential task)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Choose.addDefault.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (task == null) {

fos.write("2\nB1\n".getBytes());

      return;
    }
    if (this.otherwise != null) {

fos.write("3\nB2\n".getBytes());

      throwbx("<otherwise/> clause already used.");
      return;
    }
    this.otherwise = task;
fos.close();
    return;


  }

  public void execute() {
      try{
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Choose.execute.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    When when;
    /*
     * If we do not have some 'when' conditions but we have an otherwise we
     * execute the otherwise, otherwise we return silently.
     */
    if (this.whenlist == null) {

fos.write("2\nB1\n".getBytes());

      if (this.otherwise != null) {

fos.write("3\nB2\n".getBytes());

        this.otherwise.execute();
      }
      return;
    }

    /* execute the very fist 'when' that evaluates to 'true' */
    for (int i = 0; i < this.whenlist.size(); ++i) {

fos.write("4\nB3\n".getBytes());

      when = (When) this.whenlist.get(i);
      if (when.eval()) {

fos.write("5\nB4\n".getBytes());

        when.exec();
        return;
      }
    }

    /* otherwise execute the otherwise task */
    if (this.otherwise != null) {

fos.write("6\nB5\n".getBytes());

      this.otherwise.execute();
    }
fos.close();
    return;
      }catch(Exception e){ }

  }
}