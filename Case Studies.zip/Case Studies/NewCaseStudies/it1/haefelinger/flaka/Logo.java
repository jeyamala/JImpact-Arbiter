
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;
import it1.haefelinger.flaka.util.TextReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;


/**
 * 
 * @author merzedes
 * @since 1.0
 */
public class Logo extends Task {
  public String text = "";
  public String chr = ":";
  public int width = 80;
  public TextReader tr = new TextReader();

  public Logo() {
    super();
    this.tr.setIC(";");
    this.tr.setSkipws(true);
    this.tr.setResolveContLines(true);
    this.tr.setSkipEmpty(false);
  }

  public void addText(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Logo.addText.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.tr.setText(s);
fos.close();

  }

  public void setChr(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Logo.setChr.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.chr = Static.trim2(s, this.chr);
fos.close();

  }

  public void setWidth(int s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Logo.setWidth.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.width = s;
fos.close();

  }

  public void setCs(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Logo.setCs.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.tr.setCL(s);
fos.close();

  }

  public void setIcs(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Logo.setIcs.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.tr.setIC(s);
fos.close();

  }

  public void setWs(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Logo.setWs.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    // TODO: document me
    this.tr.setSkipws(b);
fos.close();

  }

  public void setCl(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Logo.setCl.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    // TODO: document me
    this.tr.setResolveContLines(b);
fos.close();

  }

  public void execute() throws BuildException  {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.Logo.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            Project project = this.getProject();
            String line = this.tr.readLine();
            System.out.println(Static.mkchrseq(this.chr, this.width));
            int w = this.chr.length();
            while (line != null) {
                fos.write("2\nB1\n".getBytes());
                line = project.replaceProperties(line);
                /* resolve all EL references #{ ..} */
                line = Static.elresolve(project, line);
                System.out.print(this.chr);
                System.out.print(Static.center(line, this.width - 2 * w, " "));
                System.out.print(this.chr);
                System.out.println();
                line = this.tr.readLine();
            }
            System.out.println(Static.mkchrseq(this.chr, this.width));
            System.out.flush();
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(Logo.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(Logo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }
}