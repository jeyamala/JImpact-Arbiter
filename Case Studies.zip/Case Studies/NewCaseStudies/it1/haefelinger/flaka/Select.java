
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.

 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;

/**
 * Create a new property by selecting a couple of existing ones ..
 * 
 * @author merzedes
 * @since 1.0
 */
public class Select extends Task {

    public String regex = null;
    public String property = null;
    public String sep = ",";

    public void setProperty(String s) throws Exception {
        File file1 = new File("src//instrumented//it1.haefelinger.flaka.Select.setProperty.txt");
        FileOutputStream fos = new FileOutputStream(file1, false);

        fos.write("1\n".getBytes());

        this.property = Static.trim2(s, this.property);
        fos.close();

    }

    public void setRegex(String s) throws Exception {
        File file1 = new File("src//instrumented//it1.haefelinger.flaka.Select.setRegex.txt");
        FileOutputStream fos = new FileOutputStream(file1, false);

        fos.write("1\n".getBytes());

        this.regex = Static.trim2(s, this.regex);
        fos.close();

    }

    public void setSep(String s) throws Exception {
        File file1 = new File("src//instrumented//it1.haefelinger.flaka.Select.setSep.txt");
        FileOutputStream fos = new FileOutputStream(file1, false);

        fos.write("1\n".getBytes());

        this.sep = s;
        fos.close();

    }

    public static String[] select_properties(Project P, String regex) {
        String[] L = null;
        try {
            L = Static.grep(P, regex);
        } catch (Exception e) {
            Static.verbose(P, "error grepping properties using pattern `" + regex
                    + "'", e);
            L = null;
        }
        return L;
    }

    public void execute() throws BuildException {
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.Select.execute.txt");
            FileOutputStream fos = new FileOutputStream(file1, false);

            fos.write("1\n".getBytes());

            Project P;
            String s;
            String[] L;

            if (this.property == null) {

                fos.write("2\nB1\n".getBytes());

                debug("missing attribute `property` ..");
                return;
            }

            if (this.regex == null) {

                fos.write("3\nB2\n".getBytes());

                debug("missing attribute `regex' ..");
                return;
            }

            P = getProject();

            if (P.getProperty(this.property) != null) {

                fos.write("4\nB3\n".getBytes());

                debug("property `" + this.property + "' already defined (task skipped)");
            }

            /* grep properties */
            L = select_properties(P, this.regex);

            if (L == null) {

                fos.write("5\nB4\n".getBytes());

                /* propably syntax error in pattern */
                return;
            }

            if (L.length <= 0) {

                fos.write("6\nB5\n".getBytes());

                verbose("no properties matching pattern `" + this.regex + "', property `"
                        + this.property + "' will be empty.");
            }

            s = null;
            for (int i = 0; i < L.length; ++i) {

                fos.write("7\nB6\n".getBytes());

                String[] S = null;
                try {
                    /* split not more than one time */
                    S = L[i].split("=", 2);
                } catch (Exception ex) {
                    continue;
                }
                if (S == null || S.length != 2) {

                    fos.write("8\nB7\n".getBytes());

                    continue;
                }

                if (s == null) {
                    fos.write("9\nB8\n".getBytes());

                    s = S[1];
                } else {

                    fos.write("10\nB9\n".getBytes());

                    s += this.sep + S[1];
                }
            }
            if (s == null) {
                fos.write("11\nB10\n".getBytes());

                s = "";

                /* will only set if not already set */
                Static.assign(P, this.property, s, Static.PROPTY);
                fos.close();
            }
        } catch (Exception e) {
        }
    }
}
