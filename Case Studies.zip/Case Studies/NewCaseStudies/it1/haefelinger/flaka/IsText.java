
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.types.selectors.BaseSelector;


/**
 * 
 * @author merzedes
 * @since 1.0
 */
public class IsText extends BaseSelector {
  /** upper limit of characters to investige. */
  public long limit = -1;

  /** invert selection */
  public boolean invert = false;

  /** set limit */
  public void setLimit(long n)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.IsText.setLimit.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.limit = n;
fos.close();

  }

  public void setInvertMatch(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.IsText.setInvertMatch.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.invert = b;
fos.close();

  }

  public void setInvert(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.IsText.setInvert.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.invert = b;
fos.close();

  }

  /**
   * * Implements a selector to restrict a given fileset to contain * "textual"
   * files only. * *
   */

  public boolean isSelected(File basedir, String filename, File file)  {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.IsText.isSelected.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            String path;
            InputStream S;
            boolean retv = false;
            if (file == null || basedir == null || filename == null) {
                fos.write("2\nB1\n".getBytes());
                debug("isText: some `nil' arguments seen, return `false'");
                return false;
            }
            path = file.getAbsolutePath();
            if (file.isDirectory()) {
                fos.write("3\nB2\n".getBytes());
                debug("`" + path + "` is a directory, return `false'");
                return false;
            }
            if (!file.canRead()) {
                fos.write("4\nB3\n".getBytes());
                debug("`" + path + "` is not readable, return `false'");
                return false;
            }
            S = open(file);
            if (S == null) {
                fos.write("5\nB4\n".getBytes());
                debug("unable to open `" + path + "`, return `false'");
                return false;
            }
            try {
                retv = istext(S, this.limit);
                debug("istext('" + path + "') = " + retv);
                retv = this.invert ? !retv : retv;
            } catch (Exception e) {
                debug("error while reading from `" + path + "`", e);
            } finally {
                if (!close(S)) {
                    fos.write("6\nB5\n".getBytes());
                }
                debug("unable to close `" + path + "` (error ignored).");
            }
            fos.close();
            return retv;
        } catch (Exception ex) {
            Logger.getLogger(IsText.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(IsText.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return false;

  }

  public boolean istext(InputStream S, long max) throws Exception  {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.IsText.istext.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    int c;
    boolean b;

    c = S.read();
    b = true;

    if (max < 0) {

fos.write("2\nB1\n".getBytes());

      while (b && c != -1) {

fos.write("3\nB2\n".getBytes());

        b = Static.istext((char) c);
        c = S.read();
      }
    } else {

fos.write("4\nB3\n".getBytes());

      for (long i = 0; b && i < max; ++i) {

fos.write("5\nB4\n".getBytes());

        b = Static.istext((char) c);
        c = S.read();
      }
    }
fos.close();
    return b;

  }

  public boolean isbinary(InputStream S, long max) throws Exception  {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.IsText.isbinary.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return istext(S, max) ? false : true;

  }

  public InputStream open(File file) {
    InputStream retv = null;
    try {
      retv = new FileInputStream(file);
      retv = new BufferedInputStream(retv);
    } catch (Exception e) {
      /* ignore */
    }
    return retv;
  }

  public boolean close(InputStream S)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.IsText.close.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    boolean b = true;
    try {
      if (S != null)

fos.write("2\nB1\n".getBytes());

        S.close();
    } catch (Exception e) {
      b = false;
    }
fos.close();
    return b;

  }

  public void debug(String msg)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.IsText.debug.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Static.debug(getProject(), "istext: " + msg);
fos.close();

  }

  public void debug(String msg, Exception e)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.IsText.debug.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Static.debug(getProject(), "istext: " + msg, e);
fos.close();

  }
}