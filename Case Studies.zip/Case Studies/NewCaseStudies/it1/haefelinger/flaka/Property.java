
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;
import it1.haefelinger.flaka.util.TextReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;


/**
 * A task to set multiple properties at once.
 * 
 * 
 * @author merzedes
 * @since 1.0
 */
public class Property extends Task {
  public TextReader tr = new TextReader();

  public void setComment(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Property.setComment.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.tr.setCL(s);
fos.close();

  }

  public void setCs(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Property.setCs.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    // TODO: document me
    this.tr.setCL(s);
fos.close();

  }

  public void setIcs(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Property.setIcs.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    // TODO: document me
    this.tr.setIC(s);
fos.close();

  }

  public void setCL(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Property.setCL.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    // TODO: document me
    this.tr.setResolveContLines(b);
fos.close();

  }

  public void addText(String text)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Property.addText.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.tr.setText(text);
fos.close();

  }

  public Pattern makeregex(String s) {
    Pattern re = null;
    try {
      re = Pattern.compile(s);
    } catch (Exception e) {
      /* TODO: error */
      Static.debug(getProject(), "error compiling regex '" + s + "'", e);
    }
    return re;
  }

  public Pattern getPropRegex() {
    return makeregex("([^=:]+)[:=](.*)");
  }

  public void execute() throws BuildException  {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.Property.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            Project project;
            Pattern regex;
            Matcher M;
            String line;
            String k;
            String v;
            project = this.getProject();
            regex = this.getPropRegex();
            while ((line = this.tr.readLine()) != null) {
                fos.write("2\nB1\n".getBytes());
                line = project.replaceProperties(line);
                /* resolve all EL references #{ ..} */
                line = Static.elresolve(project, line);
                if (!(M = regex.matcher(line)).matches()) {
                    fos.write("3\nB2\n".getBytes());
                    Static.debug(getProject(), "line : bad property line '" + line + "'");
                    continue;
                }
                k = M.group(1);
                v = M.group(2).trim();
                try {
                    // k = project.replaceProperties(k);
                    // k = Static.elresolve(project, k);
                    // v = project.replaceProperties(v);
                    // v = Static.elresolve(project, v);
                } catch (Exception e) {
                    Static.debug(project, "line : error evaluating EL expression (ignored) in " + Static.q(v));
                }
                Static.assign(project, k, v, Static.PROPTY);
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(Property.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(Property.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }

}