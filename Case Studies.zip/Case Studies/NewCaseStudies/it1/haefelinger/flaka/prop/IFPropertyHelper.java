package it1.haefelinger.flaka.prop;

import java.io.*;


public interface IFPropertyHelper {
    public boolean enable(boolean b);
}

