
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.Location;
import org.apache.tools.ant.Project;


/**
 * @author merzedes
 * @since 1.0
 */
public class Task extends org.apache.tools.ant.Task {
  public boolean el = true;
  public boolean debug = false;

  public void setEl(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.setEl.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.el = b;
fos.close();

  }

  public void setDebug(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.setDebug.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.debug = b;
fos.close();

  }

  /**
   * Reference object denoted by string <b>s</b>.
   * 
   * This method is a wrapper around method
   * {@link org.apache.tools.ant.Project#getReference(String)} allowing to pass
   * a null string as well. If null is passed, a null object is returned.
   * 
   * @param s
   *          may be null
   * @return object denoted by <code>s</code> or null if not existing.
   */
  final public Object getref(String s) {
    return s == null ? null : getProject().getReference(s);
  }

  /**
   * A convenient method to retrieve a project property.
   * 
   * @param s
   *          might be null
   * @return value of property <code>s</code> or null if such a property does
   *         not exist or if no project is associated with this task.
   */
  final public String getProperty(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.getProperty.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Project P = getProject();
fos.close();
    return P != null ? P.getProperty(s) : null;

  }

  final public void throwbx(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.throwbx.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Static.throwbx(s);
fos.close();

  }

  final public File toFile(String s) {
    return Static.toFile(this.getProject(), s);
  }

  final public void throwbx(String s, Exception e)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.throwbx.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Static.throwbx(s, e);
fos.close();

  }

    @Override
  final public void log(String msg)  {

        try {
              FileOutputStream fos = null;
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.log.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            if (msg != null) {
                fos.write("2\nB1\n".getBytes());
                Static.log(getProject(), msg);
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(Task.class.getName()).log(Level.SEVERE, null, ex);
        }

  }

  final public void debug(String msg)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.debug.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (this.debug) {

fos.write("2\nB1\n".getBytes());

      System.err.println(msg);
      return;
    }
    if (msg != null) {

fos.write("3\nB2\n".getBytes());

      Static.debug(getProject(), msg);
    }
fos.close();

  }

  final public void debug(String msg, Exception e)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.debug.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (msg != null) {

fos.write("2\nB1\n".getBytes());

      Static.debug(getProject(), msg, e);
    }
fos.close();

  }

  final public void verbose(String msg)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.verbose.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (msg != null) {

fos.write("2\nB1\n".getBytes());

      Static.verbose(getProject(), msg);
    }
fos.close();

  }

  @SuppressWarnings("boxing")
  final public void warn(String msg)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.warn.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (msg != null) {

fos.write("2\nB1\n".getBytes());

      Location where;
      String bname, tname;
      String buf;
      int line;
      int col;

      where = getLocation();
      bname = new File(where.getFileName()).getName();
      tname = this.getTaskName();
      line = where.getLineNumber();
      col = where.getColumnNumber();
      buf = String.format("%s:%s:%s[%s]: %s", bname, line, col, tname, msg);
      Static._log_(getProject(), buf.toString(), Project.MSG_WARN);
    }
fos.close();

  }

  public void warn(String msg, Exception e)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.warn.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (msg != null && e != null) {

fos.write("2\nB1\n".getBytes());

      Static._log_(getProject(), msg + ", got " + e.getMessage(),
          Project.MSG_WARN);
    }
fos.close();

  }

  final public void error(String msg)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.error.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (msg != null) {

fos.write("2\nB1\n".getBytes());

      Static._log_(getProject(), msg, Project.MSG_ERR);
    }
fos.close();

  }

  final public void error(String msg, Exception e)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.error.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (msg != null && e != null) {

fos.write("2\nB1\n".getBytes());

      Static._log_(getProject(), msg + ", got " + e.getMessage(),
          Project.MSG_ERR);
    }
fos.close();

  }

  final public void info(String msg)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Task.info.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (msg != null) {

fos.write("2\nB1\n".getBytes());

      super.log(msg, Project.MSG_INFO);
    }
fos.close();

  }

}