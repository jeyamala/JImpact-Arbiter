
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */

/*
 * Copyright 2001-2005 The Apache Software Foundation
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this loc except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 */package it1.haefelinger.flaka.type;

import java.io.*;

import it.haefelinger.flaka.util.Static;

import java.util.Enumeration;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * A set of filters to be applied to something.
 * 
 * A filter set may have begintoken and endtokens defined.
 * 
 * *
 * 
 * @author merzedes
 * @since 1.0
 */
public class FilterSet extends org.apache.tools.ant.types.FilterSet {
  public class Props {
    /* empty class */
  }

  public void grep(String regexpr)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.type.FilterSet.grep.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String[] R;
    Pattern P;
    Matcher M;
    Enumeration E;
    LinkedList L;

    R = null;
    P = Pattern.compile(regexpr);
    L = new LinkedList();
    E = getProject().getProperties().keys();

    while (E.hasMoreElements()) {

fos.write("2\nB1\n".getBytes());

      String k;

      k = (String) E.nextElement();
      M = P.matcher(k);

      if (M.matches() == false) {

fos.write("3\nB2\n".getBytes());

        continue;
      }
      L.add(k);
    }

    R = new String[L.size()];
    for (int i = 0; i < L.size(); ++i)
    {
fos.write("4\nB3\n".getBytes());

      R[i] = (String) L.get(i);
      }
      L = null;
    addtokens(R);
fos.close();

  }

  public void addtokens(String[] name)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.type.FilterSet.addtokens.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (name != null && name.length > 0) {

fos.write("2\nB1\n".getBytes());

      String k, v;
      for (int i = 0; i < name.length; ++i) {

fos.write("3\nB2\n".getBytes());

        k = name[i];
        v = getProject().getProperty(k);
        v = getProject().replaceProperties(v);
        addtoken(k, v);
      }
    }
fos.close();

  }

  public void addtoken(String K, String V)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.type.FilterSet.addtoken.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String k = K;
    String v = V;
    if (k == null) {

fos.write("2\nB1\n".getBytes());

      return;
    }
    k = k.trim();
    if (k.length() <= 0) {

fos.write("3\nB2\n".getBytes());

      return;
    }
    if (v == null)

fos.write("4\nB3\n".getBytes());

      v = "";
    super.addFilter(k, v);
fos.close();

  }

  /** support for element </code>properties</code> */
  public Props createProperties() {
        try {
            String s;
            s = Static.patternAsRegex("*");
            grep(s);

        } catch (Exception ex) {
            Logger.getLogger(FilterSet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new Props();
  }
}