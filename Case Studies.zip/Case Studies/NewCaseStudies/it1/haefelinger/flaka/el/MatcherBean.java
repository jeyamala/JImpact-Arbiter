package it1.haefelinger.flaka.el;

import java.io.*;

import java.util.regex.Matcher;


/**
 * The sole purpose of this class is to answer questions on <em>properties</em>
 * asked by a resolver, usually a bean resolver (hence the name BeanMatcher).
 * 
 * 
 * @author merzedes
 * @since 1.0
 */
public class MatcherBean {
  final Matcher m;
  final int index;

  @SuppressWarnings("unused")
  public MatcherBean() {
    this.m = null;
    this.index = 0;
  }

  public MatcherBean(Matcher m, int index) {
    this.m = m;
    this.index = index;
  }

  public Matcher getMatcher() {
    return this.m;
  }

  public int getStart()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getStart.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.m.start(this.index);

  }

  public int getS()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getS.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return getStart();

  }

  public int getEnd()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getEnd.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.m.end(this.index);

  }

  public int getE()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getE.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return getEnd();

  }

  public String getPattern()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getPattern.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.m.pattern().pattern();

  }

  public String getP()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getP.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return getPattern();

  }

  public int getGroups()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getGroups.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.m.groupCount();

  }

  public int getN()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getN.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return getGroups();

  }

  public int getLength()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getLength.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return getGroups();

  }

  public int getSize()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.el.MatcherBean.getSize.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return getGroups();

  }

  public String toString() {
    return this.m.group(this.index);

  }

}