
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;


/**
 * A simple task which installs or deinstalls a specialized * ComponentHelper.
 * This specialized version is supposed to get * rid of some anoying log
 * messages. Installation may fail if * your Ant does not support all required
 * methods. * *
 * 
 * 
 * @author merzedes
 * @since 1.0
 * @deprecated
 */

public class InstCompH extends Task {
  public boolean install = true;
  public boolean fail = false;

  public void setInstall(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.InstCompH.setInstall.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.install = b;
fos.close();

  }

  public void setUnInstall(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.InstCompH.setUnInstall.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.install = !b;
fos.close();

  }

  public void setFail(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.InstCompH.setFail.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.fail = b;
fos.close();

  }

  public void warnordie(String msg) throws BuildException  {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.InstCompH.warnordie.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            if (this.fail) {
                fos.write("2\nB1\n".getBytes());
          
            throwbx(msg);

    }
    else
    {
fos.write("3\nB2\n".getBytes());

      verbose(msg);
fos.close();
    }
      }catch(Exception e){ }
  }

  public void execute() throws BuildException   {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.InstCompH.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            Project P;
            P = getProject();
            if (this.install) {
                fos.write("2\nB1\n".getBytes());
                if (!CompH.install(P)) {
                    fos.write("3\nB2\n".getBytes());
                    warnordie("failed to install customized component helper.");
                }
            } else {
                fos.write("4\nB3\n".getBytes());
                if (!CompH.uninstall(P)) {
                    fos.write("5\nB4\n".getBytes());
                    warnordie("failed to uninstall customized component helper.");
                }
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(InstCompH.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(InstCompH.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }
}