
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.MatchingTask;


/**
 * A task echoing files in a fileset similar as the Unix command
 * <code>find</code> would do.
 * 
 * 
 * @author merzedes
 * @since 1.0
 */

public class Find extends MatchingTask {
  public String srcdir = "''.tofile";
  public String type = null;
  public String var = null;

  public void setVar(String var)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Find.setVar.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.var = Static.trim3(getProject(), var, this.var);
fos.close();

  }

  public void setDir(String dir)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Find.setDir.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.srcdir = Static.trim3(getProject(), dir, this.srcdir);
fos.close();

  }

  public void setType(String type)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Find.setType.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.type = Static.trim3(getProject(), type, this.type);
fos.close();

  }

  public DirectoryScanner getds(File dir) {
    DirectoryScanner ds = null;
    ds = super.getDirectoryScanner(dir);
    return ds;
  }

  public void scan(File dir, List C)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Find.scan.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Project project;
    DirectoryScanner ds;

    project = getProject();
    if (dir == null)
    {
fos.write("2\nB1\n".getBytes());

fos.close();
      return;
      }

    if (!dir.exists()) {

fos.write("3\nB2\n".getBytes());

      Static.debug(project, "ignoring non existent folder:" + dir);
      return;
    }
    if (!dir.isDirectory()) {

fos.write("4\nB3\n".getBytes());

      Static.debug(project, "ignoring non folder:" + dir);
      return;
    }
    try {
      ds = getds(dir);
      String[] buf = null;
      if (this.type == null || this.type.equals("f"))
      {
fos.write("5\nB4\n".getBytes());

        buf = ds.getIncludedFiles();
        }
      else if (this.type.equals("d"))
      {
fos.write("6\nB5\n".getBytes());

        buf = ds.getIncludedDirectories();
      }
      if (buf != null)
      {
fos.write("7\nB6\n".getBytes());
        }
        for (int j = 0; j < buf.length; ++j) {

fos.write("8\nB7\n".getBytes());

          File file = new File(dir, buf[j]);
          C.add(file);
        }
    } catch (Exception e) {
      Static.debug(project, "error scanning " + dir, e);
    }
fos.close();

  }

  public void set(String name, String value)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Find.set.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String p = getProject().getProperty(name);
    p = (p == null) ? value : (p + " " + value);
    getProject().setProperty(name, p);
fos.close();

  }

  static List makelist(Object... argv) {
    List L = new ArrayList();
    for (int i = 0, n = argv.length; i < n; ++i)
      if (argv[i] != null)
        L.add(argv[i]);
    return L;
  }

  static Iterator iteratorof(Object obj) {
    Iterator iter = null;
    if (obj instanceof Iterable) {
      iter = ((Iterable) obj).iterator();
    } else {
      iter = makelist(obj).iterator();
    }
    return iter;
  }

  /**
   * perfoms the <code>find</code> operation.
   * 
   * @exception BuildException
   *              if an error occurs
   */

  public void execute() throws BuildException  {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.Find.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            Project project;
            Object obj;
            File dir;
            Iterator di;
            ArrayList L;
            project = getProject();
            // eval dir attribute
            obj = Static.el2obj(project, this.srcdir);
            di = iteratorof(obj);
            L = new ArrayList();
            while (di.hasNext()) {
                fos.write("2\nB1\n".getBytes());
                obj = di.next();
                dir = null;
                if (obj instanceof File) {
                    fos.write("3\nB2\n".getBytes());
                    dir = (File) obj;
                } else {
                    fos.write("4\nB3\n".getBytes());
                    dir = Static.toFile(project, obj.toString());
                }
                scan(dir, L);
            }
            Static.assign(project, this.var, L, Static.VARREF);
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(Find.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(Find.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }
}