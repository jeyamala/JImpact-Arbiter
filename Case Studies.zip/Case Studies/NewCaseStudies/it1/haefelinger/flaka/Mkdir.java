
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.tools.ant.BuildException;


/**
 * 
 * @author merzedes
 * @since 1.0
 */
public class Mkdir extends Task {

  public static final int MKDIR_RETRY_SLEEP_MILLIS = 10;

  public File dir;
  public boolean verbose = false;

  public void execute() throws BuildException  {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.Mkdir.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            if (this.dir == null) {
                fos.write("2\nB1\n".getBytes());
                debug("mkdir called without `dir' attribute set");
                return;
            }
            if (this.dir.isDirectory()) {
                fos.write("3\nB2\n".getBytes());
                /* exists already */
                return;
            }
            if (this.dir.exists()) {
                fos.write("4\nB3\n".getBytes());
                String s = this.dir.getAbsolutePath();
                throwbx("unable to create `" + s + "', exists and is not a directory.");
            }
            mkdirs(this.dir);
            if (this.dir.isDirectory()) {
                fos.write("5\nB4\n".getBytes());
                if (this.verbose) {
                    fos.write("6\nB5\n".getBytes());
                }
                log("directory `" + this.dir.getPath() + "' created.");
            } else {
                fos.write("7\nB6\n".getBytes());
                String s = "failed to create `" + this.dir.getAbsolutePath() + "'";
                throwbx(s);
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(Mkdir.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(Mkdir.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }

  /**
   * the directory to create; not required.
   * 
   * @param dir
   *          the directory to be made.
   */
  public void setDir(File dir)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Mkdir.setDir.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.dir = dir;
fos.close();

  }

  public void setVerbose(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Mkdir.setVerbose.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.verbose = b;
fos.close();

  }

  /**
   * Attempt to fix possible race condition when creating directories on WinXP.
   * If the mkdirs does not work, wait a little and try again.
   */

  public boolean mkdirs(File f)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Mkdir.mkdirs.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (!f.mkdirs()) {

fos.write("2\nB1\n".getBytes());

      try {
        Thread.sleep(MKDIR_RETRY_SLEEP_MILLIS);
        return f.mkdirs();
      } catch (InterruptedException ex) {
        return f.mkdirs();
      }
    }
fos.close();
    return true;

  }
}