
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;
import it1.haefelinger.flaka.util.TextReader;

import java.util.ArrayList;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;


/**
 * 
 * @author merzedes
 * @since 1.0
 */
public class List extends Task {
  public String var;
  public java.util.List list = new ArrayList();
  public TextReader tr = new TextReader();

  public void setComment(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.List.setComment.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.tr.setCL(s);
fos.close();

  }

  public void setCs(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.List.setCs.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    // TODO: document me
    this.tr.setCL(s);
fos.close();

  }

  public void setIcs(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.List.setIcs.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    // TODO: document me
    this.tr.setIC(s);
fos.close();

  }

  public void setCL(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.List.setCL.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    // TODO: document me
    this.tr.setResolveContLines(b);
fos.close();

  }

  public void setVar(String var)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.List.setVar.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.var = Static.trim3(getProject(), var, this.var);
fos.close();

  }

  public void addText(String text)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.List.addText.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.tr.setText(text);
fos.close();

  }

  public void append(Object obj)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.List.append.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.list.add(obj);
fos.close();

  }

  public java.util.List eval() throws BuildException {
    Project project;
    String line;
    Object obj;

    if (this.tr.getText() != null) {
      /* start evaluation text */
      project = this.getProject();

      /* read line by line */
      while ((line = this.tr.readLine()) != null) {
        line = project.replaceProperties(line);

        /* resolve all EL references #{ ..} */
        line = Static.elresolve(project, line);

        try {
          if (this.el)
            obj = Static.el2obj(project, line);
          else
            obj = line.trim();
          append(obj);
        } catch (Exception e) {
          String s = "line : error evaluating EL expression (ignored) in "
              + Static.q(line);
          this.log(s);
        }
      }
    }
    /* ensure that we in any case return a list */
    return this.list;
  }

  public void execute() throws BuildException  {
    Static.assign(getProject(), this.var, eval(), Static.VARREF);
  }
}