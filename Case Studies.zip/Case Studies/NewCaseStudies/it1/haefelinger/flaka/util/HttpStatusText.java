
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka.util;

import java.io.*;


/**
 * 
 * @author merzedes
 * @since 1.0
 */
public class HttpStatusText {
  final static public String explain(int status)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.util.HttpStatusText.explain.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    switch (status) {
    case 100:

fos.write("2\nB1\n".getBytes());

      return "100 Continue: The client SHOULD continue with its request. This interim response is used to inform the client that the initial part of the request has been received and has not yet been rejected by the server.";

    case 101:

fos.write("3\nB2\n".getBytes());

      return "101 Switching Protocols: The server understands and is willing to comply with the client's request, via the Upgrade message header field (section 14.42), for a change in the application protocol being used on this connection.";

    case 200:

fos.write("4\nB3\n".getBytes());

      return "200 OK: The request has succeeded.";

    case 201:

fos.write("5\nB4\n".getBytes());

      return "201 Created: The request has been fulfilled and resulted in a new resource being created.";

    case 202:

fos.write("6\nB5\n".getBytes());

      return "202 Accepted: The request has been accepted for processing, but the processing has not been completed.";

    case 203:

fos.write("7\nB6\n".getBytes());

      return "203 Non-Authoritative Information: The returned metainformation in the entity-header is not the definitive set as available from the origin server, but is gathered from a file or a third-party copy.";

    case 204:

fos.write("8\nB7\n".getBytes());

      return "204 No Content: The server has fulfilled the request but does not need to return an entity-body, and might want to return updated metainformation.";

    case 205:

fos.write("9\nB8\n".getBytes());

      return "205 Reset Content: The server has fulfilled the request and the user agent SHOULD reset the document view which caused the request to be sent.";

    case 206:

fos.write("10\nB9\n".getBytes());

      return "206 Partial Content: The server has fulfilled the partial GET request for the resource. The request MUST have included a Range header field (section 14.35) indicating the desired range, and MAY have included an If-Range header field (section 14.27) to make the request conditional.";

    case 300:

fos.write("11\nB10\n".getBytes());

      return "300 Multiple Choices: The requested resource corresponds to any one of a set of representations, each with its own specific location, and agent- driven negotiation information (section 12) is being provided so that the user (or user agent) can select a preferred representation and redirect its request to that location.";

    case 301:

fos.write("12\nB11\n".getBytes());

      return "301 Moved Permanently: The requested resource has been assigned a new permanent URI and any future references to this resource SHOULD use one of the returned URIs.";

    case 302:

fos.write("13\nB12\n".getBytes());

      return "302 Found: The requested resource resides temporarily under a different URI.";

    case 303:

fos.write("14\nB13\n".getBytes());

      return "303 See Other: The response to the request can be found under a different URI and SHOULD be retrieved using a GET method on that resource.";

    case 304:

fos.write("15\nB14\n".getBytes());

      return "304 Not Modified: If the client has performed a conditional GET request and access is allowed, but the document has not been modified, the server SHOULD respond with this status code.";

    case 305:

fos.write("16\nB15\n".getBytes());

      return "305 Use Proxy: The requested resource MUST be accessed through the proxy given by the Location field. The Location field gives the URI of the proxy. The recipient is expected to repeat this single request via the proxy.";

    case 306:

fos.write("17\nB16\n".getBytes());

      return "306 (Unused): The 306 status code was used in a previous version of the specification, is no longer used, and the code is reserved.";

    case 307:

fos.write("18\nB17\n".getBytes());

      return "307 Temporary Redirect: The requested resource resides temporarily under a different URI.";
    case 401:

fos.write("19\nB18\n".getBytes());

      return "401 Unauthorized: The request requires user authentication. The response MUST include a WWW-Authenticate header field (section 14.47) containing a challenge applicable to the requested resource.";
    case 402:

fos.write("20\nB19\n".getBytes());

      return "402 Payment Required: This code is reserved for future use.";
    case 403:

fos.write("21\nB20\n".getBytes());

      return "403 Forbidden: The server understood the request, but is refusing to fulfill it. Authorization will not help and the request SHOULD NOT be repeated.";
    case 404:

fos.write("22\nB21\n".getBytes());

      return "404 Not Found: The server has not found anything matching the Request-URI. No indication is given of whether the condition is temporary or permanent.";
    case 405:

fos.write("23\nB22\n".getBytes());

      return "405 Method Not Allowed: The method specified in the Request-Line is not allowed for the resource identified by the Request-URI.";
    case 406:

fos.write("24\nB23\n".getBytes());

      return "406 Not Acceptable: The resource identified by the request is only capable of generating response entities which have content characteristics not acceptable according to the accept headers sent in the request.";

    case 407:

fos.write("25\nB24\n".getBytes());

      return "407 Proxy Authentication Required: This code is similar to 401 (Unauthorized), but indicates that the client must first authenticate itself with the proxy.";

    case 408:

fos.write("26\nB25\n".getBytes());

      return "408 Request Timeout: The client did not produce a request within the time that the server was prepared to wait.";

    case 409:

fos.write("27\nB26\n".getBytes());

      return "409 Conflict: The request could not be completed due to a conflict with the current state of the resource.";

    case 410:

fos.write("28\nB27\n".getBytes());

      return "410 Gone: The requested resource is no longer available at the server and no forwarding address is known. This condition is expected to be considered permanent.";

    case 411:

fos.write("29\nB28\n".getBytes());

      return "411 Length Required: The server refuses to accept the request without a defined Content- Length.";

    case 412:

fos.write("30\nB29\n".getBytes());

      return "412 Precondition Failed: The precondition given in one or more of the request-header fields evaluated to false when it was tested on the server.";

    case 413:

fos.write("31\nB30\n".getBytes());

      return "413 Request Entity Too Large: The server is refusing to process a request because the request entity is larger than the server is willing or able to process.";

    case 414:

fos.write("32\nB31\n".getBytes());

      return "414 Request-URI Too Long: The server is refusing to service the request because the Request-URI is longer than the server is willing to interpret.";

    case 415:

fos.write("33\nB32\n".getBytes());

      return "415 Unsupported Media Type: The server is refusing to service the request because the entity of the request is in a format not supported by the requested resource for the requested method.";

    case 416:

fos.write("34\nB33\n".getBytes());

      return "416 Requested Range Not Satisfiable: A server SHOULD return a response with this status code if a request included a Range request-header field (section 14.35), and none of the range-specifier values in this field overlap the current extent of the selected resource, and the request did not include an If-Range request-header field.";

    case 417:

fos.write("35\nB34\n".getBytes());

      return "417 Expectation Failed: The expectation given in an Expect request-header field (see section 14.20) could not be met by this server, or, if the server is a proxy, the server has unambiguous evidence that the request could not be met by the next-hop server.";

    case 500:

fos.write("36\nB35\n".getBytes());

      return "500 Internal Server Error: The server encountered an unexpected condition which prevented it from fulfilling the request.";

    case 501:

fos.write("37\nB36\n".getBytes());

      return "501 Not Implemented: The server does not support the functionality required to fulfill the request. This is the appropriate response when the server does not recognize the request method and is not capable of supporting it for any resource.";

    case 502:

fos.write("38\nB37\n".getBytes());

      return "502 Bad Gateway: The server, while acting as a gateway or proxy, received an invalid response from the upstream server it accessed in attempting to fulfill the request.";
    case 503:

fos.write("39\nB38\n".getBytes());

      return "503 Service Unavailable: The server is currently unable to handle the request due to a temporary overloading or maintenance of the server.";

    case 504:

fos.write("40\nB39\n".getBytes());

      return "504 Gateway Timeout: The server, while acting as a gateway or proxy, did not receive a timely response from the upstream server specified by the URI (e.g. HTTP, FTP, LDAP) or some other auxiliary server (e.g. DNS) it needed to access in attempting to complete the request.";

    case 505:

fos.write("41\nB40\n".getBytes());

      return "505 HTTP Version Not Supported: The server does not support, or refuses to support, the HTTP protocol version that was used in the request message.";

    default:

fos.write("42\nB41\n".getBytes());

      return status
          + ": not a status according to RFC 2616, http://www.w3.org/Protocols/rfc2616";
    }
  }
}