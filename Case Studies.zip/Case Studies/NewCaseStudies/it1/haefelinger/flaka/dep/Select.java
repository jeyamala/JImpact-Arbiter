
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka.dep;

import java.io.*;

import it.haefelinger.flaka.util.Static;

import java.io.File;
import java.util.regex.Pattern;

import org.apache.tools.ant.types.selectors.BaseSelector;


public class Select extends BaseSelector {
  final static public short GLOB = 1;
  final static public short REGEX = 2;

  public boolean needsinit = true;

  public boolean invert = false;
  public int flags = Pattern.CASE_INSENSITIVE;
  public boolean glob = false;

  public String alias_regex = null;
  public String scope_regex = null;
  public String bname_regex = null;
  public String type_regex = null;
  public String gid_regex = null;
  public String path_regex = null;
  public String version_regex = null;

  public Pattern alias = null;
  public Pattern scope = null;
  public Pattern bname = null;
  public Pattern type = null;
  public Pattern gid = null;
  public Pattern path = null;
  public Pattern version = null;

  public String errmsg = null;
  /* The reference holding all known dependencies */
  public String refid = "project.dependencies";

  /**
   * Use attribute <code>refid</code> to change the reference holding all known
   * dependencies.
   * 
   * @param s
   */
  public void setRefid(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setRefid.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.refid = Static.trim2(s, this.refid);
fos.close();

  }

  /**
   * Use attribute <code>ref</code> to change the reference holding all known
   * dependencies.
   * 
   * @param s
   */
  public void setRef(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setRef.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    setRefid(s);
fos.close();

  }

  public void setGlob(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setGlob.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.glob = b;
fos.close();

  }

  public void setInvert(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setInvert.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.invert = b;
fos.close();

  }

  public void setCaseSensitive(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setCaseSensitive.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (b) {

fos.write("2\nB1\n".getBytes());

      // turn CASE_INSENSITIVE off
      this.flags &= ~Pattern.CASE_INSENSITIVE;
    } else {

fos.write("3\nB2\n".getBytes());

      // turn CASE_INSENSITIVE on
      this.flags |= Pattern.CASE_INSENSITIVE;
    }
fos.close();

  }

  public void setIgnore(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setIgnore.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    setCaseSensitive(!b);
fos.close();

  }

  public void setIgnoreCase(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setIgnoreCase.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    setIgnore(b);
fos.close();

  }

  public void setAlias(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setAlias.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.alias_regex = Static.trim2(s, this.alias_regex);
fos.close();

  }

  public void setName(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setName.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    setAlias(s);
fos.close();

  }

  public void setScope(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setScope.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.scope_regex = Static.trim2(s, this.scope_regex);
fos.close();

  }

  public void setBasename(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setBasename.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.bname_regex = Static.trim2(s, this.bname_regex);
fos.close();

  }

  public void setType(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setType.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.type_regex = Static.trim2(s, this.type_regex);
fos.close();

  }

  public void setGroupid(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setGroupid.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.gid_regex = Static.trim2(s, this.gid_regex);
fos.close();

  }

  public void setGroup(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setGroup.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    setGroupid(s);
fos.close();

  }

  public void setGroupname(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setGroupname.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    setGroupid(s);
fos.close();

  }

  public void setPath(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setPath.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.path_regex = s;
fos.close();

  }

  public void setVersion(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.setVersion.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.version_regex = Static.trim2(s, this.version_regex);
fos.close();

  }

  /**
   * Init this instance. Needs to be called before real execution, i.e
   * {@link #isSelected} takes place.
   * <p>
   * The method translates regular expressions given as string into precompiled
   * pattern objects.
   */

  public void init()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.init.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (this.needsinit) {

fos.write("2\nB1\n".getBytes());

      /* precompile regular expressions */
      this.alias = compile(this.alias_regex);
      this.scope = compile(this.scope_regex);
      this.bname = compile(this.bname_regex);
      this.type = compile(this.type_regex);
      this.gid = compile(this.gid_regex);
      this.path = compile(this.path_regex);
      this.version = compile(this.version_regex);
      /* we are done */
      this.needsinit = false;
    }
fos.close();

  }

  /**
   * return <code>s</code> as reference.
   */

  public Object getref(String s) {
    return getProject().getReference(s);
  }

  public Object getref() {
    return getref(this.refid);
  }

  /**
   * compile a string a regular expression pattern. In case of an error, the
   * internal variable <code>errmsg</code> is set.
   * 
   * @return nil if <code>s</code> can't be translated.
   */

  final public Pattern compile(String S) {
    String s = S;
    Pattern P = null;
    if (s != null && s.trim().length() > 0) {
      try {
        if (this.glob) {
          s = Static.patternAsRegex(s);
          P = Pattern.compile(s, this.flags);
        } else {
          P = Static.patterncompile(s, this.flags);
        }
      } catch (Exception e) {
        this.errmsg = e.toString();
      }
    }
    return P;
  }

  final public Dependency[] getdeps() {
    Object ref;
    /* lookup reference */
    ref = getref();

    if (ref == null) {
      return null;
    }

    if (!(ref instanceof Dependency[])) {
      return null;
    }

    return (Dependency[]) ref;
  }

  final public Dependency haveDependency(String filename) {
      try{
    Dependency[] deps = getdeps();

    if (deps != null && filename != null) {
      String fname;

      for (int i = 0; i < deps.length; ++i) {
        fname = deps[i].basename();
        if (fname.equals(filename))
          return deps[i];
      }
    }
      }catch(Exception e){}
    return null;
  }

  /**
   * Match a string against a (precompiled) regular expression.
   * 
   * @param regex
   *          if null, <code>true</code> is returned regardless of
   *          <code>s</code>'s value.
   * 
   * @param s
   *          if <code>null</code> then true is returned if regex is null as
   *          well, otherwise false.
   * 
   */

  final public boolean match(Pattern regex, String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.match.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    boolean b;

    b = true;
    /* a empty regex matches everything */
    if (regex == null)
    {
fos.write("2\nB1\n".getBytes());

fos.close();
      return true;
      }

    /* a empty string is only matched by an empty regex */
    if (s == null)
    {
fos.write("3\nB2\n".getBytes());

fos.close();
      return false;

      }
    /* execute the match */
    b = regex.matcher(s).matches();

fos.close();
    return b;

  }

  /**
   * Implements a selector which can be used to restrict a given fileset. When
   * used without any attributes, a loc in a loc set is selected if that loc is
   * the basename of a dependency. Further checks are carried out if given. For
   * example, if a regular expression has been set to match the scope of a
   * dependency, then the matching dependency must also match that regular
   * expression.
   */
  public boolean isSelected(File basedir, String filename, File file)  {
      try{
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.isSelected.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Dependency d;
    boolean r;
    if (this.needsinit)
    {
fos.write("2\nB1\n".getBytes());

      init();
      }
    /* find a dependency matching this filename */
    d = haveDependency(filename);
    r = (d != null) ? match(d) : false;
fos.close();
    return this.invert ? !r : r;
      }
      catch(Exception e){}
      return false;

  }

  public boolean hasattribs()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.hasattribs.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (this.alias != null)
    {
fos.write("2\nB1\n".getBytes());

fos.close();
      return true;
    }

    if (this.scope != null)
    {
fos.write("3\nB2\n".getBytes());

fos.close();
      return true;
      }

    if (this.bname != null)
    {
fos.write("4\nB3\n".getBytes());

fos.close();
      return true;

      }
    if (this.type != null)
    {
fos.write("5\nB4\n".getBytes());

fos.close();
      return true;

      }
    if (this.gid != null)
    {
fos.write("6\nB5\n".getBytes());

fos.close();
      return true;

      }
    if (this.path != null)
    {
fos.write("7\nB6\n".getBytes());

fos.close();
      return true;
      }

fos.close();
    return false;

  }

  /**
   * @param d
   *          not null
   */
  public boolean match(Dependency d)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Select.match.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    boolean r = true;

    /* match if not attributes given */
    if (hasattribs() == false)
    {
fos.write("2\nB1\n".getBytes());

fos.close();
      return r;

    }
    if (r && this.alias != null)
    {
fos.write("3\nB2\n".getBytes());

      r = match(this.alias, d.getAlias());
      }
    if (r && this.scope != null) {

fos.write("4\nB3\n".getBytes());

      String[] scope;
      scope = d.getScope();
      r = false;
      for (int i = 0; !r && i < scope.length; ++i)
      {
fos.write("5\nB4\n".getBytes());

        r = match(this.scope, scope[i]);
        }
    }

    if (r && this.bname != null)

fos.write("6\nB5\n".getBytes());

      r = match(this.bname, d.basename());

    if (r && this.type != null)

fos.write("7\nB6\n".getBytes());

      r = match(this.type, d.getType());

    if (r && this.gid != null)

fos.write("8\nB7\n".getBytes());

      r = match(this.gid, d.getGroupId());

    if (r && this.path != null)

fos.write("9\nB8\n".getBytes());

      r = match(this.path, d.m1path());

    if (r && this.version != null)

fos.write("10\nB9\n".getBytes());

      r = match(this.version, d.getVersion());

fos.close();
    return r;

  }

}