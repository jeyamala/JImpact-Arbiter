
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka.dep;

import java.io.*;

import it.haefelinger.flaka.util.Static;

import java.io.File;
import java.util.Map;
import java.util.Properties;

import org.apache.tools.ant.Project;


// Regarding Maven (1.02) element <jar> within a dependency:
// The docmentation states that <jar> is used to construct the
// artifact name (without stating what the "name" is supposed to be.
// It turns out that "name" is supposed to be the "basename". When
// playing around with dependencies, Maven 1.0.2 behaves like shown
// in the examples below.
// 
// <dependency>
// <jar>junit-3.8.1.jar</jar> Illegal state
// </dependency>
//
// <dependency>
// <groupId>junit</groupId>
// <jar>junit-3.8.1.jar</jar> Illegal state
// </dependency>
//
// <dependency>
// <groupId>junit</groupId>
// <version>3.8.1</version> Illegal state
// </dependency>
//
// <dependency>
// <groupId>junit</groupId>
// <artifactId>junit</artifactId>
// <jar>junit-3.8.1.jar</jar> Good.
// </dependency>
//
// <dependency>
// <groupId>junit</groupId>
// <artifactId>WHATEVER</artifactId>
// <jar>junit-3.8.1.jar</jar> Good (artifactId, is
// </dependency> overridden).
//
// <dependency>
// <groupId>NO-SUCH-GROUP</groupId>
// <artifactId>WHATEVER</artifactId>
// <jar>junit-3.8.1.jar</jar> Fails to resolve.
// </dependency>
//
// <dependency>
// <groupId>junit</groupId>
// <artifactId>WHATEVER</artifactId>
// <jar>junit-3.8.1</jar> Fails to resolve.
// <type>jar</jar>
// </dependency>
//
// <dependency>
// <groupId>junit</groupId>
// <artifactId>WHATEVER</artifactId>
// <jar>junit-3.8.1.jar</jar> Good.
// <type>jar</jar>
// </dependency>
//
// <dependency>
// <groupId>junit</groupId>
// <artifactId>WHATEVER</artifactId>
// <jar>junit-3.8.1.jar</jar> Fails to resolve.
// <type>war</jar>
// </dependency>
//
// <dependency>
// <groupId>junit</groupId>
// <artifactId>WHATEVER</artifactId>
// <jar>junit-3.8.1.jar</jar> Good (version is
// <type>jar</jar> ignored).
// <version>xxx</version>
// </dependency>
//
public class Dependency {

  /* The logical name of this dependency (if any) */
  public String alias = null;
  /* The revision/version */
  public String rev;
  /* The type */
  public String type;
  /* The group */
  public String group;
  /* The name */
  public String name;
  /* The alternative name-rev for irregular typed names */
  public String jar;
  /* The usage scopes of this dependency */
  public String[] scope = { "compile" };
  /* Additional properties */
  public Map props = null;
  /* The materialized dependency */
  public File file = null;
  /* The location of this dependency's declaration */
  public File location = null;
  /* The alternative location from where to get the artifact */
  public String alt;

  /* This is the task which created this dependency */
  public Project proj;

  public Dependency(Project proj) {
    super();
    this.proj = proj;
  }

  public Object clone() {
    Dependency d = new Dependency(this.proj);
    d.alias = this.alias;
    d.rev = this.rev;
    d.type = this.type;
    d.group = this.group;
    d.name = this.name;
    d.jar = this.jar;
    d.scope = this.scope;
    d.props = this.props;
    d.file = this.file;
    d.location = this.location;
    d.alt = this.alt;
    return d;
  }

  public String getAlias()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getAlias.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.alias;

  }

  public void setAlias(String S)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.setAlias.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.alias = Static.trim2(S, null);
fos.close();

  }

  /**
   * @return alt
   */
  public String getAlt()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getAlt.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.alt;

  }

  /**
   * @return version
   */
  public String getVersion()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getVersion.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.rev;

  }

  // Ivy names
  public String getRev()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getRev.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.rev;

  }

  public String getGroup()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getGroup.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.group;

  }

  public String getName()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getName.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.name;

  }

  /**
   * @param string
   */
  public void setUrl(String string)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.setUrl.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.alt = string;
fos.close();

  }

  /**
   * @param string
   */
  public void setVersion(String string)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.setVersion.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.rev = string;
fos.close();

  }

  /**
   * @return the type (or extension) of the dependency
   */
  public String getType()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getType.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.type;

  }

  /**
   * Sets the type (or extension) of the dependency
   * 
   * @param string
   */
  public void setType(String string)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.setType.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.type = string;
fos.close();

  }

  /**
   * @return artifact name
   */
  public String getArtifactId()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getArtifactId.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.name;

  }

  /**
   * @return group name
   */
  public String getGroupId()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getGroupId.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.group;

  }

  /**
   * @return jar
   */
  public String getJar()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getJar.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.jar;

  }

  /**
   * @param string
   */
  public void setArtifactId(String string)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.setArtifactId.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.name = string;
fos.close();

  }

  /**
   * @param string
   */
  public void setGroupId(String string)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.setGroupId.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.group = string;
fos.close();

  }

  /**
   * @param string
   */
  public void setJar(String string)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.setJar.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.jar = string;
fos.close();

  }

  public String[] getScope() {
    return this.scope;
  }

  public void setScope(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.setScope.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (s != null) {

fos.write("2\nB1\n".getBytes());

      this.scope = s.split("\\s");
    }
fos.close();

  }

  /**
   * @return loc where this dependency has been declared
   */
  public File getLocation() {
    return this.location;
  }

  /**
   * @param location
   *          this dependency has been declared in loc <code>location</code> .
   */
  public Dependency setLocation(File location) {
    this.location = location;
    return this;
  }

  public void setFile(File file)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.setFile.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.file = file;
fos.close();

  }

  public File getFile() {
    return this.file;
  }

  public String getBasename()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getBasename.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return basename();

  }

  public String getM1path()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getM1path.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.m1path();

  }

  public String getM2path()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getM2path.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.m2path();

  }

  /*
   * Returns the basename of the calculated 'loc name'. Example: Assume that we
   * have a dependency for
   * 
   * log4j/jars/log4j-1.2.8.jar
   * 
   * Then basename() would return
   * 
   * log4j-1.2.8.jar
   */
  public String basename()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.basename.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String s;

    /*
     * According to Maven's behaviour, "<jar>" overrides any other setting.
     */
    if (this.jar != null) {

fos.write("2\nB1\n".getBytes());

      return this.jar;
    }
    s = null;
    if (this.name != null)

fos.write("3\nB2\n".getBytes());

      s = this.name;
    if (s == null)

fos.write("4\nB3\n".getBytes());

      s = "?";
    if (this.rev != null) {

fos.write("5\nB4\n".getBytes());

      s += "-";
      s += this.rev;
    }
    s += ".";
    if (this.type != null) {

fos.write("6\nB5\n".getBytes());

      s += this.type;
      }
    else

fos.write("7\nB6\n".getBytes());

      s += "jar";
fos.close();
    return s;

  }

  /**
   * Returns the path expected on the remote repository
   * 
   * @return the path which will be used on a remote repository
   */
  public String m1path()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.m1path.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String s="";
    String b = basename();

    /* must have either id or (groupd and (artifact or jar)) */
    if (this.group == null || b == null || b.equals(""))
    {
fos.write("2\nB1\n".getBytes());
    s = "/";
fos.close();
      return null;



      }
    if (this.group != null) {

fos.write("3\nB2\n".getBytes());

      s += this.group;
      }
    else{

fos.write("4\nB3\n".getBytes());

      s += "?";
    s += "/";
      }
    if (this.type != null) {

fos.write("5\nB4\n".getBytes());

      s += this.type;
      }
    else{

fos.write("6\nB5\n".getBytes());

      s += "jar";
    s += "s/";
    s += b;
      }
fos.close();

    return s;

  }

  /**
   * Returns the path expected on the remote repository
   * 
   * @return the path which will be used on a remote repository
   */
  public String m2path()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.m2path.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String s="";
    String b = basename();

    /* must have either id or (group and (artifact or jar)) */
    if (this.group == null || b == null || b.equals(""))
    {
fos.write("2\nB1\n".getBytes());
s = "/";
fos.close();
      return null;
      }
    
    if (this.group != null) {

fos.write("3\nB2\n".getBytes());

      s += this.group.replace('.', '/');
      }
    else{

fos.write("4\nB3\n".getBytes());

      s = "?";
    s += "/";
      }
    if (this.name != null) {

fos.write("5\nB4\n".getBytes());

      s += this.name;
      s += "/";
    }
    if (this.rev != null) {

fos.write("6\nB5\n".getBytes());

      s += this.rev;
      s += "/";
    }
    s += basename();
fos.close();
    return s;

  }

  public String toString() {
      try{
    return tostring(false);
      }catch(Exception e){}
return "";
  }

  public String toAliased()  throws Exception {
    return tostring(true);

  }

  public String tostring(boolean aliased)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.tostring.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String s;

    s = "<dependency";

    if (aliased && this.getAlias() != null) {

fos.write("2\nB1\n".getBytes());

      s += " alias=\"";
      s += this.getAlias();
      s += "\"";
    }
    s += ">\n";

    if (this.group != null){

fos.write("3\nB2\n".getBytes());

      s += "<groupId>" + this.group + "</groupId>\n";
      }
    if (this.jar != null){

fos.write("4\nB3\n".getBytes());

      s += "<jar>" + this.jar + "</jar>\n";
      }
    if (this.name != null){

fos.write("5\nB4\n".getBytes());

      s += "<artifactId>" + this.name + "</artifactId>\n";
      }
    if (this.rev != null){

fos.write("6\nB5\n".getBytes());

      s += "<version>" + this.rev + "</version>\n";
      }
    if (this.type != null){

fos.write("7\nB6\n".getBytes());

      s += "<type>" + this.type + "</type>\n";
      }
    else{

fos.write("8\nB7\n".getBytes());

      s += "<type>jar</type>\n";
      }
    if (this.alt != null)
    {
fos.write("9\nB8\n".getBytes());

      s += "<url>" + this.alt + "</url>\n";
      }
    if (this.scope != null) {

fos.write("10\nB9\n".getBytes());

      s += "<scope>";
      for (int i = 0; i < this.scope.length; ++i) {

fos.write("11\nB10\n".getBytes());

        s += this.scope[i];
        if (i + 1 < this.scope.length) {

fos.write("12\nB11\n".getBytes());

          s += " ";
        }
      }
      s += "</scope>\n";
    }
    if (this.props != null && this.props.size() > 0) {

fos.write("13\nB12\n".getBytes());

      Object keyset[] = this.props.keySet().toArray();
      s += "<properties>\n";
      for (int i = 0; i < keyset.length; ++i) {

fos.write("14\nB13\n".getBytes());

        Object k, v;
        String ks, vs;
        k = keyset[i];
        try {
          v = this.props.get(k);
          ks = k.toString();
          vs = v.toString();
          s += "<" + ks + ">" + vs + "</" + ks + ">\n";
        } catch (Exception e) {
          this.proj.log("problems while dumping a dependency property.",
              Project.MSG_DEBUG);
          s += "<!-- error on getting a property -->\n";
        }
      }
      s += "</properties>\n";
    }
    s += "</dependency>\n";
fos.close();
    return s;

  }

  /**
   * Sets a property value
   * 
   * @param key
   *          the property key to set
   * @param value
   *          the property value to set
   * @return the property value just set (can be null)
   */
  public String putProperty(String key, String value)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.putProperty.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (key == null) {

fos.write("2\nB1\n".getBytes());

      return null;
    }
    if (this.props == null)

fos.write("3\nB2\n".getBytes());

      this.props = new Properties();
fos.close();
    return (String) this.props.put(key, value);

  }

  /**
   * Returns a property value
   * 
   * @param key
   *          the property key to retrieve
   * @return a property value, or null if not found
   */
  public String getProperty(String key)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.getProperty.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (key == null || this.props == null) {

fos.write("2\nB1\n".getBytes());

      return null;
    }
fos.close();
    return (String) this.props.get(key);

  }

  /**
   * Checks this Dep against another dependency for equality
   */
  public boolean equals(Object other) {
      try{
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.equals.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (other == null) {

fos.write("2\nB1\n".getBytes());

      return false;
    }
    if (!this.getClass().equals(other.getClass())) {

fos.write("3\nB2\n".getBytes());

      return false;
    }
    Dependency otherDep = (Dependency) other;
fos.close();
    return this.basename().equals(otherDep.basename());
    }catch(Exception e){}
      return false;

  }

  // public String eval(Project P,String v)
  // {
  // return P.replaceProperties(v);
  // }

  /**
   * Resolve properties within this dependency ..
   * 
   * @param P
   *          project's properties are used to resolve this dependency.
   * @return number of properties resolved (>=0).
   */

  public int resolve(Properties P)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.dep.Dependency.resolve.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    int c = 0;
    /* we can't resolve without properties */
    if (P == null) {

fos.write("2\nB1\n".getBytes());

fos.close();
      return c;
      }

    /* we can't resolve without have an "alias" for this dependency. */
    if (this.alias == null)
    {
fos.write("3\nB2\n".getBytes());

fos.close();
      return c;

      }
    if (this.group == null) {

fos.write("4\nB3\n".getBytes());

      this.group = P.getProperty(this.alias + ".path", null);
      c += (this.group == null) ? 0 : 1;
    }
    if (this.name == null) {

fos.write("5\nB4\n".getBytes());

      this.name = P.getProperty(this.alias + ".name", null);
      c += (this.name == null) ? 0 : 1;
    }
    if (this.rev == null) {

fos.write("6\nB5\n".getBytes());

      this.rev = P.getProperty(this.alias + ".vers", null);
      c += (this.rev == null) ? 0 : 1;
    }
    if (this.alt == null) {

fos.write("7\nB6\n".getBytes());

      this.alt = P.getProperty(this.alias + ".url", null);
      c += (this.alt == null) ? 0 : 1;
    }
    if (this.type == null) {

fos.write("8\nB7\n".getBytes());

      this.type = P.getProperty(this.alias + ".type", null);
      c += (this.type == null) ? 0 : 1;
    }
    if (this.jar == null) {

fos.write("9\nB8\n".getBytes());

      this.jar = P.getProperty(this.alias + ".jar", null);
      c += (this.jar == null) ? 0 : 1;
    }

    /*
     * We have not been able to resolve the type of this dependency via
     * properties. In this case we try to derive the type from the alias name
     * (should have the format "<alias>.<type>".
     */

    if (this.type == null) {

fos.write("10\nB9\n".getBytes());

      int index;
      this.type = "";

      index = this.alias.lastIndexOf('.');
      if (index >= 0) {

fos.write("11\nB10\n".getBytes());

        try {
          /* index+1 could be out-of-range */
          this.type = this.alias.substring(index + 1);
        } catch (Exception e) {
          // do nothing
        }
      }
      /* if we can't derive a type, fall back to "jar" */
      this.type = this.type.trim();
      if (this.type.length() <= 0) {

fos.write("12\nB11\n".getBytes());

        this.type = "jar";
      }
    }

fos.close();
    return c;

  }

}