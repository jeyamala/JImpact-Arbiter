
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.HttpUpload;
import it1.haefelinger.flaka.util.Static;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.types.FileSet;


/**
 * 
 * @author merzedes
 * @since 1.0
 */
public class HttpUploadTask extends Task {
  public File rcfile;
  public HttpUpload uploader;
  public List filesets;
  public File logdir;
  public String acceptpat;
  public String errorpat;

  public HttpUploadTask() {
    this.uploader = new HttpUpload();
    this.filesets = new ArrayList();
    this.logdir = null;
  }

  public void setAcceptIf(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.setAcceptIf.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.acceptpat = Static.trim2(s, this.acceptpat);
fos.close();

  }

  public void setErrorIf(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.setErrorIf.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.errorpat = Static.trim2(s, this.errorpat);
fos.close();

  }

  public void setLogdir(File logdir)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.setLogdir.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.logdir = logdir;
fos.close();

  }

  public void setEndpoint(String S)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.setEndpoint.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String s = Static.trim2(S, null);
    if (s != null)

fos.write("2\nB1\n".getBytes());

      this.uploader.set("endpoint", s);
fos.close();

  }

  public void setTest(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.setTest.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.uploader.set("testonly", b ? "true" : "false");
fos.close();

  }

  public void setCategory(String S)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.setCategory.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String s = Static.trim2(S, null);
    if (s != null)

fos.write("2\nB1\n".getBytes());

      this.uploader.set("category", s);
fos.close();

  }

  public void setRcFile(File file)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.setRcFile.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.rcfile = file;
fos.close();

  }

  public void setDebug(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.setDebug.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.uploader.setDebug(b);
fos.close();

  }

  public void addFileset(FileSet set)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.addFileset.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (set != null) {

fos.write("2\nB1\n".getBytes());

      this.filesets.add(set);
    }
fos.close();

  }

  public boolean isTest()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.isTest.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.uploader.get("testonly", "").matches("\\s*true\\s*");

  }

  public String[] eval(FileSet fs) throws BuildException {
    DirectoryScanner ds;
    File dir;
    String[] files;

    if (fs == null)
      return null;

    ds = fs.getDirectoryScanner(getProject());
    dir = fs.getDir(getProject());
    files = ds.getIncludedFiles();

    for (int i = 0; i < files.length; ++i) {
      String s;

      s = files[i];
      files[i] = new File(dir, s).getAbsolutePath();
    }

    return files;
  }

  // The method executing the task
  public void execute() throws BuildException   {
      try{
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.execute.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    String s;

    if (this.debug) {

fos.write("2\nB1\n".getBytes());

      /* enable debug output */
      // HttpUpload.debug(true);
    }

    if (this.filesets == null) {

fos.write("3\nB2\n".getBytes());

      throwbx("this task must be used with at least on <fileset>.");
    }

    /* read username and password from a hidden RC loc */
    if (this.rcfile != null) {

fos.write("4\nB3\n".getBytes());

      String[] words;

      s = this.rcfile.getAbsolutePath();
      if (!this.rcfile.exists()) {

fos.write("5\nB4\n".getBytes());

        throwbx("loc `" + s + "' does not exist.");
      }
      /* read username and password from this loc */
      s = Static.readlines(this.rcfile);
      if (s == null) {

fos.write("6\nB5\n".getBytes());

        throwbx("unable to read from loc `" + s + "'.");
        return;
      }

      /* split into words */
      words = s.split("\\s+");

      if (words == null || words.length < 2) {

fos.write("7\nB6\n".getBytes());

        throwbx("syntax error while parsing loc `" + s + "' -  too few words.");
        return;
      }

      /* format: username password */
      this.uploader.set("user", words[0]);
      this.uploader.set("passwd", words[1]);
    }

    boolean errorseen = false;

    /* TODO: not used right now .. */
    this.uploader.set("accept-if", this.acceptpat);

    for (int i = 0; i < this.filesets.size(); ++i) {

fos.write("8\nB7\n".getBytes());

      String[] files;

      files = eval((FileSet) this.filesets.get(i));

      if (files == null)
      {
fos.write("9\nB8\n".getBytes());

        continue;
        }
      for (int j = 0; j < files.length; ++j) {

fos.write("10\nB9\n".getBytes());

        File f;
        boolean rc;

        f = new File(files[j]);
        this.uploader.set("filepath", f.getPath());
        rc = this.uploader.upload();

        if (this.logdir != null) {

fos.write("11\nB10\n".getBytes());

          String buf;
          String name = f.getPath().replaceAll("/|\\.\\.|\\\\|:|\\.", "_");
          buf = this.uploader.get("xmlbuf", null);
          savebuf(buf, "upload-" + name + ".xml");
          buf = this.uploader.get("resbuf", null);
          savebuf(buf, "upload-" + name + ".txt");
        }
        if (!rc) {

fos.write("12\nB11\n".getBytes());

          String errmsg;

          errorseen = true;
          errmsg = this.uploader.getError();
          if (isTest())
          {
fos.write("13\nB12\n".getBytes());

            info(errmsg);
            }
          else
          {
fos.write("14\nB13\n".getBytes());

            throwbx(errmsg);
        }
        } else {

fos.write("15\nB14\n".getBytes());

          info("loc `" + this.uploader.get("filepath", "") + "' uploaded.");
        }
      
    }
    if (errorseen) {

fos.write("16\nB15\n".getBytes());

      throwbx("error(s) seen while uploading files.");
    }
          }
fos.close();

}catch(Exception e){ }
  }

  /**
   * Save content of buffer buf into logdir using filename fname.
   * 
   * @param buf
   * @param fname
   * @return true if no error occured
   */
  public boolean savebuf(String buf, String fname)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.HttpUploadTask.savebuf.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    boolean good = true;
    FileOutputStream fo = null;
    File u;

    if (this.logdir != null && buf != null && fname != null) {

fos.write("2\nB1\n".getBytes());

      u = new File(this.logdir, fname);
      this.debug("writing upload log report: " + u.getAbsolutePath());
      try {
        fo = new FileOutputStream(u);
        fo.write(buf.getBytes());
      } catch (Exception e) {
        good = false;
        this.error("unable to write upload log report: ", e);
      } finally {
        Static.close(fo);
      }
    }
fos.close();
    return good;

  }
}