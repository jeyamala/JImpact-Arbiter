
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;

import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;


/**
 * @author merzedes
 * @since 1.0
 */
public class SetDefault extends Task {
  public String target = null;
  public boolean fail = false;
  public boolean override = false;

  /**
   * The name of the default target.
   * 
   * @param s
   */
  public void setName(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.SetDefault.setName.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.target = Static.trim2(s, this.target);
fos.close();

  }

  public String getName()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.SetDefault.getName.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.target;

  }

  /**
   * Whether to fail if the target does not exist.
   * 
   * @param b
   */
  public void setFail(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.SetDefault.setFail.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.fail = b;
fos.close();

  }

  public boolean getFail()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.SetDefault.getFail.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.fail;

  }

  /**
   * Whether to override an existing default target
   * 
   * @param b
   */
  public void setOverride(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.SetDefault.setOverride.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.override = b;
fos.close();

  }

  public boolean hastarget(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.SetDefault.hastarget.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Hashtable H = getProject().getTargets();
fos.close();
    return H.containsKey(s);

  }

  public void execute() throws BuildException  {
        
        try {
            FileOutputStream fos = null;
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.SetDefault.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            String s;
            if (this.target == null) {
                fos.write("2\nB1\n".getBytes());
                debug("no default target given to set");
                return;
            }
            s = getProject().getDefaultTarget();
            if (!Static.isEmpty(s) && this.override == false) {
                fos.write("3\nB2\n".getBytes());
                debug("default target already set to `" + s + "' (ignored)");
                return;
            }
            if (hastarget(this.target)) {
                fos.write("4\nB3\n".getBytes());
                getProject().setDefault(this.target);
            } else {
                fos.write("5\nB4\n".getBytes());
                String m;
                m = "target `" + this.target + "' does not exist.";
                if (this.fail) {
                    fos.write("6\nB5\n".getBytes());
                    throwbx(m);
                } else {
                    fos.write("7\nB6\n".getBytes());
                    verbose(m + " (ignored)");
                }
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(SetDefault.class.getName()).log(Level.SEVERE, null, ex);
        }

  }
}