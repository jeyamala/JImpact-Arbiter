
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.RuntimeConfigurable;
import org.apache.tools.ant.taskdefs.MacroInstance;
import org.apache.tools.ant.taskdefs.PreSetDef;


/**
 * A task allowing the dynamic execution of a macro or task.
 * 
 * 
 * @author merzedes
 * @since 1.0
 */

public class RunMacro extends Task {
  public String name = "";
  public boolean fail = false;
  public List args = null; /* list of arguments */

  /**
   * The name of the macro to execute.
   * 
   * @param s
   */
  public void setName(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunMacro.setName.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.name = Static.trim2(s, this.name);
fos.close();

  }

  /**
   * Fail if macro does not exist.
   * 
   * @param b
   */
  public void setFail(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunMacro.setFail.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.fail = b;
fos.close();

  }

  public boolean getFail()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunMacro.getFail.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.fail;

  }

  /** nested element <code>param</code> */
  public Param createParam() {
    return createArg();
  }

  /** nested element <code>attribute</code> */
  public Param createAttribute() {
    return createArg();
  }

  /** nested element <code>arg</code> */
  public Param createArg() {
      Param P= new Param();;  
      try {
                                    addarg(P);

        } catch (Exception ex) {
            Logger.getLogger(RunMacro.class.getName()).log(Level.SEVERE, null, ex);
        }
      return P;
  }

  public List getargs() {
    if (this.args == null)
      this.args = new ArrayList();
    return this.args;
  }

  public void addarg(Object obj)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunMacro.addarg.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    getargs().add(obj);
fos.close();

  }

  public class Param {
    public String k;
    public String v;

    public Param() {
      this.k = null;
      this.v = null;
    }

    public void setName(String k)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunMacro.setName.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

      this.k = Static.trim2(k, this.k);
fos.close();

    }

    public void setValue(String v) {
      this.v = Static.trim2(v, this.v);
    }
  }

  public void onerror(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunMacro.onerror.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (this.fail)
    {
fos.write("2\nB1\n".getBytes());

      throwbx(s);
      }
    else
    {
fos.write("3\nB2\n".getBytes());

      verbose("warning: " + s);
fos.close();
      }
  }

  public void runmacro(String m, Object[] args)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunMacro.runmacro.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Param P;
    Object obj;

    obj = Static.makecomp(getProject(), m);
    if (obj == null) {

fos.write("2\nB1\n".getBytes());

      onerror("`" + m + "' neither marco nor task.");
      return;
    }

    /*
     * Check whether it's a presetdef. If so then Project.createTask() fails
     * with ClassCastException (1.6.5). In such a way we need to create the
     * object like shown below ..
     */
    if (obj instanceof PreSetDef.PreSetDefinition) {

fos.write("3\nB2\n".getBytes());

      PreSetDef.PreSetDefinition psd;
      psd = (PreSetDef.PreSetDefinition) obj;
      obj = psd.createObject(getProject());
    } else {

fos.write("4\nB3\n".getBytes());

      /* try to create task */
      obj = getProject().createTask(m);
      if (obj == null) {

fos.write("5\nB4\n".getBytes());

        /* this should not happen - anyhow, we check again */
        onerror("`" + m + "' neither marco nor task.");
        return;
      }
    }

    if (obj instanceof MacroInstance) {

fos.write("6\nB5\n".getBytes());

      MacroInstance M;
      M = (MacroInstance) obj;
      for (int i = 0; i < args.length; ++i) {

fos.write("7\nB6\n".getBytes());

        if (args[i] instanceof Param) {

fos.write("8\nB7\n".getBytes());

          P = (Param) args[i];
          M.setDynamicAttribute(P.k, P.v);
        }
      }
      M.execute();
      return;
    }

    if (obj instanceof org.apache.tools.ant.Task) {

fos.write("9\nB8\n".getBytes());

      RuntimeConfigurable rtc;
      org.apache.tools.ant.Task T;

      T = (org.apache.tools.ant.Task) obj;
      rtc = T.getRuntimeConfigurableWrapper();
      for (int i = 0; i < args.length; ++i) {

fos.write("10\nB9\n".getBytes());

        if (args[i] instanceof Param) {

fos.write("11\nB10\n".getBytes());

          P = (Param) args[i];
          rtc.setAttribute(P.k, P.v);
        }
      }
      T.execute();
      return;
    }

    onerror("`" + m + "' neither marco nor task.");
fos.close();
    return;
  }

  public void execute() throws BuildException   {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunMacro.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            Object[] args = getargs().toArray();
            String[] name = this.name.split("\\s+");
            for (int i = 0; i < name.length; ++i) {
                fos.write("2\nB1\n".getBytes());
            runmacro(name[i], args);
            }
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(RunMacro.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(RunMacro.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }
}