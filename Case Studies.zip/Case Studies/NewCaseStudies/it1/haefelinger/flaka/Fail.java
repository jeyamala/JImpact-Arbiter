
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.Exit;
import org.apache.tools.ant.taskdefs.condition.ConditionBase;


/**
 * Same as Ant's fail task, additionally resolve EL references in message and
 * property.
 * 
 * 
 * @author merzedes
 * @since 1.0
 */
public class Fail extends Exit {
  public String test;
  public boolean havemsg = false;
  public boolean dosuper = false;

  public void setMessage(String msg)   {
    Project project = getProject();
    msg = project.replaceProperties(msg);
    msg = Static.elresolve(project, msg);
    super.setMessage(msg);
    this.havemsg = true;
  }

  public void addText(String msg)   {
    Project project = getProject();
    msg = project.replaceProperties(msg);
    msg = Static.elresolve(project, msg);
    super.addText(msg);
    this.havemsg = true;
  }

  public void setTest(String expr)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.Fail.setTest.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.test = Static.elresolve(getProject(), expr);
fos.close();

  }

  public void setIf(String s)  {
    this.dosuper = true;
    super.setIf(s);
  }

  public void setUnless(String s)  {

    this.dosuper = true;
    super.setUnless(s);

  }

  public ConditionBase createCondition() {
    this.dosuper = true;
    return super.createCondition();
  }

  public void execute() throws BuildException {
        FileOutputStream fos = null;
        try {
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.Fail.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            Project project;
            /* standard behaviour */
            if (this.test == null) {
                fos.write("2\nB1\n".getBytes());
                super.execute();
                return;
            }
            project = getProject();
            if (Static.el2bool(project, this.test)) {
                fos.write("3\nB2\n".getBytes());
                /* Set a nice message if not set */
                if (this.havemsg == false) {
                    fos.write("4\nB3\n".getBytes());
                    this.setMessage("test(\"" + this.test + "\") => true");
                }
                this.setUnless("${}");
                /*
                 * We want to use super here to handle all the other logistics (exist
                 * status, message handling etc).
                 */
                super.execute();
                return;
            }
            if (this.dosuper) {
                fos.write("5\nB4\n".getBytes());
            }
            super.execute();
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(Fail.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(Fail.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

  }
}