
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it1.haefelinger.flaka.util.Static;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tools.ant.BuildException;


/**
 * A task allowing the dynamic execution of a target.
 * 
 * 
 * @author merzedes
 * @since 1.0
 */

public class RunTarget extends Task {
  public String name = null;
  public boolean fail = false;

  /**
   * The name of the target to execute
   * 
   * @param s
   */
  public void setName(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunTarget.setName.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.name = Static.trim2(s, this.name);
fos.close();

  }

  public String getName()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunTarget.getName.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.name;

  }

  /**
   * Whether to fail if target does not exist.
   * 
   * @param b
   */
  public void setFail(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunTarget.setFail.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.fail = b;
fos.close();

  }

  public boolean getFail()  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunTarget.getFail.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

fos.close();
    return this.fail;

  }

  public void onerror(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunTarget.onerror.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (this.fail)
    {
fos.write("2\nB1\n".getBytes());

      throwbx(s);
      }
    else
    {
fos.write("3\nB2\n".getBytes());

      verbose("warning: " + s);
fos.close();
      }
  }

  public void execute() throws BuildException   {
       
        try {
             FileOutputStream fos = null;
            File file1 = new File("src//instrumented//it1.haefelinger.flaka.RunTarget.execute.txt");
            fos = new FileOutputStream(file1, false);
            fos.write("1\n".getBytes());
            if (this.name == null) {
                fos.write("2\nB1\n".getBytes());
                onerror("attribute `name' missing.");
                return;
            }
            if (Static.istarget(getProject(), this.name)) {
                fos.write("3\nB2\n".getBytes());
                getProject().executeTarget(this.name);
            } else {
                fos.write("4\nB3\n".getBytes());
                onerror("`" + this.name + "' not a target.");
            }
            fos.close();
            return;
        } catch (Exception ex) {
            Logger.getLogger(RunTarget.class.getName()).log(Level.SEVERE, null, ex);
        }
        }

  }
