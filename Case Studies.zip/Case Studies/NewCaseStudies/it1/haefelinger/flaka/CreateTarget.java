
/*
 * Copyright (c) 2009 Haefelinger IT 
 *
 * Licensed  under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required  by  applicable  law  or  agreed  to in writing, 
 * software distributed under the License is distributed on an "AS 
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either 
 * express or implied.
 
 * See the License for the specific language governing permissions
 * and limitations under the License.
 */
package it1.haefelinger.flaka;

import java.io.*;

import it.haefelinger.flaka.util.Static;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Target;
import org.apache.tools.ant.taskdefs.PreSetDef;


/**
 * A task allowing the dynamic creation of a target.
 * 
 * 
 * @author merzedes
 * @since 1.0
 */

public class CreateTarget extends Task {
  public String name = null; /* name of new target */
  public String task = null; /* name of task (or macro) to exec */
  public String desc = null; /* (optional) description */
  public String deps = null; /* (optional) depends on */
  public boolean override = false; /* override if target already exist */
  public boolean fail = true;

  public void setName(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CreateTarget.setName.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.name = Static.trim2(s, null);
fos.close();

  }

  public void setTask(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CreateTarget.setTask.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.task = Static.trim2(s, null);
fos.close();

  }

  public void setDescription(String s){
    this.desc = Static.trim2(s, null);
  }

  public void setDepends(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CreateTarget.setDepends.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.deps = Static.trim2(s, null);
fos.close();

  }

  public void setOverride(boolean b)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CreateTarget.setOverride.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    this.override = b;
fos.close();

  }

  public void onerror(String s)  throws Exception {
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CreateTarget.onerror.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    if (this.fail)
    {
fos.write("2\nB1\n".getBytes());

      throwbx(s);
      }
    else
    {
fos.write("3\nB2\n".getBytes());

      verbose("warning: " + s);
      }
fos.close();

  }

  public void execute() throws BuildException {
      try{
File file1 = new File("src//instrumented//it1.haefelinger.flaka.CreateTarget.execute.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

    Target target;
    Object obj;
    org.apache.tools.ant.Task T = null;
    Project P = getProject();
    String pname = P.getName();

    if (this.name == null) {

fos.write("2\nB1\n".getBytes());

      debug("attribute `name' missing.");
      return;
    }

    debug("creating target " + this.name + "[" + this.task + "] in project "
        + pname + "");

    if (Static.istarget(P, this.name)) {

fos.write("3\nB2\n".getBytes());

      if (this.override == false) {

fos.write("4\nB3\n".getBytes());

        debug("target " + this.name + " exits in project [overriding=false]");
        return;
      }
      debug("target " + this.name + " exits in project [overriding=true]");
    } else {

fos.write("5\nB4\n".getBytes());

      debug("creating new target " + this.name + " in project");
    }

    target = new Target();
    target.setProject(getProject());
    target.setName(this.name);
    if (this.desc != null)

fos.write("6\nB5\n".getBytes());

      target.setDescription(this.desc);
    if (this.deps != null)

fos.write("7\nB6\n".getBytes());

      target.setDepends(this.deps);

    if (this.task != null) {

fos.write("8\nB7\n".getBytes());

      /* Allow for a sequence of tasks .. */
      String list[] = this.task.split("\\s+");
      String word;

      for (int i = 0; i < list.length; ++i) {

fos.write("9\nB8\n".getBytes());

        word = list[i];
        obj = Static.makecomp(getProject(), word);

        if (obj == null) {

fos.write("10\nB9\n".getBytes());

          debug("`" + word + "' does not exist in this project (ignored)");
          continue;
        }

        /*
         * Check whether it's a presetdef. If so then Project.createTask() fails
         * with ClassCastException (1.6.5). In such a way we need to create the
         * object like shown below ..
         */
        if (obj instanceof PreSetDef.PreSetDefinition) {

fos.write("11\nB10\n".getBytes());

          PreSetDef.PreSetDefinition psd;
          psd = (PreSetDef.PreSetDefinition) obj;
          obj = psd.createObject(getProject());
        } else {

fos.write("12\nB11\n".getBytes());

          /* try to create task */
          obj = getProject().createTask(this.task);
          if (obj == null) {

fos.write("13\nB12\n".getBytes());

            /* this should not happen - anyhow, we check again */
            debug("failed to create task `" + this.task + "' in project");
            continue;
          }
        }

        if (!(obj instanceof org.apache.tools.ant.Task)) {

fos.write("14\nB13\n".getBytes());

          debug("task `" + this.task + "' created, but not an Ant Task.");
          continue;
        }

        /* obj != null and instance of Task */
        T = (org.apache.tools.ant.Task) obj;

        debug("adding task " + T.getTaskName() + "[" + T.getTaskType()
            + "] to target " + target.getName() + "");

        target.addTask(T);
      }
    }

    /* eventually add target to project */
    getProject().addTarget(target);
fos.close();
    return;

  }catch(Exception e){  }
    }
}