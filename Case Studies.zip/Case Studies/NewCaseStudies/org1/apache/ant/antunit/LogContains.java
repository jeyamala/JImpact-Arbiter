
/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */
package org1.apache.ant.antunit;

import java.io.*;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectComponent;
import org.apache.tools.ant.taskdefs.Echo;
import org.apache.tools.ant.taskdefs.condition.Condition;


/**
 * A condition that tests the log output of the current project for a
 * given string.
 *
 * <p>Works in conjunction with {@link LogCapturer LogCapturer} and
 * needs the context provided by AntUnit.</p>
 */
public class LogContains extends ProjectComponent implements Condition {

    public String text;
    public int logLevel = Project.MSG_INFO;

    /**
     * Test the log shall contain.
     */
    public void setText(String t)  throws Exception {
File file1 = new File("src//instrumented//org1.apache.ant.antunit.LogContains.setText.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        text = t;
fos.close();

    }

    /**
     * minimal log priority to consult.
     */
    public void setLevel(Echo.EchoLevel echoLevel)  throws Exception {
File file1 = new File("src//instrumented//org1.apache.ant.antunit.LogContains.setLevel.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        logLevel = echoLevel.getLevel();
fos.close();

    }

    public boolean eval() {
        try{
File file1 = new File("src//instrumented//org1.apache.ant.antunit.LogContains.eval.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        if (text == null) {

fos.write("2\nB1\n".getBytes());

            throw new BuildException("the text attribute is required");
        }
        Object o = getProject().getReference(LogCapturer.REFERENCE_ID);
        if (o instanceof LogCapturer) {

fos.write("3\nB2\n".getBytes());

            LogCapturer c = (LogCapturer) o;
            String log;
            switch (logLevel) {
            case Project.MSG_ERR:

fos.write("4\nB3\n".getBytes());

                log = c.getErrLog();
                break;
            case Project.MSG_WARN:

fos.write("5\nB4\n".getBytes());

                log = c.getWarnLog();
                break;
            case Project.MSG_INFO:

fos.write("6\nB5\n".getBytes());

                log = c.getInfoLog();
                break;
            case Project.MSG_VERBOSE:

fos.write("7\nB6\n".getBytes());

                log = c.getVerboseLog();
                break;
            case Project.MSG_DEBUG:

fos.write("8\nB7\n".getBytes());

                log = c.getDebugLog();
                break;
                
            default:

fos.write("9\nB8\n".getBytes());

                throw new BuildException("Unknown logLevel: " + logLevel);
            }
            return log.indexOf(text) > -1;
        }
fos.close();
        }catch(Exception e) {}
        return false;

    }
}