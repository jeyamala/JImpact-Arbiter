
/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */
package org1.apache.ant.antunit.junit3;

import java.io.*;

import java.io.IOException;
import java.io.OutputStream;

import org.apache.ant.antunit.AntUnitScriptRunner;
import org.apache.tools.ant.DemuxOutputStream;
import org.apache.tools.ant.Project;



/**
 * Forward stdout or stderr operation to the current antunit project.
 */
class MultiProjectDemuxOutputStream extends OutputStream {

    public final AntUnitScriptRunner scriptRunner;
    
    public Project lastProject;
    public DemuxOutputStream lastDemuxOutputStream = null;

    public final boolean isErrorStream; 

    public MultiProjectDemuxOutputStream(AntUnitScriptRunner scriptRunner, boolean isErrorStream) {
        this.scriptRunner = scriptRunner;
        this.isErrorStream = isErrorStream;        
    }
    

    public DemuxOutputStream getDemuxOutputStream() {
        if (lastProject != scriptRunner.getCurrentProject()) {
            lastProject = scriptRunner.getCurrentProject();
            lastDemuxOutputStream = new DemuxOutputStream(lastProject,isErrorStream);
        }
        return lastDemuxOutputStream;
    }
    
    public void write(int b) throws IOException {

       getDemuxOutputStream().write(b);


    }

    public void write(byte[] b, int off, int len) throws IOException{
        try{
File file1 = new File("src//instrumented//org1.apache.ant.antunit.junit3.MultiProjectDemuxOutputStream.write.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        getDemuxOutputStream().write(b, off, len);
fos.close();
 }catch(Exception e) {}
    }
    
    public void close() throws IOException {
        getDemuxOutputStream().close();

    }
    
    public void flush() throws IOException{
        getDemuxOutputStream().flush();
    }
}