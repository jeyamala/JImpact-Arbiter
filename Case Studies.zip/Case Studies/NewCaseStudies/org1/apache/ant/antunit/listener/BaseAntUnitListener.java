
/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */
package org1.apache.ant.antunit.listener;

import java.io.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.NumberFormat;

import org1.apache.ant.antunit.AntUnitListener;
import org1.apache.ant.antunit.AssertionFailedException;
import org.apache.tools.ant.BuildEvent;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.BuildListener;
import org.apache.tools.ant.Location;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.taskdefs.LogOutputStream;
import org.apache.tools.ant.types.EnumeratedAttribute;
import org.apache.tools.ant.util.FileUtils;
import org.apache.tools.ant.util.TeeOutputStream;


/**
 * A test listener for &lt;antunit&gt; modeled aftern the Plain JUnit
 * test listener that is part of Ant.
 */
public abstract class BaseAntUnitListener
    implements AntUnitListener {

    public BaseAntUnitListener(SendLogTo defaultReportTarget,
                                  String extension) {
        logTo = defaultReportTarget;
        this.extension = extension;
        logLevel = BaseAntUnitListener.AntUnitLogLevel.NONE;
    }

    /**
     * Formatter for timings.
     */
    public static final NumberFormat nf = NumberFormat.getInstance();

    /**
     * Directory to write reports to.
     */
    public File toDir;

    /**
     * Extension for report files.
     */
    public String extension;

    /**
     * Directory to write reports to.
     */
    public final File getToDir() {
        return toDir;
    }

    /**
     * Sets the directory to write test reports to.
     */
    public void setToDir(File f)  throws Exception {
File file1 = new File("src//instrumented//org1.apache.ant.antunit.listener.BaseAntUnitListener.setToDir.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        toDir = f;
fos.close();

    }

    /**
     * Where to send log.
     */
    public SendLogTo logTo;

    /**
     * Where to send the test report.
     */
    public void setSendLogTo(SendLogTo logTo)  throws Exception {
File file1 = new File("src//instrumented//org1.apache.ant.antunit.listener.BaseAntUnitListener.setSendLogTo.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        this.logTo = logTo;
fos.close();

    }

    public Task parentTask;

    public void setParentTask(Task t){
        parentTask = t;


    }

    /**
     * keeps track of the numer of executed targets, the failures an errors.
     */
    public int runCount, failureCount, errorCount;
    /**
     * time for the starts of the current test-suite and test-target.
     */
    public long start, testStart;

    public void startTestSuite(Project testProject, String buildFile) {
        start = System.currentTimeMillis();
        runCount = failureCount = errorCount = 0;

    }

    public final void close(OutputStream out)  throws Exception {
File file1 = new File("src//instrumented//org1.apache.ant.antunit.listener.BaseAntUnitListener.close.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        if (out != System.out && out != System.err) {

fos.write("2\nB1\n".getBytes());

            FileUtils.close(out);
        }
fos.close();

    }

    public void startTest(String target){
        testStart = System.currentTimeMillis();
        runCount++;
    }
    public void addFailure(String target, AssertionFailedException ae)  {
        failureCount++;
    }
    public void addError(String target, Throwable ae){
        errorCount++;
    }

    public final OutputStream getOut(String buildFile) {
        OutputStream l, f;
        l = f = null;
        if (logTo.getValue().equals(SendLogTo.ANT_LOG)
            || logTo.getValue().equals(SendLogTo.BOTH)) {
            if (parentTask != null) {
                l = new LogOutputStream(parentTask, Project.MSG_INFO);
            } else {
                l = System.out;
            }
            if (logTo.getValue().equals(SendLogTo.ANT_LOG)) {
                return l;
            }
        }
        if (logTo.getValue().equals(SendLogTo.FILE)
            || logTo.getValue().equals(SendLogTo.BOTH)) {
try {
            String fileName = "TEST-" + normalize(buildFile) + "." + extension;
            File file = toDir == null
                ? (parentTask != null 
                   ? parentTask.getProject().resolveFile(fileName)
                   : new File(fileName))
                : new File(toDir, fileName);
            
                f = new FileOutputStream(file);
            } catch (Exception e) {
                throw new BuildException(e);
            }
            if (logTo.getValue().equals(SendLogTo.FILE)) {
                return f;
            }
        }
        return new TeeOutputStream(l, f);
    }

    /**
     * Turns the build file name into something that vaguely looks
     * like a Java classname.  Close enough to be suitable for
     * junitreport.
     */
    public final String normalize(String buildFile)  throws Exception {
File file1 = new File("src//instrumented//org1.apache.ant.antunit.listener.BaseAntUnitListener.normalize.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        File base = parentTask != null
            ? parentTask.getProject().getBaseDir()
            : new File(System.getProperty("user.dir"));
        buildFile = FileUtils.getFileUtils()
            .removeLeadingPath(base, new File(buildFile));
       if (buildFile.length() > 0
            && buildFile.charAt(0) == File.separatorChar) {
            fos.write("2\nB1\n".getBytes());
            buildFile = buildFile.substring(1);
        }

fos.close();
        return buildFile.replace('.', '_').replace(':', '_')

            .replace(File.separatorChar, '.');
    }

    public final Location getLocation(Throwable t) {
        Location l = Location.UNKNOWN_LOCATION;
        if (t instanceof BuildException) {
            Location l2 = ((BuildException) t).getLocation();
            if (l2 != null) {
                l = l2;
            }
        }
        return l;
    }

    public Project currentTest;

    public void setCurrentTestProject(Project p){
        currentTest = p;
        p.addBuildListener(new LogGrabber());
    }

    public Project getCurrentTestProject() {
        return currentTest;
    }

    /**
     * The minimum level a log message must be logged at to be
     * included in the output.
     */
    public AntUnitLogLevel logLevel;

    /**
     * Sets the minimum level a log message must be logged at to be
     * included in the output.
     */
    public void setLogLevel(AntUnitLogLevel l){
        logLevel = l;

    }

    /**
     * Gets messages from the project running the test target if their
     * level is at least of the level specified with {@link
     * #setLoglevel setLogLevel}.
     *
     * <p>This implementation is empty.</p>
     */    public void messageLogged(BuildEvent event) {}


    public static class SendLogTo extends EnumeratedAttribute {
        public static final String ANT_LOG = "ant";
        public static final String FILE = "file";
        public static final String BOTH = "both";

        public SendLogTo() {}

        public SendLogTo(String s) {
            setValue(s);
        }

        public String[] getValues() {
            return new String[] {ANT_LOG, FILE, BOTH};
        }
    }

    public static class AntUnitLogLevel extends EnumeratedAttribute {
        public static final AntUnitLogLevel NONE = new AntUnitLogLevel("none");

        public AntUnitLogLevel() {
            super();
        }

        public AntUnitLogLevel(String value) {
            super();
            setValue(value);
        }

        public String[] getValues() {
            return new String[] {
                "none",
                "error",
                "warn",
                "warning",
                "info",
                "verbose",
                "debug"};
        }

        public static int[] levels = {
            Project.MSG_ERR - 1,
            Project.MSG_ERR,
            Project.MSG_WARN,
            Project.MSG_WARN,
            Project.MSG_INFO,
            Project.MSG_VERBOSE,
            Project.MSG_DEBUG
        };

        public int getLevel() {
            return levels[getIndex()];
        }
    }

    public class LogGrabber implements BuildListener {
        public void buildStarted(BuildEvent event) {}
        public void buildFinished(BuildEvent event) {}
        public void targetStarted(BuildEvent event) {}
        public void targetFinished(BuildEvent event) {}
        public void taskStarted(BuildEvent event) {}
        public void taskFinished(BuildEvent event) {}
        public void messageLogged(BuildEvent event) {
            int priority = event.getPriority();
            // Filter out messages based on priority
            try{
            File file1 = new File("src//instrumented//org1.apache.ant.antunit.listener.BaseAntUnitListener.messageLogged.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

            if (priority <= logLevel.getLevel()) {

fos.write("2\nB1\n".getBytes());

                BaseAntUnitListener.this.messageLogged(event);
            }
fos.close();
        }catch(Exception e) {}
        }
    }


}