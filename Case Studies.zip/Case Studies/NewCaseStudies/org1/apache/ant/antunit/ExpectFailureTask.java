
/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */
package org1.apache.ant.antunit;

import java.io.*;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.taskdefs.Sequential;


/**
 * Expects the nested tasks to throw a BuildException and optinally
 * asserts the message of that exception.
 *
 * <p>Throws a AssertFailedException if the nested tasks do not throw
 * the expected BuildException.</p>
 */
public class ExpectFailureTask extends Sequential {

    public String expectedMessage;
    public String message;

    /**
     * The exception message to expect.
     */
    public void setExpectedMessage(String m)  throws Exception {
File file1 = new File("src//instrumented//org1.apache.ant.antunit.ExpectFailureTask.setExpectedMessage.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        expectedMessage = m;
fos.close();

    }

    /**
     * The message to use in the AssertionFailedException if the nested
     * tasks fail to raise the "correct" exception.
     */
    public void setMessage(String m)  throws Exception {
File file1 = new File("src//instrumented//org1.apache.ant.antunit.ExpectFailureTask.setMessage.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        message = m;
fos.close();

    }

    public void execute() {
        try{
File file1 = new File("src//instrumented//org1.apache.ant.antunit.ExpectFailureTask.execute.txt");
FileOutputStream fos = new FileOutputStream(file1, false);

fos.write("1\n".getBytes());

        boolean thrown = false;
        try {
            super.execute();
        } catch (BuildException e) {
            thrown = true;
            String caughtMessage = e.getMessage();
            if (expectedMessage != null && (caughtMessage == null
                            || caughtMessage.indexOf(expectedMessage) < 0)) {

fos.write("2\nB1\n".getBytes());

                    
                if (message == null) {

fos.write("3\nB2\n".getBytes());

//                    throw new AssertionFailedException(
//                            "Expected build failure "
//                                    + "with message '"
//                                    + expectedMessage
//                                    + "' but was '"
//                                    + caughtMessage + "'" , e);
                } else {

fos.write("4\nB3\n".getBytes());

//                    throw new AssertionFailedException(message, e);
                }
            }
        }

        if (!thrown) {

fos.write("5\nB4\n".getBytes());

            if (message == null) {

fos.write("6\nB5\n".getBytes());

//                throw new AssertionFailedException("Expected build failure");
            } else {

fos.write("7\nB6\n".getBytes());

//                throw new AssertionFailedException(message);
            }
        }
fos.close();
}catch(Exception e) {}
    }
}        